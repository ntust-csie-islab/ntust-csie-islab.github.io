#include <stdio.h>
#include <string.h>
#include <math.h>
#define VarMax 10
#define TermMax 10
#define FileNameMax 10
#define consistent     0
#define redundant      1
#define conflict       2
#define A_type_subsume 3
#define B_type_subsume 4
#define small -1
#define equal 0
#define large 1
#define ParmP 1
#define ParmQ 0.5
#define ParmI 1
#define ParmJ 0.5

typedef struct inconsist
{
 int RuleIndex;
 int InconType;
 struct inconsist *NextNode;
}Inconsist;

typedef struct NandP
{
 char variable[VarMax];
 char term[TermMax];
 float Sn;
 float Sp;
 struct NandP *NextNode;
}NandP;

typedef struct Rule
{
 int index;
 int Killed;
 float Sn;
 float Sp;
 Inconsist *InconHead;
 NandP *PremiseHead;
 NandP consequent;
 struct Rule *NextNode;
}RuleNode;

typedef struct FuzzyNode
{
 char term[TermMax];
 float m;
 float n;
 float alfa;
 float beta;
 struct FuzzyNode *NextNode;
}FuzzyNode;

typedef struct FuzzySet
{
 char variable[VarMax];
 FuzzyNode *FuzzyHead;
 struct FuzzySet *NextNode;
}FuzzyTerm;

typedef struct FuzzyNum
{
 char variable[VarMax];
 float m;
 float n;
 float alfa;
 float beta;
}FuzzyNum;

typedef struct TermNandP
{
 char term[TermMax];
 float Sn;
 float Sp;
}TermNandP;

typedef struct NnP
{
 float Sn;
 float Sp;
}NnP;

typedef struct GInput
{
 char IpVar[VarMax];
 struct GInput *NextNode;
}GInput;

typedef struct Gneuron
{
 char name[VarMax];
 GInput *GIpHead;
 struct Gneuron *NextNode;
}Gneuron;

typedef struct FindTerm
{
 int find;
 char term[TermMax];
}FindTerm;

typedef struct TempNP
{
 int index;
 float ForSumOfAdd;
 float ForSumOfSub;
 float BackSumOfAdd;
 float BackSumOfSub;
 struct TempNP *NextNode;
}TempNP;

RuleNode *MakeRuleNet(RuleNode *RuleHead,FuzzyTerm *FzHead,TempNP *THead);
FuzzyTerm *ReadFuzzySet(FuzzyTerm *FzHead);
void TranNnP(FuzzyNum EachTerm,NandP *PHead,FuzzyTerm *FzHead);
NandP TranConTerm(FuzzyNum EachTerm,NandP Conseq,FuzzyTerm *FzHead);
RuleNode *ReadTerm(FILE *RuleFile,RuleNode *RNode,FuzzyTerm *FzHead,
		   int NumOfTerm);
TermNandP TermNnP(FuzzyNum Term,FuzzyNode *ZHead);
void ReadFuzzyTerm(FILE *FuzzyFile,FuzzyNode *FHead);
void TestFuzzySet(FuzzyTerm *FzHead);
RuleNode *InitRuleNode(RuleNode *Head);
FuzzyTerm *InitFuzzyNode(FuzzyTerm *FzHead);
Gneuron *InitGInput(Gneuron *GHead);
Gneuron *ReadGneuron(Gneuron *GHead);
void ReadGInput(FILE *GFile,GInput *IHead);
void PreConsistentChk(RuleNode *RuleHead,Gneuron *GHead);
int ConsistentChk(RuleNode *FixNode,RuleNode *CmpNode,Gneuron *GHead);
int RedSubAnalysis(NandP *FixPremHead,NandP *CmpPremHead);
int ConfAnalysis(NandP *FixPremHead,NandP *CmpPremHead,GInput *GIHead);
FindTerm *FindVar(GInput *Inow,NandP *NPNode);
int AdvanceChk(NandP *MorePrem, NandP *LessPrem);
void RecordIncon(RuleNode *FixNode,RuleNode *CmpNode,int ChkResult);
void CheckTest(RuleNode *RuleHead);
void GneuronTest(Gneuron *GHead);
float CalculateSn(RuleNode *RNode);
float CalculateSp(RuleNode *RNode);
void ModifyNnP(RuleNode *RuleHead,TempNP *THead);
TempNP *InitTnew(TempNP *TNode,int cntr);
void RedMdfy(RuleNode *RNode,RuleNode *RuleHead,TempNP *THead);
void ConfMdfy(RuleNode *RNode,RuleNode *RuleHead,TempNP *THead);
void AddRedSum(RuleNode *Rfix,RuleNode *Rcmp,TempNP *THead);
void AddConfSum(RuleNode *Rfix,RuleNode *Rcmp,TempNP *THead);
void NPadjust(RuleNode *RuleHead,TempNP *THead);
void SnAdjust(RuleNode *RNode,TempNP *TNode);
void SpAdjust(RuleNode *RNode,TempNP *TNode);
void DeleteRule(RuleNode *RuleHead,RuleNode *KillHead);
void CmpAndMark(RuleNode *RNode, RuleNode *RNode1, int InconType);
void TakeRecordOut(RuleNode *RNode, RuleNode *RNode1);
int DecideByUser(RuleNode *RNode,RuleNode *RNode1,int InconType);
void RealKill(RuleNode *RuleHead,RuleNode *KillHead);
void DeleteRedRule(RuleNode *RuleHead,RuleNode *KillHead);
void DeleteRule(RuleNode *RuleHead,RuleNode *KillHead);
void DeleteConfRule(RuleNode *RuleHead,RuleNode *KillHead);
void DeleteSubsumRule(RuleNode *RuleHead,RuleNode *KillHead);
int FindSubsumeRule(int index,RuleNode *RuleHead);
void RemoveMark(int index,int KillRuleIndex,RuleNode *RuleHead);
void AddKillMark(int index,int RemoveIndex,RuleNode *RuleHead);
float FindDenominator(float x1,float x2,float x3,float x4);
float FindNumerator(float x1,float x2,float x3,float x4);
void ListKill(RuleNode *KillHead);
void ListAllTerm(RuleNode *RuleHead);

main()
{
 static RuleNode *RuleHead, *KillHead;
 static FuzzyTerm *FzHead;
 static Gneuron *GHead;
 static TempNP *THead;
 THead = (TempNP *)malloc(sizeof(TempNP));
 THead->NextNode = NULL;
 FzHead = (FuzzyTerm *)malloc(sizeof(FuzzyTerm));
 FzHead->NextNode = NULL;
 FzHead = InitFuzzyNode(FzHead);
 FzHead = ReadFuzzySet(FzHead);
 RuleHead = (RuleNode *)malloc(sizeof(RuleNode));
 KillHead = (RuleNode *)malloc(sizeof(RuleNode));
 RuleHead->NextNode = NULL;
 KillHead->NextNode = NULL;
 RuleHead = InitRuleNode(RuleHead);
 KillHead = InitRuleNode(KillHead);
 RuleHead = MakeRuleNet(RuleHead,FzHead,THead);
 GHead = (Gneuron *)malloc(sizeof(Gneuron));
 GHead->NextNode = NULL;
 GHead = InitGInput(GHead);
 GHead = ReadGneuron(GHead);
 ListAllTerm(RuleHead);
 /*PreConsistentChk(RuleHead,GHead);
 ModifyNnP(RuleHead,THead);
 DeleteRule(RuleHead,KillHead);
 CheckTest(RuleHead);*/
 /*ListKill(KillHead);*/
}

void ListAllTerm(RuleNode *RuleHead)
{
 FILE *OutFile;
 char OutFileName[FileNameMax];
 RuleNode *Rnow;
 NandP *Nnow;
 printf("please input the name of Term File : ");
 scanf("%s",OutFileName);
 OutFile = fopen(OutFileName,"w");
 Rnow = RuleHead;
 while(Rnow->NextNode != NULL)
  {
   Rnow = Rnow->NextNode;
   Nnow = Rnow->PremiseHead;
   fprintf(OutFile,"(%d)\n",Rnow->index);
   fprintf(OutFile,"Premise Part:\n");
   while(Nnow->NextNode != NULL)
    {
     Nnow = Nnow->NextNode;
     fprintf(OutFile,"%s = %s  Sn = %4.2f  Sp = %4.2f\n",
	     Nnow->variable, Nnow->term, Nnow->Sn, Nnow->Sp);
    }
   fprintf(OutFile,"Consequent Part:\n");
   fprintf(OutFile,"%s = %s  Sn = %4.2f  Sp = %4.2f\n\n",
	Rnow->consequent.variable,  Rnow->consequent.term,
	Rnow->consequent.Sn, Rnow->consequent.Sp);
  }
 fclose(OutFile);
}

void ListKill(RuleNode *KillHead)
{
 RuleNode *Rnow;
 printf("----------Killed Node----------\n");
 Rnow = KillHead;
 while(Rnow->NextNode != NULL)
  {
   Rnow = Rnow->NextNode;
   printf("Rule %d has been killed\n", Rnow->index);
  }
}

void DeleteRule(RuleNode *RuleHead,RuleNode *KillHead)
{
 DeleteRedRule(RuleHead,KillHead);
 DeleteConfRule(RuleHead,KillHead);
 DeleteSubsumRule(RuleHead,KillHead);
}

void DeleteSubsumRule(RuleNode *RuleHead,RuleNode *KillHead)
{
 RuleNode *Rnow;
 Inconsist *Inow, *Iprevious;
 int exist;
 Rnow = RuleHead;
 while(Rnow->NextNode != NULL)
  {
   Rnow = Rnow->NextNode;
   Inow = Rnow->InconHead;
   while(Inow->NextNode != NULL)
    {
     Iprevious = Inow;
     Inow = Inow->NextNode;
     exist = 0;
     if (Inow->InconType == A_type_subsume)
       {
	exist = FindSubsumeRule(Inow->RuleIndex,RuleHead);
	if (exist)
	  {
	   Rnow->Killed = 1;
	   RemoveMark(Inow->RuleIndex,Rnow->index,RuleHead);
	  }
        if (Inow->NextNode != NULL)
	  Iprevious->NextNode = Inow->NextNode;
	else
	  Iprevious->NextNode = NULL;
	free(Inow);
	Inow = Iprevious;
       }
     if (Inow->InconType == B_type_subsume)
       {
	exist = FindSubsumeRule(Inow->RuleIndex,RuleHead);
	if (exist)
	  AddKillMark(Inow->RuleIndex,Rnow->index,RuleHead);
	if (Inow->NextNode != NULL)
	  Iprevious->NextNode = Inow->NextNode;
	else
	  Iprevious->NextNode = NULL;
	free(Inow);
	Inow = Iprevious;
       }
    }
  }
 RealKill(RuleHead,KillHead);
}

void AddKillMark(int index,int RemoveIndex,RuleNode *RuleHead)
{
 RuleNode *Rnow;
 Inconsist *Iprevious, *Inow;
 Rnow = RuleHead;
 while(Rnow->index != index)
   Rnow = Rnow->NextNode;
 Rnow->Killed = 1;
 Inow = Rnow->InconHead;
 while(Inow->RuleIndex != RemoveIndex)
   {
    Iprevious = Inow;
    Inow = Inow->NextNode;
   }
 if (Inow->NextNode != NULL)
   Iprevious->NextNode = Inow->NextNode;
 else
   Iprevious->NextNode = NULL;
 free(Inow);
}

void RemoveMark(int index,int KillRuleIndex,RuleNode *RuleHead)
{
 RuleNode *Rnow;
 Inconsist *Inow, *Iprevious;
 Rnow = RuleHead;
 while(Rnow->index != index)
   Rnow = Rnow->NextNode;
 Inow = Rnow->InconHead;
 while(Inow->RuleIndex != KillRuleIndex)
  {
   Iprevious = Inow;
   Inow = Inow->NextNode;
  }
 if (Inow->NextNode != NULL)
   Iprevious->NextNode = Inow->NextNode;
 else
   Iprevious->NextNode = NULL;
 free(Inow);
}

int FindSubsumeRule(int index,RuleNode *RuleHead)
{
 int find=0;
 RuleNode *Rnow;
 Rnow = RuleHead;
 while((!find) && (Rnow->NextNode != NULL))
  {
   Rnow = Rnow->NextNode;
   if (Rnow->index == index)
     find = 1;
  }
 return(find);
}

void DeleteConfRule(RuleNode *RuleHead,RuleNode *KillHead)
{
 RuleNode *Rnow, *Rnow1;
 Inconsist *Inow, *Iprevious;
 int KillRnow1,find;
 Rnow = RuleHead;
 while(Rnow->NextNode != NULL)
  {
   Rnow = Rnow->NextNode;
   Inow = Rnow->InconHead;
   while(Inow->NextNode != NULL)
    {
     Iprevious = Inow;
     Inow = Inow->NextNode;
     if (Inow->InconType == conflict)
       {
	Rnow1 = RuleHead;
	find = 0;
	while((!find) && (Rnow1->NextNode != NULL))
	 {
	  Rnow1 = Rnow1->NextNode;
	  if (Rnow1->index == Inow->RuleIndex)
	    find = 1;
	 }
	if (find)
	  CmpAndMark(Rnow,Rnow1,conflict);
	if (Inow->NextNode != NULL)
	  Iprevious->NextNode = Inow->NextNode;
	else
	  Iprevious->NextNode = NULL;
	free(Inow);
	Inow = Iprevious;
       }
    }
  }
 RealKill(RuleHead,KillHead);
}

void DeleteRedRule(RuleNode *RuleHead,RuleNode *KillHead)
{
 RuleNode *Rnow, *Rnow1;
 Inconsist *Inow, *Iprevious;
 Rnow = RuleHead;
 while(Rnow->NextNode != NULL)
  {
   Rnow = Rnow->NextNode;
   Inow = Rnow->InconHead;
   while(Inow->NextNode != NULL)
    {
     Iprevious = Inow;
     Inow = Inow->NextNode;
     if (Inow->InconType == redundant)
       {
	Rnow1 = RuleHead;
	while(Rnow1->index != Inow->RuleIndex)
	  Rnow1 = Rnow1->NextNode;
	CmpAndMark(Rnow,Rnow1,redundant);
	if (Inow->NextNode != NULL)
	  Iprevious->NextNode = Inow->NextNode;
	else
	   Iprevious->NextNode = NULL;
	free(Inow);
	Inow = Iprevious;
       }
    }
  }
 RealKill(RuleHead,KillHead);
}

void RealKill(RuleNode *RuleHead,RuleNode *KillHead)
{
 RuleNode *Rnow, *Rprevious, *Know;
 Rnow = RuleHead;
 Know = KillHead;
 while(Know->NextNode != NULL)
   Know = Know->NextNode;
 while(Rnow->NextNode != NULL)
  {
   Rprevious = Rnow;
   Rnow = Rnow->NextNode;
   if (Rnow->Killed)
     {
      if (Rnow->NextNode != NULL)
	Rprevious->NextNode = Rnow->NextNode;
      else
	Rprevious->NextNode = NULL;
      Rnow->NextNode = NULL;
      Know->NextNode = Rnow;
      Know = Know->NextNode;
      Rnow = Rprevious;
     }
  }
}

void CmpAndMark(RuleNode *RNode, RuleNode *RNode1, int InconType)
{
 int PremResult, ConseqResult, KillRNode1=0;
 float CalRNode, CalRNode1;
 CalRNode = ParmI * RNode->Sn + ParmJ * RNode->Sp;
 CalRNode1 = ParmI * RNode1->Sn + ParmJ * RNode1->Sp;
 if (CalRNode > CalRNode1)
   PremResult = large;
 else
   {
    if (CalRNode == CalRNode1)
      PremResult = equal;
    else
      PremResult = small;
   }
 CalRNode = ParmI * RNode->consequent.Sn + ParmJ * RNode->consequent.Sp;
 CalRNode1 = ParmI * RNode1->consequent.Sn + ParmJ * RNode1->consequent.Sp;
 if (CalRNode > CalRNode1)
   ConseqResult = large;
 else
   {
    if (CalRNode == CalRNode1)
      ConseqResult = equal;
    else
      ConseqResult = small;
   }
 if ((PremResult == equal) && (ConseqResult == equal))
   {
    KillRNode1 = DecideByUser(RNode,RNode1,InconType);
    if (KillRNode1)
       RNode1->Killed = 1;
    else
       RNode->Killed = 1;
   }
 else
   if ((PremResult >= equal) && (ConseqResult >= equal))
      RNode1->Killed = 1;
   else
     if ((PremResult <= equal) && (ConseqResult <= equal))
	RNode->Killed = 1;
     else
       {
	KillRNode1 = DecideByUser(RNode,RNode1,InconType);
	if (KillRNode1)
	   RNode1->Killed = 1;
	else
	   RNode->Killed = 1;
       }
 TakeRecordOut(RNode,RNode1);
}

int DecideByUser(RuleNode *RNode,RuleNode *RNode1,int InconType)
{
 int CorrectInput=0,input;
 printf("Rule(%d) and Rule(%d) are ",RNode->index,RNode1->index);
 if (InconType == redundant)
   printf("redundant.\n\n");
 else
   printf("conflict.\n\n");
 printf("The support pair of premise of Rule(%d) are ",RNode->index);
 printf("Sn = %5.3f  Sp = %5.3f\n",RNode->Sn,RNode->Sp);
 printf("The support pair of consequent of Rule(%d) are ",RNode->index);
 printf("Sn = %5.3f  Sp = %5.3f\n\n",
	 RNode->consequent.Sn,RNode->consequent.Sp);
 printf("The support pair of premise of Rule(%d) are ",RNode1->index);
 printf("Sn = %5.3f  Sp = %5.3f\n",RNode1->Sn,RNode1->Sp);
 printf("The support pair of consequent of Rule(%d) are ",RNode1->index);
 printf("Sn = %5.3f  Sp = %5.3f\n\n",
	 RNode1->consequent.Sn,RNode1->consequent.Sp);
 while(!CorrectInput)
  {
   printf("Which rule do you decide to delete ? ");
   scanf("%d",&input);
   if ((input != RNode->index) && (input != RNode1->index))
     printf("\nInput error.\n");
   else
     CorrectInput = 1;
  }
 if (input == RNode->index)
   return(0);
 else
   return(1);
}

void TakeRecordOut(RuleNode *RNode,RuleNode *RNode1)
{
 int index;
 Inconsist *Inow, *Iprevious;
 index = RNode->index;
 Inow = RNode1->InconHead;
 while(Inow->RuleIndex != index)
  {
   Iprevious = Inow;
   Inow = Inow->NextNode;
  }
 if (Inow->NextNode != NULL)
   Iprevious->NextNode = Inow->NextNode;
 else
   Iprevious->NextNode = NULL;
 free(Inow);
}

void ModifyNnP(RuleNode *RuleHead,TempNP *THead)
{
 RuleNode *Rnow;
 float NPPremRatio,NPConseqRatio;
 Rnow = RuleHead;
 while(Rnow->NextNode != NULL)
  {
   Rnow = Rnow->NextNode;
   RedMdfy(Rnow,RuleHead,THead);
   ConfMdfy(Rnow,RuleHead,THead);
  }
 NPadjust(RuleHead,THead);
}

void NPadjust(RuleNode *RuleHead,TempNP *THead)
{
 RuleNode *Rnow;
 TempNP *Tnow;
 Rnow = RuleHead;
 while(Rnow->NextNode != NULL)
  {
   Rnow = Rnow->NextNode;
   Tnow = THead;
   while(Tnow->index != Rnow->index)
     Tnow = Tnow->NextNode;
   SnAdjust(Rnow,Tnow);
   SpAdjust(Rnow,Tnow);
  }
}

void SnAdjust(RuleNode *RNode,TempNP *TNode)
{
 RNode->Sn += TNode->ForSumOfAdd;
 if (RNode->Sn > 1.0)
   RNode->Sn = 1.0;
 if (RNode->Sn > RNode->Sp)
   RNode->Sp = RNode->Sn;
 RNode->consequent.Sn += TNode->BackSumOfAdd;
 if (RNode->consequent.Sn > 1.0)
   RNode->consequent.Sn = 1.0;
 if (RNode->consequent.Sn > RNode->consequent.Sp)
   RNode->consequent.Sp = RNode->consequent.Sn;
}

void SpAdjust(RuleNode *RNode,TempNP *TNode)
{
 RNode->Sp -= TNode->ForSumOfSub;
 if (RNode->Sp < 0.0)
   RNode->Sp = 0.0;
 if (RNode->Sp < RNode->Sn)
   RNode->Sn = RNode->Sp;
 RNode->consequent.Sp -= TNode->BackSumOfSub;
 if (RNode->consequent.Sp < 0.0)
   RNode->consequent.Sp = 0.0;
 if (RNode->consequent.Sp < RNode->consequent.Sn)
   RNode->consequent.Sn = RNode->consequent.Sp;
}

void RedMdfy(RuleNode *RNode,RuleNode *RuleHead,TempNP *THead)
{
 Inconsist *Inow;
 RuleNode *Rnow;
 Inow = RNode->InconHead;
 while(Inow->NextNode != NULL)
  {
   Inow = Inow->NextNode;
   if ((Inow->InconType == redundant) && (Inow->RuleIndex > RNode->index))
     {
      Rnow = RuleHead;
      while(Rnow->index != Inow->RuleIndex)
	Rnow = Rnow->NextNode;
      AddRedSum(RNode,Rnow,THead);
     }
  }
}

void AddRedSum(RuleNode *Rfix,RuleNode *Rcmp,TempNP *THead)
{
 TempNP *Tnow, *Tfix, *Tcmp;
 Tnow = THead;
 while(Tnow->index != Rfix->index)
   Tnow = Tnow->NextNode;
 Tfix = Tnow;
 Tnow = THead;
 while(Tnow->index != Rcmp->index)
   Tnow = Tnow->NextNode;
 Tcmp = Tnow;
 if ((Rfix->Sn + Rcmp->Sn) > 0.0)
   {
     Tfix->ForSumOfAdd += fabs(Rfix->Sn - Rcmp->Sn) * Rfix->Sn /
			  (Rfix->Sn + Rcmp->Sn);
     Tcmp->ForSumOfAdd += fabs(Rfix->Sn - Rcmp->Sn) * Rcmp->Sn /
			  (Rfix->Sn + Rcmp->Sn);
   }
 if ((Rfix->consequent.Sn + Rcmp->consequent.Sn) > 0.0)
   {
    Tfix->BackSumOfAdd += fabs(Rfix->consequent.Sn - Rcmp->consequent.Sn) *
			  Rfix->consequent.Sn /
			  (Rfix->consequent.Sn + Rcmp->consequent.Sn);
    Tcmp->BackSumOfAdd += fabs(Rfix->consequent.Sn - Rcmp->consequent.Sn) *
			  Rcmp->consequent.Sn /
			  (Rfix->consequent.Sn + Rcmp->consequent.Sn);
   }
}

void ConfMdfy(RuleNode *RNode,RuleNode *RuleHead,TempNP *THead)
{
 Inconsist *Inow;
 RuleNode *Rnow;
 Inow = RNode->InconHead;
 while(Inow->NextNode != NULL)
  {
   Inow = Inow->NextNode;
   if ((Inow->InconType == conflict) && (Inow->RuleIndex > RNode->index))
     {
      Rnow = RuleHead;
      while(Rnow->index != Inow->RuleIndex)
	Rnow = Rnow->NextNode;
      AddConfSum(RNode,Rnow,THead);
     }
  }
}

void AddConfSum(RuleNode *Rfix,RuleNode *Rcmp,TempNP *THead)
{
 TempNP *Tnow, *Tfix, *Tcmp;
 Tnow = THead;
 while(Tnow->index != Rfix->index)
   Tnow = Tnow->NextNode;
 Tfix = Tnow;
 Tnow = THead;
 while(Tnow->index != Rcmp->index)
   Tnow = Tnow->NextNode;
 Tcmp = Tnow;
 if ((Rfix->Sp + Rcmp->Sp) > 0.0)
   {
    Tfix->ForSumOfSub += fabs(Rfix->Sp - Rcmp->Sp) * Rcmp->Sp /
			 (Rfix->Sp + Rcmp->Sp);
    Tcmp->ForSumOfSub += fabs(Rfix->Sp - Rcmp->Sp) * Rfix->Sp /
			 (Rfix->Sp + Rcmp->Sp);
   }
 if ((Rfix->consequent.Sp + Rcmp->consequent.Sp) > 0.0)
   {
    Tfix->BackSumOfSub += fabs(Rfix->consequent.Sp - Rcmp->consequent.Sp) *
			  Rcmp->consequent.Sp /
			  (Rfix->consequent.Sp + Rcmp->consequent.Sp);
    Tcmp->BackSumOfAdd += fabs(Rfix->consequent.Sp - Rcmp->consequent.Sp) *
			  Rfix->consequent.Sp /
			  (Rfix->consequent.Sp + Rcmp->consequent.Sp);
   }
}

void GneuronTest(Gneuron *GHead)
{
 Gneuron *Gnow;
 GInput *Inow;
 Gnow = GHead;
 while(Gnow->NextNode != NULL)
  {
   Gnow = Gnow->NextNode;
   printf("%s\n",Gnow->name);
   Inow = Gnow->GIpHead;
   while(Inow->NextNode != NULL)
    {
     Inow = Inow->NextNode;
     printf("%s ",Inow->IpVar);
    }
   printf("\n");
  }
}

void CheckTest(RuleNode *RuleHead)
{
 FILE *OutFile;
 char OutFileName[FileNameMax];
 RuleNode *Rnow;
 NandP *prem;
 Inconsist *incon;
 int test;
 printf("Please input the name of Output File: ");
 scanf("%s",OutFileName);
 OutFile = fopen(OutFileName,"w");
 Rnow = RuleHead;
 while(Rnow->NextNode != NULL)
  {
   Rnow = Rnow->NextNode;
   fprintf(OutFile,"\n(%d)\n",Rnow->index);
   fprintf(OutFile,"  Premise Part:\n");
   prem = Rnow->PremiseHead;
   while(prem->NextNode != NULL)
    {
     prem = prem->NextNode;
     fprintf(OutFile,"%s:%s  ",prem->variable,prem->term);
    }
   fprintf(OutFile,"\nSn=%5.3f  ",Rnow->Sn);
   fprintf(OutFile,"Sp=%5.3f",Rnow->Sp);
   fprintf(OutFile,"\n  Consequent Part:\n");
   fprintf(OutFile,"%s:%s\n",Rnow->consequent.variable,Rnow->consequent.term);
   fprintf(OutFile,"Sn=%5.3f  ",Rnow->consequent.Sn);
   fprintf(OutFile,"Sp=%5.3f\n",Rnow->consequent.Sp);
   incon = Rnow->InconHead;
   if (incon->NextNode != NULL)
     fprintf(OutFile,"  Inconsistent with:\n");
   while(incon->NextNode != NULL)
    {
     incon = incon->NextNode;
     fprintf(OutFile,"%d:",incon->RuleIndex);
     switch(incon->InconType)
      {
       case redundant:
	 fprintf(OutFile,"redundant ");
	 break;
       case conflict:
	 fprintf(OutFile,"conflict ");
	 break;
       case A_type_subsume:
	 fprintf(OutFile,"A_type_subsume ");
	 break;
       case B_type_subsume:
	 fprintf(OutFile,"B_type_subsume ");
      }
    }
  }
 fclose(OutFile);
}

void PreConsistentChk(RuleNode *RuleHead,Gneuron *GHead)
{
 RuleNode *Rnow, *Rcmp;
 int ChkResult;
 Rnow = RuleHead;
 while(Rnow->NextNode != NULL)
  {
   Rcmp = Rnow = Rnow->NextNode;
   while(Rcmp->NextNode != NULL)
    {
     Rcmp = Rcmp->NextNode;
     if(!strcmp(Rnow->consequent.variable,Rcmp->consequent.variable))
       {
	ChkResult = ConsistentChk(Rnow,Rcmp,GHead);
	if (ChkResult != consistent)
	  RecordIncon(Rnow,Rcmp,ChkResult);
       }
    }
  }
}

void RecordIncon(RuleNode *FixNode,RuleNode *CmpNode,int ChkResult)
{
 Inconsist *Fnow, *Cnow, *Inew;
 Fnow = FixNode->InconHead;
 Cnow = CmpNode->InconHead;
 while(Fnow->NextNode != NULL)
   Fnow = Fnow->NextNode;
 Inew = (Inconsist *)malloc(sizeof(Inconsist));
 Inew->RuleIndex = CmpNode->index;
 Inew->InconType = ChkResult;
 Inew->NextNode = NULL;
 Fnow->NextNode = Inew;
 while(Cnow->NextNode != NULL)
   Cnow = Cnow->NextNode;
 Inew = (Inconsist *)malloc(sizeof(Inconsist));
 Inew->RuleIndex = FixNode->index;
 if (ChkResult == A_type_subsume)
     Inew->InconType = B_type_subsume;
  else
     {
      if (ChkResult == B_type_subsume)
	 Inew->InconType = A_type_subsume;
       else
	 Inew->InconType = ChkResult;
     }
 Inew->NextNode = NULL;
 Cnow->NextNode = Inew;
}

int ConsistentChk(RuleNode *FixNode,RuleNode *CmpNode,Gneuron *GHead)
{
 int ChkResult;
 NandP *FixPremHead, *CmpPremHead;
 Gneuron *Gnow;
 GInput *GIHead;
 Gnow = GHead;
 FixPremHead = FixNode->PremiseHead;
 CmpPremHead = CmpNode->PremiseHead;
 if(!strcmp(FixNode->consequent.term,CmpNode->consequent.term))
      ChkResult = RedSubAnalysis(FixPremHead,CmpPremHead);
  else
      {
       while (strcmp(FixNode->consequent.variable,Gnow->name))
	    Gnow = Gnow->NextNode;
       GIHead = Gnow->GIpHead;
       ChkResult = ConfAnalysis(FixPremHead,CmpPremHead,GIHead);
      }
 return(ChkResult);
}

int RedSubAnalysis(NandP *FixPremHead,NandP *CmpPremHead)
{
 NandP *Fnow, *Cnow;
 int cntrF=0, cntrC=0, ChkResult;
 Fnow = FixPremHead;
 Cnow = CmpPremHead;
 while(Fnow->NextNode != NULL)
  {
   Fnow = Fnow->NextNode;
   cntrF++;
  }
 while(Cnow->NextNode != NULL)
  {
   Cnow = Cnow->NextNode;
   cntrC++;
  }
 if (cntrF > cntrC)
  {
   ChkResult = AdvanceChk(FixPremHead,CmpPremHead);
   if (ChkResult)
     ChkResult = A_type_subsume;
  }
 else
   {
    if (cntrF < cntrC)
      {
       ChkResult = AdvanceChk(CmpPremHead,FixPremHead);
       if (ChkResult)
	 ChkResult = B_type_subsume;
      }
    else
      {
       ChkResult = AdvanceChk(FixPremHead,CmpPremHead);
       if (ChkResult)
	 ChkResult = redundant;
      }
   }
 return(ChkResult);
}

int AdvanceChk(NandP *MorePrem, NandP *LessPrem)
{
 NandP *Mnow, *Lnow;
 int match;
 Lnow = LessPrem;
 while(Lnow->NextNode != NULL)
  {
   Lnow = Lnow->NextNode;
   match = 0;
   Mnow = MorePrem;
   while((Mnow->NextNode != NULL) && (!match))
    {
     Mnow = Mnow->NextNode;
     if(!strcmp(Lnow->variable,Mnow->variable) &&
	!strcmp(Lnow->term,Mnow->term))
      {
       match = 1;
       break;
      }
    }
   if (!match)
     return(match);
  }
 return(match);
}

int ConfAnalysis(NandP *FixPremHead,NandP *CmpPremHead,GInput *GIHead)
{
 int ChkResult,match;
 FindTerm *Ffind,*Cfind;
 GInput *Inow;
 Inow = GIHead;
 while(Inow->NextNode != NULL)
  {
   Inow = Inow->NextNode;
   match = 0;
   Ffind = FindVar(Inow,FixPremHead);
   Cfind = FindVar(Inow,CmpPremHead);
   if(Ffind->find && Cfind->find)
     {
      if(!strcmp(Ffind->term,Cfind->term))
	 match = 1;
     }
   else
      match = 1;
   if(!match)
     return(consistent);
  }
 return(conflict);
}

FindTerm *FindVar(GInput *Inow,NandP *NPNode)
{
 FindTerm *result;
 NandP *NPnow;
 result = (FindTerm *)malloc(sizeof(FindTerm));
 result->find = 0;
 NPnow = NPNode;
 while(NPnow->NextNode != NULL)
  {
   NPnow = NPnow->NextNode;
   if(!strcmp(NPnow->variable,Inow->IpVar))
      {
       result->find = 1;
       strcpy(result->term,NPnow->term);
      }
  }
 return(result);
}

Gneuron *ReadGneuron(Gneuron *GHead)
{
 FILE *GFile;
 char GFileName[FileNameMax];
 Gneuron *Gprevious, *Gnow, *Gnew;
 GInput *IHead;
 int TermNum, cntr;
 Gnow = GHead;
 printf("Please input G_neuron file: ");
 scanf("%s",GFileName);
 GFile = fopen(GFileName,"r");
 while(!feof(GFile))
  {
   Gprevious = Gnow;
   Gnew = (Gneuron *)malloc(sizeof(Gneuron));
   Gnew->GIpHead = (GInput *)malloc(sizeof(GInput));
   IHead = Gnew->GIpHead;
   IHead->NextNode = NULL;
   fscanf(GFile,"%s",Gnew->name);
   fscanf(GFile,"%d",&TermNum);
   for(cntr=1;cntr<=TermNum;cntr++)
      ReadGInput(GFile,IHead);
   Gnow->NextNode = Gnew;
   Gnew->NextNode = NULL;
   Gnow = Gnew;
  }
 Gprevious->NextNode = NULL;
 free(Gnow);
 fclose(GFile);
 return(GHead);
}

void ReadGInput(FILE *GFile,GInput *IHead)
{
 GInput *Gnow, *Gnew;
 Gnow = IHead;
 while(Gnow->NextNode != NULL)
      Gnow = Gnow->NextNode;
 Gnew = (GInput *)malloc(sizeof(GInput));
 Gnow->NextNode = Gnew;
 Gnew->NextNode = NULL;
 fscanf(GFile,"%s",Gnew->IpVar);
}

Gneuron *InitGInput(Gneuron *GHead)
{
 static GInput *InitGNext;
 GHead->GIpHead = (GInput *)malloc(sizeof(GInput));
 InitGNext = GHead->GIpHead;
 InitGNext->NextNode = NULL;
 return(GHead);
}

FuzzyTerm *InitFuzzyNode(FuzzyTerm *FzHead)
{
 static FuzzyNode *InitFuzzyNext;
 FzHead->FuzzyHead = (FuzzyNode *)malloc(sizeof(FuzzyNode));
 InitFuzzyNext = FzHead->FuzzyHead;
 InitFuzzyNext->NextNode = NULL;
 return(FzHead);
}

RuleNode *InitRuleNode(RuleNode *Head)
{
 static NandP *InitPremiseNext;
 static Inconsist *InitInconsist;
 Head->PremiseHead = (NandP *)malloc(sizeof(NandP));
 InitPremiseNext = Head->PremiseHead;
 InitPremiseNext->NextNode = NULL;
 Head->InconHead = (Inconsist *)malloc(sizeof(Inconsist));
 InitInconsist = Head->InconHead;
 InitInconsist->NextNode = NULL;
 return(Head);
}

void TestFuzzySet(FuzzyTerm *FzHead)
{
 FuzzyTerm *Fnow;
 FuzzyNode *Znow;
 Fnow = FzHead;
 while(Fnow->NextNode != NULL)
  {
   Fnow = Fnow->NextNode;
   printf("%s ",Fnow->variable);
   Znow = Fnow->FuzzyHead;
   while(Znow->NextNode != NULL)
    {
     Znow = Znow->NextNode;
     printf("%s\n",Znow->term);
     printf("m=%f ",Znow->m);
     printf("n=%f ",Znow->n);
     printf("alfa=%f ",Znow->alfa);
     printf("beta=%f\n",Znow->beta);
    }
  }
}

FuzzyTerm *ReadFuzzySet(FuzzyTerm *FzHead)
{
 FILE *FuzzyFile;
 char FuzzyFileName[FileNameMax];
 FuzzyTerm *Fprevious, *Fnow, *Fnew;
 FuzzyNode *FHead;
 int TermNum,cntr;
 Fnow = FzHead;
 printf("Please input the name of fuzzy set: ");
 scanf("%s",FuzzyFileName);
 FuzzyFile = fopen(FuzzyFileName,"r");
 while(!feof(FuzzyFile))
   {
    Fprevious = Fnow;
    Fnew = (FuzzyTerm *)malloc(sizeof(FuzzyTerm));
    Fnew->FuzzyHead = (FuzzyNode *)malloc(sizeof(FuzzyNode));
    FHead = Fnew->FuzzyHead;
    FHead->NextNode = NULL;
    fscanf(FuzzyFile,"%s",Fnew->variable);
    fscanf(FuzzyFile,"%d",&TermNum);
    for(cntr=1;cntr<=TermNum;cntr++)
       ReadFuzzyTerm(FuzzyFile,FHead);
    Fnow->NextNode = Fnew;
    Fnew->NextNode = NULL;
    Fnow = Fnew;
   }
 Fprevious->NextNode = NULL;
 free(Fnow);
 fclose(FuzzyFile);
 return(FzHead);
}

void ReadFuzzyTerm(FILE *FuzzyFile,FuzzyNode *FHead)
{
 FuzzyNode *Fnow,*Fnew;
 Fnow = FHead;
 while(Fnow->NextNode != NULL)
     Fnow = Fnow->NextNode;
 Fnew = (FuzzyNode *)malloc(sizeof(FuzzyNode));
 Fnow->NextNode = Fnew;
 Fnew->NextNode = NULL;
 fscanf(FuzzyFile,"%s",Fnew->term);
 fscanf(FuzzyFile,"%f",&Fnew->m);
 fscanf(FuzzyFile,"%f",&Fnew->n);
 fscanf(FuzzyFile,"%f",&Fnew->alfa);
 fscanf(FuzzyFile,"%f",&Fnew->beta);
}

RuleNode *MakeRuleNet(RuleNode *RuleHead,FuzzyTerm *FzHead,TempNP *THead)
{
 FILE *RuleFile;
 TempNP *Tprevious, *Tnow, *Tnew;
 RuleNode *Rprevious, *Rnow, *Rnew;
 Inconsist *IHead;
 int NumOfTerm,IndexCntr=1;
 char RuleFileName[FileNameMax];
 Rnow = RuleHead;
 Tnow = THead;
 printf("Please input the name of rule file: ");
 scanf("%s",RuleFileName);
 RuleFile = fopen(RuleFileName,"r");
 while(!feof(RuleFile))
   {
    Rprevious = Rnow;
    Tprevious = Tnow;
    fscanf(RuleFile,"%d",&NumOfTerm);
    Rnew = (RuleNode *)malloc(sizeof(RuleNode));
    Rnew->index = IndexCntr;
    Rnew->Killed = 0;
    Rnew = ReadTerm(RuleFile,Rnew,FzHead,NumOfTerm);
    Rnew->Sn = CalculateSn(Rnew);
    Rnew->Sp = CalculateSp(Rnew);
    Rnew->InconHead = (Inconsist *)malloc(sizeof(Inconsist));
    IHead = Rnew->InconHead;
    IHead->NextNode = NULL;
    Rnow->NextNode = Rnew;
    Rnew->NextNode = NULL;
    Rnow = Rnow->NextNode;
    Tnew = (TempNP *)malloc(sizeof(TempNP));
    Tnew = InitTnew(Tnew,IndexCntr);
    Tnow->NextNode = Tnew;
    Tnow = Tnow->NextNode;
    IndexCntr++;
   }
 Rprevious->NextNode = NULL;
 free(Rnow);
 Tprevious->NextNode = NULL;
 free(Tnow);
 fclose(RuleFile);
 return(RuleHead);
}

TempNP *InitTnew(TempNP *TNode,int cntr)
{
 TNode->index = cntr;
 TNode->NextNode = NULL;
 TNode->ForSumOfAdd = 0.0;
 TNode->ForSumOfSub = 0.0;
 TNode->BackSumOfAdd = 0.0;
 TNode->BackSumOfSub = 0.0;
 return(TNode);
}

float CalculateSn(RuleNode *RNode)
{
 NandP *Pnow;
 float Sn=1.0;
 Pnow = RNode->PremiseHead;
 while(Pnow->NextNode != NULL)
  {
   Pnow = Pnow->NextNode;
   if (Pnow->Sn < Sn)
     Sn = Pnow->Sn;
  }
 return(Sn);
}

float CalculateSp(RuleNode *RNode)
{
 NandP *Pnow;
 float Sp=0.0;
 Pnow = RNode->PremiseHead;
 while(Pnow->NextNode != NULL)
  {
   Pnow = Pnow->NextNode;
   if (Pnow->Sp > Sp)
     Sp = Pnow->Sp;
  }
 return(Sp);
}

RuleNode *ReadTerm(FILE *RuleFile,RuleNode *RNode,FuzzyTerm *FzHead,
		   int NumOfTerm)
{
 FuzzyNum EachTerm;
 int cntr;
 NandP *PHead,Conseq;
 RNode->PremiseHead = (NandP *)malloc(sizeof(NandP));
 PHead = RNode->PremiseHead;
 PHead->NextNode = NULL;
 for(cntr=1; cntr<=(NumOfTerm-1); cntr++)
     {
       fscanf(RuleFile,"%s",EachTerm.variable);
       fscanf(RuleFile,"%f",&EachTerm.m);
       fscanf(RuleFile,"%f",&EachTerm.n);
       fscanf(RuleFile,"%f",&EachTerm.alfa);
       fscanf(RuleFile,"%f",&EachTerm.beta);
       TranNnP(EachTerm,PHead,FzHead);
     }
 fscanf(RuleFile,"%s",EachTerm.variable);
 fscanf(RuleFile,"%f",&EachTerm.m);
 fscanf(RuleFile,"%f",&EachTerm.n);
 fscanf(RuleFile,"%f",&EachTerm.alfa);
 fscanf(RuleFile,"%f",&EachTerm.beta);
 strcpy(RNode->consequent.variable,EachTerm.variable);
 Conseq = TranConTerm(EachTerm,RNode->consequent,FzHead);
 strcpy(RNode->consequent.term,Conseq.term);
 RNode->consequent.Sn = Conseq.Sn;
 RNode->consequent.Sp = Conseq.Sp;
 RNode->consequent.NextNode = NULL;
 return(RNode);
}

NandP TranConTerm(FuzzyNum EachTerm,NandP Conseq,FuzzyTerm *FzHead)
{
 NandP result;
 TermNandP ThreeInfo;
 FuzzyTerm *Fnow;
 FuzzyNode *ZNode;
 int overflow=0;
 Fnow = FzHead;
 while(strcmp(Fnow->variable,Conseq.variable))
   {
    if(Fnow->NextNode != NULL)
      Fnow = Fnow->NextNode;
    else
     {
      overflow = 1;
      break;
     }
   }
 if(!overflow)
  {
   ZNode = Fnow->FuzzyHead;
   ThreeInfo = TermNnP(EachTerm,ZNode);
   strcpy(result.term,ThreeInfo.term);
   result.Sn = ThreeInfo.Sn;
   result.Sp = ThreeInfo.Sp;
  }
 return(result);
}

void TranNnP(FuzzyNum EachTerm,NandP *PHead,FuzzyTerm *FzHead)
{
 NandP *Pnow,*Pnew;
 FuzzyTerm *Fnow;
 FuzzyNode *ZNode;
 TermNandP result;
 Pnow = PHead;
 while(Pnow->NextNode != NULL)
   Pnow = Pnow->NextNode;
 Pnew = (NandP *)malloc(sizeof(NandP));
 Pnow->NextNode = Pnew;
 Pnew->NextNode = NULL;
 strcpy(Pnew->variable,EachTerm.variable);
 Fnow = FzHead;
 while(strcmp(Pnew->variable,Fnow->variable))
   {
    if (Fnow->NextNode != NULL)
      Fnow = Fnow->NextNode;
    else
      return;
   }
 ZNode = Fnow->FuzzyHead;
 result = TermNnP(EachTerm,ZNode);
 Pnew->Sn = result.Sn;
 Pnew->Sp = result.Sp;
 strcpy(Pnew->term,result.term);
}

TermNandP TermNnP(FuzzyNum Term,FuzzyNode *ZHead)
{
 TermNandP result;
 FuzzyNode *Znow;
 float Sn,Sp,Talfa,Tbeta,Zalfa,Zbeta,denominator,numerator,BestResult=0,
       TempResult;
 result.Sn = 0.0;
 result.Sp = 0.0;
 Znow = ZHead;
 if ((Term.m == Term.n) && (Term.alfa == 0.0) && (Term.beta == 0.0))
   {
    if (Term.m == 0.0)
      Term.n = 0.05;
    else
      {
       if (Term.n == 1.0)
	 Term.m = 0.95;
       else
	{
	 Term.m -= 0.025;
	 Term.n += 0.025;
	}
      }
   }
 Talfa = Term.m - Term.alfa;
 Tbeta = Term.n + Term.beta;
 while(Znow->NextNode != NULL)
  {
   Znow = Znow->NextNode;
   Zalfa = Znow->m - Znow->alfa;
   Zbeta = Znow->n + Znow->beta;
   if (((Talfa <= Zalfa) && (Tbeta <= Zalfa)) ||
       ((Zalfa <= Talfa) && (Zbeta <= Talfa)))
     Sn = Sp = 0;
   else
     {
      denominator = FindDenominator(Talfa,Tbeta,Zalfa,Zbeta);
      numerator = FindNumerator(Talfa,Tbeta,Zalfa,Zbeta);
      Sp = numerator / denominator;
      if (((Term.m <= Znow->m) && (Term.n <= Znow->m)) ||
	  ((Znow->m <= Term.m) && (Znow->n <= Term.m)))
	Sn = 0;
      else
	{
	 numerator = FindNumerator(Term.m,Term.n,Znow->m,Znow->n);
	 Sn = numerator / denominator;
	}
     }
   TempResult = ParmP * Sn + ParmQ * Sp;
   if (TempResult > BestResult)
     {
      BestResult = TempResult;
      result.Sn = Sn;
      result.Sp = Sp;
      strcpy(result.term,Znow->term);
     }
  }
 return(result);
}

float FindDenominator(float x1,float x2,float x3,float x4)
{
 float CmpArray[4],temp,result;
 int cntr,cntr1;
 CmpArray[0] = x1;
 CmpArray[1] = x2;
 CmpArray[2] = x3;
 CmpArray[3] = x4;
 for(cntr=0;cntr<=2;cntr++)
  for(cntr1=cntr+1;cntr1<=3;cntr1++)
   if (CmpArray[cntr1] > CmpArray[cntr])
     {
      temp = CmpArray[cntr1];
      CmpArray[cntr1] = CmpArray[cntr];
      CmpArray[cntr] = temp;
     }
 result = CmpArray[0] - CmpArray[3];
 return(result);
}

float FindNumerator(float x1,float x2,float x3,float x4)
{
 float CmpArray[4],temp,result;
 int cntr,cntr1;
 CmpArray[0] = x1;
 CmpArray[1] = x2;
 CmpArray[2] = x3;
 CmpArray[3] = x4;
 for(cntr=0;cntr<=2;cntr++)
  for(cntr1=cntr+1;cntr1<=3;cntr1++)
   if (CmpArray[cntr1] > CmpArray[cntr])
     {
      temp = CmpArray[cntr1];
      CmpArray[cntr1] = CmpArray[cntr];
      CmpArray[cntr] = temp;
     }
 result = CmpArray[1] - CmpArray[2];
 return(result);
}

