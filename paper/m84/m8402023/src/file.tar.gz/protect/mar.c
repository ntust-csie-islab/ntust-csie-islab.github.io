/* **********************************
   Program : KBFNN with ICE/RID  Rev: NVV.C 
   version : 1.0
   Author : Shuan-Hao Wu
   Date: Jun, 29, 1996
   ********************************** */
/* A modified version of KBFNN in ~m8202004/v50/vv/kbfnn.m.c
   Fuzzy target is used */
#include <fcntl.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#define maxlay 8
#define maxnod 200
#define maxwei 1
#define max 600
#define FileNameMax 10

int r_no,g_no,g_max;  /* for rule checking */
int pg_no,pg_max;     /* for pattern clustering */
int laynum=0,patnum=0,tranum,tstnum;/*lay num.,pattern num.,training pattern 
					num., and test pattern number*/
int seed,no_pat,noepcoh,no_link;/* random seed, no of pattern, 
				no of epcoh, no of connection link*/
int tno_link,tlaynods[maxnod];   /* for temp links */
int first[maxnod],laynods[maxnod],patodr[max],bg_fg=0;/*bg_fg=1 for bg */
int sc_no[maxlay][maxnod];
int conflist[maxnod][40];       /* list of conflict rules */
float goal,sim,av_sim,av_sim2;
char buff[512];
char netfile[12],wfile[12],bfile[12],chkfile[12],trafile[12],patfile[12],
	rep_file[12],cwfile[12];
float lrate,lr_con,lr_pre,momentum,threshold,lambda=1.0,delta=1.0;
float outm[maxlay][maxnod],outn[maxlay][maxnod],outa[maxlay][maxnod],outb[maxlay][maxnod];
float pata[maxnod][max],patb[maxnod][max],patm[maxnod][max],
      patn[maxnod][max],pattagm[maxnod][max],pattagn[maxnod][max],
      pattaga[maxnod][max],pattagb[maxnod][max];
float gpata[maxnod][max],gpatb[maxnod][max],gpatm[maxnod][max],
      gpatn[maxnod][max],gpattagm[maxnod][max],gpattagn[maxnod][max],
      gpattaga[maxnod][max],gpattagb[maxnod][max];      
float errec[max];

char cflag[max];
int lmode,sfact;
long scount=0;

struct CT_NOD /*network's connection structure*/
{
  struct CT_NOD *next;
  int ct_id;
};
typedef struct CT_NOD ct_node;

/*declaration head pointer for each node*/
ct_node *ct_head[maxlay][maxnod], *ct_tail[maxlay][maxnod];
ct_node *tct_head[maxlay][maxnod], *tct_tail[maxlay][maxnod];

/*declaration connection table structure*/
struct ct
  {
    int lh,head,lt,tail;/* lh: lay_no of connection head, head: node_no of connection head,
			   lt: lay_no of connection tail, tail: node_no od connection tail*/ 
    float cm,cn,ca,cb; /*LR_typed fuzzy weights and current similarity_overlap_cofficient*/
   };	/* 4 */
struct ct cotab[max];
struct ct tmtab[max];

struct t_table {
  int id;
  float value;
};  
typedef struct t_table table;

struct f_set {
  int no_set;
  float lr[maxnod][4]; 
};  
typedef struct f_set fuzzy_set;

struct tm *newtime;
long ltime;
float p1=1.5; /* importance factor of m */
int debug_flag=0;
/* definition of default fuzzy sets */
fuzzy_set fmodel[2]={{3,{{0,0.1,0,0.2},{0.4,0.6,0.2,0.2},{0.9,1,0.2,0}}},
                     {5,{{0,0.05,0,0.1},{0.2,0.3,0.1,0.1},{0.45,0.55,0.1,0.1},
                        {0.7,0.8,0.1,0.1},{0.95,1,0.1,0}}}};
struct t_rule
{
	int layer,node;
	float m,n,a,b;
	struct t_rule *next;
};
typedef struct t_rule RULE;
RULE *premise[maxnod], *conclusion[maxnod];
RULE *gcpre[maxnod],*gccon[maxnod];
int gcact[maxnod],tmgcact[maxnod];    /* active flag of each group */
struct t_group
{
	int number;
	struct t_group *next;
};
typedef struct t_group GROUP;
GROUP *group[maxnod];

static int lcompare(i,j)
struct ct *i,*j;
{
  return(i->lh<j->lh||(i->lh=j->lh&&i->head<j->head));
}

static int tcompare(i,j)
table *i,*j;
{
  return(i->value<j->value);
}

/* The main program Jan. 1995 */
main()
/*int argc;
char **argv[];*/
{
	int i,j,k,loop=0;
	float accuracy;
	char select;
	time(&ltime);
	newtime=gmtime(&ltime);
	i=newtime->tm_sec;
	j=newtime->tm_min;
	k=newtime->tm_hour;
	seed = i*i+j*k+1995;
	srand(seed);
        for (i=1;i<maxnod;i++) {
          conflist[i][0]=0; /* number of members */
          conflist[i][1]=0; /* next member */
	}  
	init_weights();
	do
	{
		printf("\n");
		printf("**********************\n");
		printf("*    NVV Rev 1.0     *\n");
		printf("*    main menu       *\n");
		printf("**********************\n");
		printf("1. load file\n");
		printf("2. save file\n");
		printf("3. learning\n");
		printf("4. test\n");
		printf("5. initialization\n");
		printf("6. reset weights\n");
		printf("7. set parameters\n");
		printf("8. on-line test\n");
		printf("9. building training data\n");
		printf("0. quit\n");
		printf("b. batch test\n");   /* new function */
		printf("d. debug\n"); 	/* print debug info */
		printf("c. check\n");	/* check consistency */
		printf("l. list all links\n"); /* list links */
                printf("s. sort links\n");
		printf("select a function...");
		scanf("%s",&select);
		switch(select)
		{
		case '1':
			load();
			break;
		case '2':
			save();
			break;
		case '3':
			learning();
			if(bg_fg==1)
			  loop=1;
			break;
		case '4':
			test();
			break;
		case '5':
			init();
			break;
		case '6':
			init_weights();
			break;
		case '7':
			set_par();
			break;
		case '8':
			on_line_test();
			break;
		case '9':
			build_data();
			break;
		case 'b':
		        batest(1);
		        break;
		case 'd':
			debug();
			break;
		case 'c':
			check();
			break;
		case 'l':
		        list_link();
		        break;	
		case 's':
		        /* qsort(cotab,max,sizeof(struct ct),lcompare); */
		        writewts("nvvtmp1");
		        printf("1\n");
		        system("sort -o nvvtmp2 nvvtmp1\n");
		        printf("2\n");
		        readwfile("nvvtmp2");
		        break;          
		case '0':
			loop=1;
			break;
		default:
			printf("error!\n");
		}
	}  while(loop==0);
}

debug () 
{
  int i,j;
  if (debug_flag == 0)
   {  printf("debug on\n");
      debug_flag= 1;
    }
   else 
   {  printf("debug off\n");
      debug_flag= 0;
    };
 for(i=1;i <= laynum; i++)
    for (j=1;j<=laynods[i];j++)
       printf("%d:%d om=%1.5f, on=%1.5f, oa=%1.5f, ob=%1.5f\n",
	i,j,outm[i][j],outn[i][j],outa[i][j],outb[i][j]);
 for (i=1;i<=laynods[laynum];i++)
     printf("target[%d]=%1.2f %1.2f %1.2f %1.2f\n", i,pattagm[i][no_pat],pattagn[i][no_pat],pattaga[i][no_pat],
		pattagb[i][no_pat]);
  return;
}

/* Reading start file for setting environment */
starfile(filename)
char *filename;
{
	FILE *fptr;
	int i;
	char name[20],value[20];
	char string[20],tmp;
	fptr=fopen(filename,"r");
	while(fscanf(fptr,"%s %s", name,value) != EOF)
	{
		switch(name[0])
		{
		case 'b':
			if (value != "no")
			{
				for(i=0;i<10;i++)
					bfile[i]=value[i];
				printf("biasfile: %s\n",bfile);
			}
			else
				break;
		case 'c':
			for(i=0;i<12;i++)
				cwfile[i]=value[i];
			printf("connection file: %s\n",cwfile);
			readwfile(cwfile);
			break;
		case 'g':
		        goal=atof(value);
		        printf("goal: %1.5f\n",goal);	
		case 'e':
			noepcoh=atoi(value);
			printf("no of epcoh: %d\n",noepcoh);
			break;
		case 'l':
			lr_con=lr_pre=atof(value);
			printf("lrate: %0.2f\n",lrate);
			break;
		case 'm':
			momentum = atof(value);
			printf("momentum: %0.2f\n",momentum);
			break;
		case 'n':
			for(i=0;i<12;i++)
				netfile[i]=value[i];
			printf("netfile: %s\n",netfile);
			readnet(netfile);
			break;
		case 'p':
			threshold=atof(value);
			printf("threshold: %0.2f\n",threshold);
			break;
		case 't':
			for(i=0;i<12;i++)
				trafile[i]=value[i];
			printf("trafile: %s\n",trafile);
			break;

		case 'w':
			if (value != "no")
			{
				for(i=0;i<12;i++)
					wfile[i]=value[i];
				printf("weightfile: %s\n",wfile);
				readwts(wfile);
				break;
			}
			else
				break;

		default: 
			printf("no match!\n");
		}
	}
	fclose(fptr);
}

/* Reading network definition file for initializing network*/
readnet(char *netfile)
{
	FILE *fptr;
	int i,j;
	int lay;
	laynum=0;
	fptr=fopen(netfile,"r");
	printf("network information-\n");
	while(fscanf(fptr,"%u %u", &i, &j) != EOF)
	{
		lay = i;
		laynods[lay] = j;
		laynum++;
		printf("laynum: %d  laynods: %d\n", laynum,
		    laynods[laynum]);
	}
	fclose(fptr);
  return;	
}

/* Reading connection table as weights file */
readwts(char *wfile)
{
	FILE *fptr;
	int i,j,k,l,index=1;
	float m,n,a,b;	/* 4 */
	char weight[3];
	fptr=fopen(wfile,"r");
	printf("connection weights-\n");
	while(fscanf(fptr,"%d %d %d %d %s", &i, &j, &k, &l,weight) != EOF)
	{
		cotab[index].lh = i;
		cotab[index].head = j;
		cotab[index].lt = k;
		cotab[index].tail =l;
		/*translating fuzzy terms to
		  LR-type fuzzy number*/
		if (strcmp(weight,"T1")==0)  {m=.0; n=.2; a=.0; b=.1;}   /* 4 */
		if (strcmp(weight,"T2")==0)  {m=.35; n=.65; a=.1; b=.1;}
		if (strcmp(weight,"T3")==0)  {m=.8; n=1.0; a=.1; b=.0;}
		if (strcmp(weight,"F1")==0)  {m=.0; n=.1; a=.0; b=.1;}
		if (strcmp(weight,"F2")==0)  {m=.25; n=.4; a=.1; b=.15;}
		if (strcmp(weight,"F3")==0)  {m=.6; n=.75; a=.15; b=.1;}
		if (strcmp(weight,"F4")==0)  {m=.9; n=1.0; a=.1; b=.0;}
		cotab[index].cm = m;
		cotab[index].cn = n;/* 4 */
		cotab[index].ca = a;
		cotab[index].cb = b;

	printf("%d:%d-->%d:%d weight: %1.3f %1.3f %1.3f %1.3f %s\n",
			cotab[index].lh,
			cotab[index].head,
			cotab[index].lt,
			cotab[index].tail,
			cotab[index].cm,
			cotab[index].cn,/* 4 */
			cotab[index].ca,
			cotab[index].cb,
			weight);
		index++;

	}
	printf("number of connections: %d\n", index-1);
	no_link=index-1;
	fclose(fptr);
  return;	
}

/* Reading weight file as connection table */
readwfile(char *wfile)
{
	FILE *fptr;
	int i,j,k,l,index=1;
	float m,n,a,b;
	char weight[3];
	fptr=fopen(wfile,"r");
	printf("connection weights-\n");
	while(fscanf(fptr,"%d %d %d %d %f %f %f %f",&i,&j,&k,&l,&m,&n,&a,&b) != EOF)
	{
		cotab[index].lh = i;
		cotab[index].head = j;
		cotab[index].lt = k;
		cotab[index].tail =l;
 		cotab[index].cm = m;
 		cotab[index].cn = n;/* 4 */
		cotab[index].ca = a;
		cotab[index].cb = b;

	printf("%d:%d-->%d:%d weight: %1.3f %1.3f %1.3f %1.3f\n",
			cotab[index].lh,
			cotab[index].head,
			cotab[index].lt,
			cotab[index].tail,
			cotab[index].cm,
			cotab[index].cn,/* 4 */
			cotab[index].ca,
			cotab[index].cb);
		index++;
	}
	printf("number of connections: %d\n", index-1);
	no_link=index-1;
	fclose(fptr);
  return;	
}

/*************************
 * Build Connection Link *
 *************************/
build_link(mode)
int mode;
{
  int i,j,lt,tail,lh,head;
  ct_node *p;
  for(i=1;i<=laynum;i++)
	for(j=1;j<=laynods[i];j++)
        {
		if((ct_head[i][j]=(ct_node *)malloc(sizeof(ct_node)))!=NULL)
                 {
                        ct_head[i][j]->next=NULL;
                        ct_head[i][j]->ct_id=0;
                  }
		if((ct_tail[i][j]=(ct_node *)malloc(sizeof(ct_node)))!=NULL)
                 {
			ct_tail[i][j]->next=NULL;
			ct_tail[i][j]->ct_id=0;
                  }
        }
/*
  for(i=2;i<=laynum;i++)
*/
       for(i=1;i<=no_link;i++)
        {
		lt=cotab[i].lt;
		tail=cotab[i].tail;
		lh=cotab[i].lh;
		head=cotab[i].head;
		if((p=(ct_node *)malloc(sizeof(ct_node)))!=NULL)
		 {
                        p->ct_id=i;
                        p->next=ct_head[lt][tail];
                        ct_head[lt][tail]=p;

		  } else printf("error allocating memory\n");
		if((p=(ct_node *)malloc(sizeof(ct_node)))!=NULL)
		 {
                        p->ct_id=i;
                        p->next=ct_tail[lh][head];
			ct_tail[lh][head]=p;
                  } else printf("error allocating memory\n");
         }
        for(i=2;i<=laynum;i++)
	for(j=1;j<=laynods[i];j++)
	{
	  p=ct_head[i][j];
	  while(p!=NULL)
	  {
            if (mode) {
	      printf("lay %d node %d ct %d",i,j,p->ct_id);
	      printf(" H_lay:%d H_nod:%d T_lay:%d T_nod:%d\n",
		cotab[p->ct_id].lh,
		cotab[p->ct_id].head,
		cotab[p->ct_id].lt,
		cotab[p->ct_id].tail);
	    }
	    p=p->next;
	   } 	
	  }
}

build_tlink()
{
  int i,j,lt,tail,lh,head;
  ct_node *p;
  for(i=1;i<=laynum;i++)
	for(j=1;j<=tlaynods[i];j++)
        {
		if((tct_head[i][j]=(ct_node *)malloc(sizeof(ct_node)))!=NULL)
                 {
                        tct_head[i][j]->next=NULL;
                        tct_head[i][j]->ct_id=0;
                  }
		if((tct_tail[i][j]=(ct_node *)malloc(sizeof(ct_node)))!=NULL)
                 {
			tct_tail[i][j]->next=NULL;
			tct_tail[i][j]->ct_id=0;
                  }
        }
/*
  for(i=2;i<=laynum;i++)
*/
       for(i=1;i<=no_link;i++)
        {
		lt=tmtab[i].lt;
		tail=tmtab[i].tail;
		lh=tmtab[i].lh;
		head=tmtab[i].head;
		if((p=(ct_node *)malloc(sizeof(ct_node)))!=NULL)
		 {
                        p->ct_id=i;
                        p->next=tct_head[lt][tail];
                        tct_head[lt][tail]=p;

		  } else printf("error allocating memory\n");
		if((p=(ct_node *)malloc(sizeof(ct_node)))!=NULL)
		 {
                        p->ct_id=i;
                        p->next=tct_tail[lh][head];
			tct_tail[lh][head]=p;
                  } else printf("error allocating memory\n");
         }
        for(i=2;i<=laynum;i++)
	for(j=1;j<=laynods[i];j++)
	{
	  p=tct_head[i][j];
	  while(p!=NULL)
	  {
            /*
	    printf("lay %d node %d ct %d",i,j,p->ct_id);
	    printf(" H_lay:%d H_nod:%d T_lay:%d T_nod:%d\n",
		tmtab[p->ct_id].lh,
		tmtab[p->ct_id].head,
		tmtab[p->ct_id].lt,
		tmtab[p->ct_id].tail); */
	    p=p->next;
	   } 	
	  }

}
/* Initializing weights between [+0.5,-0.5] */
init_weights()
{
	int i,j,k,range=50;
	float temp;
	float rnd();
	printf("Reset weights...\n");
	for(i=1;i<=no_link;i++)
	 {
		cotab[i].cm = rnd(range);
		cotab[i].cn = rnd(range);	/* 4 */
		if (cotab[i].cm > cotab[i].cn)
			{temp=cotab[i].cm;
			cotab[i].cm=cotab[i].cn;
			cotab[i].cn=temp;}
		cotab[i].ca = fabs(rnd(range*3/5));
		cotab[i].cb = fabs(rnd(range*3/5));
		printf("link %d  m:%0.3f n:%0.3f a:%0.3f b:%0.3f\n",
			i,cotab[i].cm,cotab[i].cn,cotab[i].ca,cotab[i].cb);
           }
}

/* Random number generator */
float rnd(range)
float range;
{
	double x,y,z;
	x=rand();
	x=x/10000;
	y=modf(x,&z);
	y= range*y;
	return(y);
}

/* Reading pattern data file */
int readpat(char *patfile)
{
	int i=1,j=1,k=1;
	float m,n,a,b;
	FILE *fptr;
	fptr=fopen(patfile,"r");
	patnum = 0;
	printf("%s patterns-\n",patfile);

	while(fscanf(fptr,"%f %f %f %f",&m,&n,&a,&b) != EOF)
	{

		if ( i>laynods[1]) /* output node */
		{
			pattagm[k][j]=m;
			pattagn[k][j]=n;
			pattaga[k][j]=a;
			pattagb[k][j]=b;
			k++;
		}
		else
		{
			patm[i][j]=m;
			patn[i][j]=n;
			pata[i][j]=a;
			patb[i][j]=b;
			i++;	
		}
		if ( k>laynods[laynum])
		{
			i=k=1;
			j++;
		}
	 
	}
	patnum = j-1;
	printf("patnum: %d\n",patnum);
	return(patnum);
}
writewts(char *wfile)
{
	FILE *fptr;
	int i,j,k;
	char weight[4];
	fptr=fopen(wfile,"w");
	printf("write to connection table-\n");
	for(i=1;i<=no_link;i++)
	{	/* 4 */
 		fprintf(fptr,"%d %d %d %d %1.2f %1.2f %1.2f %1.2f\n",
 			cotab[i].lh,cotab[i].head,cotab[i].lt,cotab[i].tail,
			cotab[i].cm,cotab[i].cn,cotab[i].ca,cotab[i].cb);
	}
	fclose(fptr);
  return;
}

get_pat()
{
	int i,tmp;
	double j,k,l;
	for (i=1;i<=patnum;i++)
		patodr[i]=i;

	for (i=patnum;i>1;i--)
	{
		j=fabs(rnd((i-1)*100))+1;
		k=modf(j,&l);
		tmp=patodr[i];
		patodr[i]= patodr[(int) l];
		patodr[(int) l]= tmp;
	}
	/*for (i=patnum;i>0;i--)
		printf("%d %d\n",i,patodr[i]);*/
}

float sigmoid(input)
double input;
{
	double result,exp();
	/*if(input>16.0)
		result=1.0;
	else if(input<-16.0)
float	result=0.0;
	else*/ result =1/(1.0+exp(-lambda*input));
	return(result);
}

float similarity(m1,n1,a1,b1,m2,n2,a2,b2)
float m1,n1,a1,b1,m2,n2,a2,b2;
{  float s;
	if ((s= (1-(p1*(m1-m2)*(m1-m2)+p1*(n1-n2)*(n1-n2)+(a1-a2)*(a1-a2)+(b1-b2)*(b1-b2)))) >0) 
		return s;
	return 0;
}

compute_output(no_pat)
{
	int i,j,c_no;
	float m1,n1,a1,b1,m2,n2,a2,b2;
	float MIN,MAX,s_degree,sum_ce,sum_so,centroid,total_sdeg;
	float um=.6,ua=.2,ub=.2;
	ct_node *p;

	for(i=1;i<=laynods[1];i++)      /*compute output value of input nodes*/
	{
		outm[1][i]=patm[i][no_pat];
		outn[1][i]=patn[i][no_pat];
		outa[1][i]=pata[i][no_pat];
		outb[1][i]=patb[i][no_pat];
	/*	printf("m:%1.2f a:%1.2f b:%1.2f\n",outm[1][i],outa[1][i],outb[1][i]); 9/22 */
	}
	for(i=2;i<=laynum;i++)
	    for(j=1;j<=laynods[i];j++) /*compute activation of S-neuron*/
		{
		 p=ct_head[i][j];
		 if(i % 2 ==0)
		 {
		  MIN=1;
		  total_sdeg=c_no=0;
		  while(p->next != NULL)
		  {
 			m1=cotab[p->ct_id].cm;
 			n1=cotab[p->ct_id].cn;
			a1=cotab[p->ct_id].ca;
			b1=cotab[p->ct_id].cb;
			m2=outm[cotab[p->ct_id].lh][cotab[p->ct_id].head];
			n2=outn[cotab[p->ct_id].lh][cotab[p->ct_id].head];
			a2=outa[cotab[p->ct_id].lh][cotab[p->ct_id].head];
			b2=outb[cotab[p->ct_id].lh][cotab[p->ct_id].head];
 			s_degree=similarity(m1,n1,a1,b1,m2,n2,a2,b2);
 		/*	printf("m1=%1.5f n1=%1.5f a1=%1.5f b1=%1.5f \n",m1,n1,a1,b1);
 			printf("m2=%1.5f n2=%1.5f a2=%1.5f b2=%1.5f \n",m2,n2,a2,b2); 
			printf("s_degree ==> %1.5f\n ",s_degree); 9/22 */
			if (MIN > s_degree) 
			{
				MIN=s_degree;
				sc_no[i][j]=p->ct_id;
			};
 		  	 p=p->next;
		   }/*while */
			outm[i][j]=MIN;
		/*	printf("MIN  ==> %1.5f\n",MIN); 9/22 */
			if(outm[i][j]>1) outm[i][j]=1;
			if(outm[i][j]<0) outm[i][j]=0;

		  }/* if */
		 else
		 {
		   sum_so=0;
		   outm[i][j]=0;
		   outn[i][j]=0;
		   outa[i][j]=0;
		   outb[i][j]=0;
		   p=ct_head[i][j];
		   while(p->next !=NULL)
		   {
			sum_so += outm[cotab[p->ct_id].lh][cotab[p->ct_id].head];
			outm[i][j]+=outm[cotab[p->ct_id].lh][cotab[p->ct_id].head]*cotab[p->ct_id].cm;
			outn[i][j]+=outm[cotab[p->ct_id].lh][cotab[p->ct_id].head]*cotab[p->ct_id].cn;
			outa[i][j]+=outm[cotab[p->ct_id].lh][cotab[p->ct_id].head]*cotab[p->ct_id].ca;
			outb[i][j]+=outm[cotab[p->ct_id].lh][cotab[p->ct_id].head]*cotab[p->ct_id].cb;
			p=p->next; 
	       	    } 
	/*		printf("outm[%d][%d]=%1.5f sum_so=%1.5f \n",i,j,outm[i][j],sum_so); */
		    if (sum_so !=0)
			{ outm[i][j]/=sum_so;outn[i][j]/=sum_so;outa[i][j]/=sum_so;outb[i][j]/=sum_so; }
/*
		     else
			{ outm[i][j]=0.5;outn[i][j]=0.5;outa[i][j]=0;outb[i][j]=0; } 
		     if (i==laynum)
		         outm[i][j]= (outn[i][j]+outm[i][j])/2 + (outb[i][j]-outa[i][j])/3;
			 centroid for output G-neurons
*/
		   }/* else */
		 }/* for j */	
 /*		printf("outm=%1.5f \n",outm[laynum][1]);			 */
}


float weight_change(no_pat)
int no_pat;
{
	int i,j,k,no_sc;
	float mse=0.0,err,sum_so,ce_sum,x,sign,ov;
	float m1,n1,a1,b1,m2,n2,a2,b2,s_degree,sum_cfm,sum_cfn,sum_cfa,sum_cfb;
	float errm[maxlay][maxnod],errn[maxlay][maxnod],erra[maxlay][maxnod],errb[maxlay][maxnod];
	float delm[maxlay][maxnod],dela[maxlay][maxnod],delb[maxlay][maxnod];
 	ct_node *p,*q;  
	for(i=1;i<=laynum;i++)
	   for(j=1;j<=laynods[i];j++)
		errm[i][j]=errn[i][j]=erra[i][j]=errb[i][j]=0.0;
	mse=0.0; 
	for(i=1;i<=laynods[laynum];i++)
	{	/* fuzzy target */
		errm[laynum][i]=(outm[laynum][i]-pattagm[i][no_pat]);
		errn[laynum][i]=(outn[laynum][i]-pattagn[i][no_pat]);
		erra[laynum][i]=(outa[laynum][i]-pattaga[i][no_pat]);
		errb[laynum][i]=(outb[laynum][i]-pattagb[i][no_pat]);
		err=(errn[laynum][i]*errn[laynum][i]+errm[laynum][i]*errm[laynum][i]+
		     erra[laynum][i]*erra[laynum][i]+errb[laynum][i]*errb[laynum][i]);
		mse+=err/2;
	/*	printf("outm=%1.5f targetm=%1.5f \n",outm[laynum][i],pattagm[i][no_pat]);
		printf("init error errm=%1.5f errn=%1.5f erra=%1.5f errb=%1.5f\n",errm[laynum][i],errn[laynum][i],erra[laynum][i],errb[laynum][i]);
	        getchar();  9/22 */
	 }	 
	for(i=laynum;i>1;i--)
	  if(i % 2 != 0) /* G-neurons */
	    { 
	    if (i != laynum)
	      for(j=1;j<=laynods[i];j++)
    		{
		  q=ct_tail[i][j];
		  while(q->next != NULL)
		    { 
		      /* x=errm[cotab[q->ct_id].lt][cotab[q->ct_id].tail]*(-2)/(p1+2); 9/20 */
		       x=errm[cotab[q->ct_id].lt][cotab[q->ct_id].tail]*(-2);
		       errm[i][j]+=x*(outm[i][j]-cotab[q->ct_id].cm)*p1;
		       errn[i][j]+=x*(outn[i][j]-cotab[q->ct_id].cn)*p1;
		       erra[i][j]+=x*(outa[i][j]-cotab[q->ct_id].ca);
		       errb[i][j]+=x*(outb[i][j]-cotab[q->ct_id].cb);
			q=q->next;
		    }
		 }/* for j ,if i*/
	      for(j=1;j<=laynods[i];j++)
    		{
		  sum_so=0;
		  p=ct_head[i][j];
		  while(p->next != NULL)
		    {
		      sum_so += outm[cotab[p->ct_id].lh][cotab[p->ct_id].head]; 
		      p=p->next;
		    }
		   p=ct_head[i][j];
  		   while(p->next != NULL)
  		     { 
		       if(sum_so !=0)
		        {
			x=lr_con*outm[cotab[p->ct_id].lh][cotab[p->ct_id].head]/sum_so;
 		       cotab[p->ct_id].cm -= errm[i][j]*x;
 		       cotab[p->ct_id].cn -= errn[i][j]*x;
	               cotab[p->ct_id].ca -= erra[i][j]*x;
                       cotab[p->ct_id].cb -= errb[i][j]*x;
			if(cotab[p->ct_id].cm>1.0)
			   cotab[p->ct_id].cm=1.0;
			if(cotab[p->ct_id].cm<.0)
			   cotab[p->ct_id].cm=.0; 
			if(cotab[p->ct_id].cn>1.0)
			   cotab[p->ct_id].cn=1.0;
			if(cotab[p->ct_id].cn<.0)
			   cotab[p->ct_id].cn=.0; 
		        if(cotab[p->ct_id].ca>.5)
			   cotab[p->ct_id].ca=.5;
			if(cotab[p->ct_id].ca<.0)
			   cotab[p->ct_id].ca=.0;
			if(cotab[p->ct_id].cb>.5)
			   cotab[p->ct_id].cb=.5;
			if(cotab[p->ct_id].cb<.0)
			   cotab[p->ct_id].cb=.0;
		          }
 		       p=p->next; 

		      } /* while */
		 }/* for j */
		} /* if i */
		else   /* S-neurons */
	          for(j=1;j<=laynods[i];j++)
		     if(outm[i][j] != 0)
		     {
			q=ct_tail[i][j];
		        while(q->next != NULL)
			{
		          p=ct_head[cotab[q->ct_id].lt][cotab[q->ct_id].tail];
			  sum_so=sum_cfm=sum_cfn=sum_cfa=sum_cfb=0.0;
		          while(p->next != NULL)
		          { 
			    sum_so+=outm[cotab[p->ct_id].lh][cotab[p->ct_id].head];
			    sum_cfm+=outm[cotab[p->ct_id].lh][cotab[p->ct_id].head]*cotab[p->ct_id].cm;
			    sum_cfn+=outm[cotab[p->ct_id].lh][cotab[p->ct_id].head]*cotab[p->ct_id].cn;
			    sum_cfa+=outm[cotab[p->ct_id].lh][cotab[p->ct_id].head]*cotab[p->ct_id].ca;
			    sum_cfb+=outm[cotab[p->ct_id].lh][cotab[p->ct_id].head]*cotab[p->ct_id].cb;
			    p=p->next;
			   }
/*
printf("so=%1.5f cfm=%1.5f cfa=%1.5f cfb=%1.5f\n",sum_so,sum_cfm,sum_cfa,sum_cfb);
*/
			  if (sum_so != 0)
			  errm[i][j]+=(cotab[q->ct_id].cm*sum_so-sum_cfm)/(sum_so*sum_so)*
					errm[cotab[q->ct_id].lt][cotab[q->ct_id].tail]+
			  		(cotab[q->ct_id].cn*sum_so-sum_cfn)/(sum_so*sum_so)*
					errn[cotab[q->ct_id].lt][cotab[q->ct_id].tail]+
			  		(cotab[q->ct_id].ca*sum_so-sum_cfa)/(sum_so*sum_so)*
					erra[cotab[q->ct_id].lt][cotab[q->ct_id].tail]+
			  		(cotab[q->ct_id].cb*sum_so-sum_cfb)/(sum_so*sum_so)*
					errb[cotab[q->ct_id].lt][cotab[q->ct_id].tail];
			  else errm[i][j]=0;
			  q=q->next;
			 }
			 erra[i][j]=errn[i][j]=errb[i][j]=errm[i][j];
			 p=ct_head[i][j];
			 while (p->next != NULL)
			   if(p->ct_id == sc_no[i][j])
			 {
			    /* x=errm[i][j]*lr_pre*2/(p1+2); 9/20 */
			    x=errm[i][j]*lr_pre*2;
			    cotab[p->ct_id].cm -= 
			      (outm[cotab[p->ct_id].lh][cotab[p->ct_id].head]-cotab[p->ct_id].cm)*p1*x;
			    cotab[p->ct_id].cn -= 
			      (outn[cotab[p->ct_id].lh][cotab[p->ct_id].head]-cotab[p->ct_id].cn)*p1*x;
			    cotab[p->ct_id].ca -= 
			      (outa[cotab[p->ct_id].lh][cotab[p->ct_id].head]-cotab[p->ct_id].ca)*x;
			    cotab[p->ct_id].cb -= 
			      (outb[cotab[p->ct_id].lh][cotab[p->ct_id].head]-cotab[p->ct_id].cb)*x;
  			   if(cotab[p->ct_id].cm>1.0)
			     cotab[p->ct_id].cm=1.0;
			   if(cotab[p->ct_id].cm<.0)
			     cotab[p->ct_id].cm=.0;  
			   if(cotab[p->ct_id].cn>1.0)
			     cotab[p->ct_id].cn=1.0;
			   if(cotab[p->ct_id].cn<.0)
			     cotab[p->ct_id].cn=.0; 
		           if(cotab[p->ct_id].ca>.5)
			     cotab[p->ct_id].ca=.5;
			   if(cotab[p->ct_id].ca<.0)
			     cotab[p->ct_id].ca=.0;
			   if(cotab[p->ct_id].cb>.5)
			     cotab[p->ct_id].cb=.5;
			   if(cotab[p->ct_id].cb<.0)
			     cotab[p->ct_id].cb=.0;
			   p=p->next;
		         } else p=p->next;/* while p ,if */
		      }; /* if outm */
if(debug_flag != 0)
{
  for(i=1;i <= laynum; i++)
    for (j=1;j<=laynods[i];j++)
       printf("%d:%d om=%1.2f, on:%1.2f, oa=%1.2f, ob=%1.2f, dm=%1.2f, dn=%1.2f, da=%1.2f, db=%1.2f\n",
	i,j,outm[i][j],outn[i][j],outa[i][j],outb[i][j],errm[i][j],errn[i][j],erra[i][j],errb[i][j]);
  for (i=1;i<=laynods[laynum];i++)
     printf("target[%d]=%1.2f %1.2f %1.2f %1.2f\n", i,pattagm[i][no_pat],pattagn[i][no_pat],pattaga[i][no_pat],
		pattagb[i][no_pat]);
  for(i=1;i<=no_link;i++)
     printf("%d:%d->%d:%d  m:%0.3f n:%0.3f a:%0.3f b:%0.3f\n",cotab[i].lh,cotab[i].head,
cotab[i].lt,cotab[i].tail,cotab[i].cm,cotab[i].cn,cotab[i].ca,cotab[i].cb);
 }; 
	return(mse);
}

int scompute_output(no_pat)      /* compute output with temp network */
{
	int i,j,c_no,fire=0;
	float m1,n1,a1,b1,m2,n2,a2,b2;
	float MIN,MAX,s_degree,sum_ce,sum_so,centroid,total_sdeg;
	float um=.6,ua=.2,ub=.2;
	ct_node *p;

	for(i=1;i<=tlaynods[1];i++)      /*compute output value of input nodes*/
	{
		outm[1][i]=patm[i][no_pat];
		outn[1][i]=patn[i][no_pat];
		outa[1][i]=pata[i][no_pat];
		outb[1][i]=patb[i][no_pat];
		/*printf("m:%1.2f a:%1.2f b:%1.2f\n",outm[1][i],outa[1][i],outb[1][i]);*/
	}
	for(i=2;i<=laynum;i++)
	    for(j=1;j<=tlaynods[i];j++) /*compute activation of S-neuron*/
		{
		 p=tct_head[i][j];
		 if(i % 2 ==0)
		 {
		  MIN=1;
		  total_sdeg=c_no=0;
		  while(p->next != NULL)
		  {
 			m1=tmtab[p->ct_id].cm;
 			n1=tmtab[p->ct_id].cn;
			a1=tmtab[p->ct_id].ca;
			b1=tmtab[p->ct_id].cb;
			m2=outm[tmtab[p->ct_id].lh][tmtab[p->ct_id].head];
			n2=outn[tmtab[p->ct_id].lh][tmtab[p->ct_id].head];
			a2=outa[tmtab[p->ct_id].lh][tmtab[p->ct_id].head];
			b2=outb[tmtab[p->ct_id].lh][tmtab[p->ct_id].head];
 			s_degree=similarity(m1,n1,a1,b1,m2,n2,a2,b2);
			if (MIN > s_degree) 
			{
				MIN=s_degree;
				sc_no[i][j]=p->ct_id;
			};
 		  	 p=p->next;
		   }/*while */
			outm[i][j]=MIN;
			if(outm[i][j]>1) outm[i][j]=1;
			if(outm[i][j]<0) outm[i][j]=0;
                        /* printf("sim at l%d n%d: %1.5f\n",i,j,outm[i][j]); */
		  }/* if */
		 else
		 {
		   sum_so=0;
		   outm[i][j]=0;
		   outn[i][j]=0;
		   outa[i][j]=0;
		   outb[i][j]=0;
		   p=tct_head[i][j];
		   while(p->next !=NULL)
		   {
			sum_so += outm[tmtab[p->ct_id].lh][tmtab[p->ct_id].head];
			outm[i][j]+=outm[tmtab[p->ct_id].lh][tmtab[p->ct_id].head]*tmtab[p->ct_id].cm;
			outn[i][j]+=outm[tmtab[p->ct_id].lh][tmtab[p->ct_id].head]*tmtab[p->ct_id].cn;
			outa[i][j]+=outm[tmtab[p->ct_id].lh][tmtab[p->ct_id].head]*tmtab[p->ct_id].ca;
			outb[i][j]+=outm[tmtab[p->ct_id].lh][tmtab[p->ct_id].head]*tmtab[p->ct_id].cb;
			p=p->next; 
	       	    } 
		/*	printf("outm[%d][%d]=%1.5f\n",i,j,outm[i][j]); */
		    if (sum_so !=0) {
		      outm[i][j]/=sum_so;
		      outn[i][j]/=sum_so;
		      outa[i][j]/=sum_so;
		      outb[i][j]/=sum_so;
		      fire=1;
		    }
		     else {
		       outm[i][j]=0;
		       outn[i][j]=1;
		       outa[i][j]=0;
		       outb[i][j]=0;
		     } 
/*		     if (i==laynum)
		         outm[i][j]= (outn[i][j]+outm[i][j])/2 + (outb[i][j]-outa[i][j])/3;
centroid for output G-neurons
*/
		   }/* else */
		 }/* for j */	
  return(fire);					 
}

int scompute_output2(no_pat)
{
	int i,j,c_no,fire=0;
	float m1,n1,a1,b1,m2,n2,a2,b2;
	float MIN,MAX,s_degree,sum_ce,sum_so,centroid,total_sdeg;
	float um=.6,ua=.2,ub=.2;
	ct_node *p;

	for(i=1;i<=tlaynods[1];i++)      /*compute output value of input nodes*/
	{
		outm[1][i]=gpatm[i][no_pat];
		outn[1][i]=gpatn[i][no_pat];
		outa[1][i]=gpata[i][no_pat];
		outb[1][i]=gpatb[i][no_pat];
		/*printf("m:%1.2f a:%1.2f b:%1.2f\n",outm[1][i],outa[1][i],outb[1][i]);*/
	}
	for(i=2;i<=laynum;i++)
	    for(j=1;j<=tlaynods[i];j++) /*compute activation of S-neuron*/
		{
		 p=tct_head[i][j];
		 if(i % 2 ==0)
		 {
		  MIN=1;
		  total_sdeg=c_no=0;
		  while(p->next != NULL)
		  {
 			m1=tmtab[p->ct_id].cm;
 			n1=tmtab[p->ct_id].cn;
			a1=tmtab[p->ct_id].ca;
			b1=tmtab[p->ct_id].cb;
			m2=outm[tmtab[p->ct_id].lh][tmtab[p->ct_id].head];
			n2=outn[tmtab[p->ct_id].lh][tmtab[p->ct_id].head];
			a2=outa[tmtab[p->ct_id].lh][tmtab[p->ct_id].head];
			b2=outb[tmtab[p->ct_id].lh][tmtab[p->ct_id].head];
 			s_degree=similarity(m1,n1,a1,b1,m2,n2,a2,b2);
			if (MIN > s_degree) 
			{
				MIN=s_degree;
				sc_no[i][j]=p->ct_id;
			};
 		  	 p=p->next;
		   }/*while */
			outm[i][j]=MIN;
			if(outm[i][j]>1) outm[i][j]=1;
			if(outm[i][j]<0) outm[i][j]=0;
                        /* printf("sim at l%d n%d: %1.5f\n",i,j,outm[i][j]); */
		  }/* if */
		 else
		 {
		   sum_so=0;
		   outm[i][j]=0;
		   outn[i][j]=0;
		   outa[i][j]=0;
		   outb[i][j]=0;
		   p=tct_head[i][j];
		   while(p->next !=NULL)
		   {
			sum_so += outm[tmtab[p->ct_id].lh][tmtab[p->ct_id].head];
			outm[i][j]+=outm[tmtab[p->ct_id].lh][tmtab[p->ct_id].head]*tmtab[p->ct_id].cm;
			outn[i][j]+=outm[tmtab[p->ct_id].lh][tmtab[p->ct_id].head]*tmtab[p->ct_id].cn;
			outa[i][j]+=outm[tmtab[p->ct_id].lh][tmtab[p->ct_id].head]*tmtab[p->ct_id].ca;
			outb[i][j]+=outm[tmtab[p->ct_id].lh][tmtab[p->ct_id].head]*tmtab[p->ct_id].cb;
			p=p->next; 
	       	    } 
		/*	printf("outm[%d][%d]=%1.5f\n",i,j,outm[i][j]); */
		    if (sum_so !=0) {
		      outm[i][j]/=sum_so;
		      outn[i][j]/=sum_so;
		      outa[i][j]/=sum_so;
		      outb[i][j]/=sum_so;
		      fire=1;
		    }
		     else {
		       outm[i][j]=0;
		       outn[i][j]=1;
		       outa[i][j]=0;
		       outb[i][j]=0;
		     } 
/*		     if (i==laynum)
		         outm[i][j]= (outn[i][j]+outm[i][j])/2 + (outb[i][j]-outa[i][j])/3;
centroid for output G-neurons
*/
		   }/* else */
		 }/* for j */	
  return(fire);					 
}

load()
{
	int flag=0;
	char select;
	while(flag==0)
	{
		printf("\n");
		printf("**********************\n");
		printf("*      load          *\n");
		printf("**********************\n");
		printf("1.load network file\n");
		printf("2.load pattern file\n");
		printf("3.load symbolic weight file\n");
		printf("4.load numerical weight file\n");
		printf("0.go to main menu\n");
		printf("select a function...");
		scanf("%s",&select);
		switch(select)
		{
		case '1':
			printf("Please input network filename(*.net)..");
			scanf("%s",netfile);
			printf("\nloading %s...\n",netfile);
			readnet(netfile);
			break;
		case '2':
			printf("Please input pattern filename..");
			scanf("%s",patfile);
			printf("\nloading %s...\n",patfile);
			readpat(patfile);
			break;
		case '3':
			printf("Please input symbolic weighe filename(*.wts)..");
			scanf("%s",wfile);
			printf("\nloading %s...\n",wfile);
			readwts(wfile);
			break;
		case '4':
			printf("Please input numerical weight filename..");
			scanf("%s",wfile);
			printf("\nloading %s...\n",wfile);
			readwfile(wfile);
			break;
		case '0':
			flag=1;
			break;
		default:
			printf("error!");
		}
	}
}

save()
{
	char select;
	int flag=0;
	printf("\n");
	printf("**********************\n");
	printf("*      save          *\n");
	printf("**********************\n");
	printf("1.save current file\n");
	printf("2.save as new file\n");
	printf("select a function...");
	scanf("%s",&select);
	if (select =='2')
	{
		printf("Please input connection table filename...");
		scanf("%s",wfile);
	}
	printf("saving files...\n");
	writewts(wfile);
	
}

batest(mode)
int mode;
{
  int i,j,pat_num,exist=0;
  float mse=0.0,err,tt_mse,av_mse;
  
  tt_mse=0;
  av_sim=0;
  if (patnum==0)
    return;
  for (pat_num=1;pat_num<=patnum;pat_num++) {
    mse=0.0;
    compute_output(pat_num);
    for(i=1;i<=laynods[laynum];i++) {
      /* fuzzy target */
      err=(pattagm[i][pat_num]-outm[laynum][i])*
        (pattagm[i][pat_num]-outm[laynum][i])+
        (pattagn[i][pat_num]-outn[laynum][i])*
        (pattagn[i][pat_num]-outn[laynum][i])+
        (pattaga[i][pat_num]-outa[laynum][i])*
        (pattaga[i][pat_num]-outa[laynum][i])+
        (pattagb[i][pat_num]-outb[laynum][i])*
        (pattagb[i][pat_num]-outb[laynum][i]);
      sim=similarity(pattagm[i][pat_num],pattagn[i][pat_num],
         pattaga[i][pat_num],pattagb[i][pat_num],
         outm[laynum][i],outn[laynum][i],outa[laynum][i],outb[laynum][i]);
      av_sim+=sim;   
      mse+=err/2;
      if (mode)
        printf("o%d: %1.2f %1.2f %1.2f %1.2f d: %1.2f %1.2f %1.2f %1.2f \n",
          i,outm[laynum][i],outn[laynum][i],outa[laynum][i],outb[laynum][i],
          pattagm[i][pat_num],pattagn[i][pat_num],pattaga[i][pat_num],
          pattagb[i][pat_num]);
    }
    tt_mse+=mse;
  }
  av_mse=tt_mse/patnum/laynods[laynum];
  av_sim=av_sim/patnum/laynods[laynum];
  if (mode) {
    printf("Average Pss= %3.6f\n",av_mse);
    printf("Average accuracy= %1.4f",av_sim);
  }
  return;
}

learning()
{    
        FILE *LFile;
        char FileName[FileNameMax];
	float pss,pssa[5001];
	int i,current_pat,cycno=0,iteration,ratio,npoints=100;
	char key,outfile[30];
	float accuracy;
 	FILE *mfile;	

        printf("Please input learning file name: ");
        scanf("%s",FileName);
        LFile = fopen(FileName,"w");
	printf("learning...\n");
	printf("threshold %1.2f noepcoh %d\n",threshold,noepcoh);
	iteration=noepcoh;

	do
	{
	  do
	  {
		pss=0.0;
		get_pat();
		for(i=1;i<=patnum;i++)
		{ 
			current_pat=patodr[i];
			compute_output(current_pat); 
			pss+=weight_change(current_pat);

		/*	compute_output(i);
			pss+=weight_change(i); 9/23 */
		}
		pss/=patnum;
		pssa[cycno]=pss;
		cycno++;
		if(bg_fg!=1)
		
	        /* printf("cycle no.%d pss:%1.5f \n",cycno,pss); */
		printf("%d   %1.5f\n",cycno,pss); 
		fprintf(LFile,"%d   %1.5f\n",cycno,pss);
	   
	   } while(pss>threshold && cycno<=iteration );
	if (bg_fg==1)
	{
		write_rep(cycno,pss);
		writewts(wfile);
		cycno--;
		ratio=cycno/npoints;
		if ( cycno < npoints ) ratio=1;
		strcpy(outfile,rep_file);
		strcat(outfile,".m");
		if ((mfile=fopen(outfile,"w"))==NULL) {printf("open file error\n"); exit(0);}
		        /* fprintf(mfile,"a=["); */
		fprintf(mfile,"Epochs MSE\n");  /* for excel */
		for (i=0;i <= cycno;i+=ratio)
  		  fprintf(mfile,"%6d %1.5f\n",i,pssa[i]);
  		  batest(1);
  		  fprintf(mfile,"%1.5f\n",av_sim);
  		/* remark begin
		fprintf(mfile,"%1.5f]\n",pssa[i]);
		fprintf(mfile,"x=1:%d:%d\nplot(x,a)\n",ratio,cycno);
		fprintf(mfile,"title('lr_pre=%1.3f, lr_con=%1.3f, pat_num=%d')\n",lr_pre,lr_con,patnum);
		fprintf(mfile,"xlabel('iteration')\n");
		fprintf(mfile,"ylabel('pss')\n");
		remark end */
		fclose(mfile);
	 }
	else	
	{
	if(bg_fg!=1) /*foreground running*/
	 {
	  printf("continue(y/n)?");
	  scanf("%s",&key);
          }
	}
	iteration+=noepcoh;
	if(bg_fg==1) 
	  break;
	}while(key=='y');
  batest(0);
  printf("Performance: %1.5f   Goal: %1.5f\n",av_sim,goal);
  if (av_sim<goal)
    printf("Suggestion: insert rules\n");
  fclose(LFile);  
  return;	   
}
test()
{
	int i,j,pat_num,exist=0;
	float mse=0.0,err;
	printf("***testing***\n");
	while(1)
	{
		mse=0;
		sim=0;
		printf("Please input test pattern number(0 for exit)...");
		scanf("%d",&pat_num);
		if (pat_num == 0)
			break;
		else
		{
 			compute_output(pat_num);
			for(i=1;i<=laynods[laynum];i++)
			{ 	/* fuzzy target */
				err=(pattagm[i][pat_num]-outm[laynum][i])*
				    (pattagm[i][pat_num]-outm[laynum][i])+
				    (pattagn[i][pat_num]-outn[laynum][i])*
				    (pattagn[i][pat_num]-outn[laynum][i])+
				    (pattaga[i][pat_num]-outa[laynum][i])*
				    (pattaga[i][pat_num]-outa[laynum][i])+
				    (pattagb[i][pat_num]-outb[laynum][i])*
				    (pattagb[i][pat_num]-outb[laynum][i]);
				mse+=err/2;
				sim+=similarity(pattagm[i][pat_num],pattagn[i][pat_num],
                                pattaga[i][pat_num],pattagb[i][pat_num],
                                outm[laynum][i],outn[laynum][i],
                                outa[laynum][i],outb[laynum][i]);
				printf("o%d: %1.2f %1.2f %1.2f %1.2f d: %1.2f %1.2f %1.2f %1.2f \n",
					i,outm[laynum][i],outn[laynum][i],outa[laynum][i],outb[laynum][i],
					pattagm[i][pat_num],pattagn[i][pat_num],pattaga[i][pat_num],
					pattagb[i][pat_num]);
			}
			sim/=laynods[laynum];
			printf("Pss= %3.6f Acc= %1.5f\n",mse,sim);
		}
	}
}

float test2(pat_num)   /* test specific pattern */
int pat_num;
{
  int i,j,exist=0;
  float mse,err;
 
  mse=0;
  av_sim=0;
  if (pat_num == 0)
    return(-1);
  else {
    compute_output(pat_num);
    for(i=1;i<=laynods[laynum];i++) { 	/* fuzzy target */
      err=(pattagm[i][pat_num]-outm[laynum][i])*
        (pattagm[i][pat_num]-outm[laynum][i])+
        (pattagn[i][pat_num]-outn[laynum][i])*
        (pattagn[i][pat_num]-outn[laynum][i])+
        (pattaga[i][pat_num]-outa[laynum][i])*
        (pattaga[i][pat_num]-outa[laynum][i])+
        (pattagb[i][pat_num]-outb[laynum][i])*
        (pattagb[i][pat_num]-outb[laynum][i]);
      mse+=err/2;
      sim=similarity(pattagm[i][pat_num],pattagn[i][pat_num],
        pattaga[i][pat_num],pattagb[i][pat_num],
        outm[laynum][i],outn[laynum][i],outa[laynum][i],outb[laynum][i]);
      av_sim+=sim;
        /*
	printf("o%d: %1.2f %1.2f %1.2f %1.2f d: %1.2f %1.2f %1.2f %1.2f \n",
	i,outm[laynum][i],outn[laynum][i],outa[laynum][i],outb[laynum][i],
	pattagm[i][pat_num],pattagn[i][pat_num],pattaga[i][pat_num],
	pattagb[i][pat_num]); */
     }
     av_sim/=laynods[laynum];
  }
  return(av_sim);
}

float test3(pat_num)   /* test specific pattern cluster*/
int pat_num;
{
  int i,j,exist=0;
  float mse,err;
 
  mse=0;
  av_sim=0;
  if (pat_num == 0)
    return(-1);
  else {
    compute_output(pat_num);
    for(i=1;i<=laynods[laynum];i++) { 	/* fuzzy target */
      err=(gpattagm[i][pat_num]-outm[laynum][i])*
        (gpattagm[i][pat_num]-outm[laynum][i])+
        (gpattagn[i][pat_num]-outn[laynum][i])*
        (gpattagn[i][pat_num]-outn[laynum][i])+
        (gpattaga[i][pat_num]-outa[laynum][i])*
        (gpattaga[i][pat_num]-outa[laynum][i])+
        (gpattagb[i][pat_num]-outb[laynum][i])*
        (gpattagb[i][pat_num]-outb[laynum][i]);
      mse+=err/2;
      sim=similarity(gpattagm[i][pat_num],gpattagn[i][pat_num],
        gpattaga[i][pat_num],gpattagb[i][pat_num],
        outm[laynum][i],outn[laynum][i],outa[laynum][i],outb[laynum][i]);
      av_sim+=sim;
        /*
	printf("o%d: %1.2f %1.2f %1.2f %1.2f d: %1.2f %1.2f %1.2f %1.2f \n",
	i,outm[laynum][i],outn[laynum][i],outa[laynum][i],outb[laynum][i],
	gpattagm[i][pat_num],gpattagn[i][pat_num],gpattaga[i][pat_num],
	gpattagb[i][pat_num]); */
     }
     av_sim/=laynods[laynum];
  }
  return(av_sim);
}
init()
{
	char filename[10];
	printf("\n");
	printf("**********************\n");
	printf("*    initalization   *\n");
	printf("**********************\n");
	printf("Please input start filename(*.str)..");
	scanf("%s",filename);
	printf("loading %s...\n",filename);
	starfile(filename);
	build_link(1); 
	readpat(trafile);

}

set_par()
{
 char key;
  printf("Please input parameter value...\n");
  printf("Conclusion learning rate:(%1.5f) ",lr_con);
  scanf("%f",&lr_con);
  printf("Premise learning rate:(%1.5f) ",lr_pre);
  scanf("%f",&lr_pre);
  printf("Momentum:(%1.5f) ",momentum);
  scanf("%f",&momentum);
  printf("Stopping threshold: (%1.5f)",threshold);
  scanf("%f",&threshold);
  printf("no. of epcoh %d ",noepcoh);
  scanf("%d",&noepcoh);
  printf("background running(y/n)?");
  scanf("%s",&key);
  bg_fg=0;
  if(key=='y')
    bg_fg=1;
  if(bg_fg==1)
  {
  	printf("report file name:(%s)",rep_file);
  	scanf("%s",rep_file);
  	printf("weight file name:(%s)",wfile);
  	scanf("%s",wfile);
   }
}

on_line_test()
{
 int i,j;
 char ch;
 float mse,err;
 printf("On-LINE test\n");
 while(1)
 {
   for(i=1;i<=laynods[1];i++)
	{
	  printf("Please input data(m n a b) for node %d...",i);
	  scanf("%f %f %f %f", &patm[i][0], &patn[i][0], &pata[i][0], &patb[i][0]);
	}  
  for(i=1;i<=laynods[laynum];i++)
	{
	  printf("Please input target output %d...",i);
	  scanf("%f %f %f %f", &pattagm[i][0],&pattagn[i][0],&pattaga[i][0],&pattagb[i][0]);
	}
	
   compute_output(0);
   for(i=1;i<=laynods[laynum];i++)
			{
				/*j=i-first[laynum]+1;
				err=pattag[j][0]-outm[laynum][i];
				mse+=err*err/2;
				printf("out %d: %1.2f  target: %1.2f\n",i,outm[laynum][i], pattag[j][0]);*/
				printf("o%d: %1.2f %1.2f %1.2f %1.2f\n",i,outm[laynum][i],outn[laynum][i],
					outa[laynum][i],outb[laynum][i]);
			}
  /* printf("Pss= %3.3f\n",mse);*/
   printf("Continue (y/n)?",ch);
   scanf("%s",&ch);
   if(ch=='n')
	break;
  }
}

write_rep(cycle,pss)
int cycle;
float pss;
{
	FILE *fptr;
	int i,j,k;
	char weight[4];
	fptr=fopen(rep_file,"w");
	printf("write to report table-\n");
 	fprintf(fptr,"cycle no: %d pss: %1.6f conclusion learning rate %1.5f premise learning rate %1.5f\npat=%s",cycle-1,pss,lr_con,lr_pre,patfile);

	fclose(fptr);

}


build_data()
{
 int i,j,no_instance;
 char ch,mod,train_file[10],buffer1[80],buffer[256];
 float mse,err,range_l[10],range_h[10];
 FILE *fptr;

 printf("Please input training filename:");
 scanf("%s",train_file);
 fptr=fopen(train_file,"w");
 printf("manual or automatic (m/a)?");
 scanf("%s",&mod);
 if(mod=='m')
 {
   while(1)
   {
   for(i=1;i<=laynods[1];i++)
	{
	  printf("Please input data(m n a b) for node %d: ",i);
	  /*scanf("%f %f %f %f", &patm[i][0], &patn[i][0], &pata[i][0], &patb[i][0]);*/
	  scanf("%f", &patm[i][0]);
	  pata[i][0]=.2;
	  patb[i][0]=.2;
	fprintf(fptr,"%1.2f %1.2f %1.2f %1.2f",patm[i][0],patn[i][0], pata[i][0],patb[i][0]);
 	} 
   compute_output(0); 
   
   for(i=1;i<=laynods[laynum];i++)
	{
 	  fprintf(fptr,"%1.2f ",outm[laynum][i]);
	  printf("out[%d]=%1.3f\n",i,outm[laynum][i]);
	}
	 fprintf(fptr,"\n");
    printf("Continue (y/n)?");
   scanf("%s",&ch);
   if(ch=='n')
	break;
    }
  }
  else
  {  
      printf("How many instances?");
      scanf("%d",&no_instance);
      for(i=1;i<=laynods[1];i++)
	{
/*
    	  printf("Please input range for node %d(lower and upper)",i);
          scanf("%f %f",&range_l[i],&range_h[i]);
*/
	  range_l[i]=0;
 	  range_h[i]=1;
	}
      for(i=1;i<=no_instance;i++)
      {
         buffer[0]='\0';
	 for(j=1;j<=laynods[1];j++)
	{
	   patm[j][0]=rnd(range_h[j]-range_l[j])+range_l[j];
	   patn[j][0]=rnd(.3);
	   patm[j][0]-=patn[j][0]/2;
	   if (patm[j][0]<0) patm[j][0]=0;
 	   patn[j][0]+=patm[j][0];
	   if (patn[j][0]>1) patn[j][0]=1;
	   pata[j][0]=rnd(.3);
	   patb[j][0]=rnd(.3);
	   sprintf(buffer1,"%1.4f %1.4f %1.4f %1.4f ",patm[j][0],patn[j][0],pata[j][0],patb[j][0]);
	   strcat(buffer, buffer1);
	 }
         compute_output(0); 
         if((outm[laynum][1]==0.0) && (outn[laynum][1]==1.0))
         	i--;
         else
         {
         fprintf(fptr,"%s",buffer);
         for(j=1;j<=laynods[laynum];j++)
	 {
 	  fprintf(fptr,"%1.2f %1.2f %1.2f %1.2f ",outm[laynum][j],outn[laynum][j],
 	  		outa[laynum][j],outb[laynum][j]);
	  printf("instance %d out[%d]=%1.3f\n",i,j,outm[laynum][j]);
	  }
	 fprintf(fptr,"\n");
	 }
       }
   }
	fclose(fptr);
}



/****************************************
 * compare the sim. degree of two rules *
 ****************************************/
float comp_rule(ra,rb)
RULE *ra,*rb; 
{   
  RULE *ta,*tb,*oa=ra,*ob=rb,*tmp;
  float min_sim,s_deg,s1;
  float m1,n1,a1,b1,m2,n2,a2,b2;
  int found;
  tmp=rb;
    min_sim=1;
    found=0;
    while(ra->next != NULL)
    {
        ta=ra->next;
	rb=tmp;
	while(rb->next != NULL)
	{
    	    tb=rb->next;
	    if((ta->layer == tb->layer) && (ta->node == tb->node))
	    {
		m1=ta->m;n1=ta->n;
		a1=ta->a;b1=ta->b;
		m2=tb->m;n2=tb->n;
		a2=tb->a;b2=tb->b;
	      	s_deg=similarity(m1,n1,a1,b1,m2,n2,a2,b2);
		if (s_deg<min_sim) 
		  min_sim = s_deg;
		found=1;
	     }
	     rb=rb->next;
	 }
/*
	 if((found ==0) || (min_sim == 0.0))
	 {
	     ra=NULL;
	  }
	 else 
*/
	 ra=ra->next;
      }
    if (found == 0) 
      s1=0;
    else
      s1=min_sim;
      
    ra=ob;rb=oa;
    min_sim=1;
    found=0;
    while(ra->next != NULL)
    {
        ta=ra->next;
	rb=oa;
	while(rb->next != NULL)
	{
    	    tb=rb->next;
	    if((ta->layer == tb->layer) && (ta->node == tb->node))
	    {
		m1=ta->m;n1=ta->n;
		a1=ta->a;b1=ta->b;
		m2=tb->m;n2=tb->n;
		a2=tb->a;b2=tb->b;
	      	s_deg=similarity(m1,n1,a1,b1,m2,n2,a2,b2);
		if (min_sim>s_deg) 
		  min_sim=s_deg;
		found=1;
	     }
	     rb=rb->next;
	 }
	 ra=ra->next;
      }
      if(found == 0) min_sim=0;
      if (s1 > min_sim ) 
        return (s1);
      else return min_sim;
}

/***************************************
 * return the dimension of the premise *
 ***************************************/
int dim_rule(p)
RULE *p;
{
	int i=0;
	while(p->next != NULL)
	{
	    i++;
	    p=p->next;
	}
	return i;
}

/***************************************
 * return the dimension of the premise *
 ***************************************/
list_rule(p)
RULE *p;
{	
  int i,j,maxset[maxnod];
  RULE *tmp;
  float sim_model,smax[maxnod];
  
  while(p->next != NULL) {
    tmp=p->next;
    for (i=0;i<=2;i++) {
      smax[i]=0;
      for (j=0;j<fmodel[i].no_set;j++) {
        sim_model=similarity(tmp->m,tmp->n,tmp->a,tmp->b,fmodel[i].lr[j][0]
	  ,fmodel[i].lr[j][1],fmodel[i].lr[j][2],fmodel[i].lr[j][3]);
        if (sim_model>smax[i]) {
	  maxset[i]=j;
	  smax[i]=sim_model;
	}
      }  
    }  
    printf("%d: %d (%1.2f, %1.2f, %1.2f, %1.2f)\n",tmp->layer,tmp->node,
      tmp->m,tmp->n,tmp->a,tmp->b);
    for (i=0;i<2;i++)  
      printf("model (%2d,%2d,%1.2f) ",i,maxset[i],smax[i]);
    printf("\n");  
    p=p->next;
  }
  return;
}

/******************
 * rb = (ra+rb)/2 *
 ******************/
combine_rule(ra,rb,weight)
RULE *ra,*rb ;
int weight;
{   
   RULE *ta,*tb;
   while(ra->next != NULL) {
     ta=ra->next;
     while(rb->next != NULL) {
       tb=rb->next;
       if((ta->layer == tb->layer) && (ta->node == tb->node)) {
		tb->m=(tb->m*weight+ta->m)/(weight+1);
		tb->n=(tb->n*weight+ta->n)/(weight+1);
		tb->a=(tb->a*weight+ta->a)/(weight+1);
		tb->b=(tb->b*weight+ta->b)/(weight+1);
	     }
	      rb=rb->next;
	 }
	  ra=ra->next;
      }
}

m_test()
{
  int i,j;
  char select;
  do {
    do {
    printf("Enter ID1 and ID 2 (0 0 to quit)");
    scanf("%d %d",&i,&j);
    if (i==0 && j==0) return;
    } while (i<1||j<1||i>g_no||j>g_no);
  list_rule(gcpre[i]);
  list_rule(gccon[i]);
  list_rule(gcpre[j]);
  list_rule(gccon[j]);

  printf("dimension: %d, %d\n",dim_rule(gcpre[i]),dim_rule(gcpre[j]));  
  printf("similarity: %1.3f %1.3f\n",comp_rule(gcpre[i],gcpre[j]),
       comp_rule(gccon[i],gccon[j]));
  } while(1);
  return;
}

float stest(rid,mode)  /* test of specific rule */
int rid,mode;
{
  int i,j,pat_num,exist=0;
  int index,fire=0,fire_flag;
  int lindex[maxlay],lrecord[maxnod]; 
  RULE *tmp,*tmp2,*tmp3;
  float tt_mse,mse,err,av_mse;
  char weight[3];
  ct_node *p;
  
  if (patnum==0)
    return;
    /* build temp links */
    for (i=1;i<=maxlay;i++)
      if (i%2)
        lindex[i]=1;
      else  
        lindex[i]=0;
    index=1;
    tmp3=gcpre[rid];
    tmp2=gccon[rid]->next;
    lindex[tmp2->layer-1]++;
	  while(tmp3->next != NULL) {
	    tmp=tmp3->next;
	    tmp2=gccon[rid]->next;
	    tmtab[index].lh=tmp->layer;
	    tmtab[index].head=tmp->node;
	    tmtab[index].lt=tmp2->layer-1;
	    tmtab[index].tail =lindex[tmp2->layer-1];
	    tmtab[index].cm = tmp->m;
	    tmtab[index].cn = tmp->n;
	    tmtab[index].ca = tmp->a;
	    tmtab[index].cb = tmp->b;

        if (mode==1)
	printf("%d:%d-->%d:%d weight: %1.3f %1.3f %1.3f %1.3f %s\n",
			tmtab[index].lh,
			tmtab[index].head,
			tmtab[index].lt,
			tmtab[index].tail,
			tmtab[index].cm,
			tmtab[index].cn,/* 4 */
			tmtab[index].ca,
			tmtab[index].cb,
			weight);
		tmp3=tmp3->next;
		index++;
	  }
	  lrecord[rid]=lindex[tmp2->layer-1];

	 /* build conclusion links */
	     tmp=gccon[rid]->next;
		tmtab[index].lh=tmp->layer-1;
		tmtab[index].head=lrecord[rid];
		tmtab[index].lt=tmp->layer;
		tmtab[index].tail =tmp->node;
		tmtab[index].cm = tmp->m;
		tmtab[index].cn = tmp->n;
		tmtab[index].ca = tmp->a;
		tmtab[index].cb = tmp->b;
        if (mode==1)
	printf("%d:%d-->%d:%d weight: %1.3f %1.3f %1.3f %1.3f %s\n",
			tmtab[index].lh,
			tmtab[index].head,
			tmtab[index].lt,
			tmtab[index].tail,
			tmtab[index].cm,
			tmtab[index].cn,/* 4 */
			tmtab[index].ca,
			tmtab[index].cb,
			weight);
	index++;		
	no_link=index-1;      
	
	for (i=2;i<laynum;i++) 
	  tlaynods[i]=lindex[i];
        tlaynods[1]=laynods[1];
        tlaynods[laynum]=laynods[laynum];	  
        if (mode==1) 
	for (i=1;i<=laynum;i++) 
          printf("%2d nodes at layer %2d\n",tlaynods[i],i);
  if (mode==1)        	  
  for (i=1;i<=no_link;i++) {
        printf("%d %d %d %d %1.2f %1.2f %1.2f %1.2f\n",
 			tmtab[i].lh,tmtab[i].head,tmtab[i].lt,tmtab[i].tail,
			tmtab[i].cm,tmtab[i].cn,tmtab[i].ca,tmtab[i].cb);
  }  
  if (mode==1)
    printf("Total links %d\n",no_link);
  build_tlink();
  tt_mse=0;
  av_sim=0;
  av_sim2=0;
  for (pat_num=1;pat_num<=patnum;pat_num++) {
    mse=0;
    fire_flag=(scompute_output(pat_num));
    if (fire_flag)
      fire++;
    for(i=1;i<=tlaynods[laynum];i++) {
      /* fuzzy target */
      err=(pattagm[i][pat_num]-outm[laynum][i])*
        (pattagm[i][pat_num]-outm[laynum][i])+
        (pattagn[i][pat_num]-outn[laynum][i])*
        (pattagn[i][pat_num]-outn[laynum][i])+
        (pattaga[i][pat_num]-outa[laynum][i])*
        (pattaga[i][pat_num]-outa[laynum][i])+
        (pattagb[i][pat_num]-outb[laynum][i])*
        (pattagb[i][pat_num]-outb[laynum][i]);
        sim=similarity(pattagm[i][pat_num],pattagn[i][pat_num],
         pattaga[i][pat_num],pattagb[i][pat_num],
         outm[laynum][i],outn[laynum][i],outa[laynum][i],outb[laynum][i]);
      av_sim+=sim; 
      if (fire_flag)
        av_sim2+=sim;  
        if (mode==1)
          printf("err %1.3f\n",err);
        mse+=err/2;
        if (mode==1)
          printf("o%d: %1.2f %1.2f %1.2f %1.2f d: %1.2f %1.2f %1.2f %1.2f \n",
          i,outm[laynum][i],outn[laynum][i],outa[laynum][i],outb[laynum][i],
          pattagm[i][pat_num],pattagn[i][pat_num],pattaga[i][pat_num],
          pattagb[i][pat_num]);
    }
    tt_mse+=mse; 
  }
  av_mse=tt_mse/patnum;
  av_sim/=patnum;
  if (fire!=0)
    av_sim2/=fire;
    printf("fired: %d/%d\n",fire,patnum);
    printf("Average Pss= %3.6f\n",av_mse);
    printf("Average Accuracy:\n");
    printf("Total=%1.5f Fired=%1.5f\n",av_sim,av_sim2);
  return(av_sim2);
}

float stest2(cid,kid,mode)   /* for conlict rules */
int cid,kid,mode;
{
  int i,j,pat_num,exist=0;
  int index;
  int cflag;
  int lindex[maxlay],lrecord[maxnod]; 
  RULE *tmp,*tmp2,*tmp3;
  float tt_mse,mse,err,av_mse;
  char weight[3];
  
  if (patnum==0)
    return;
    /* build temp links */
    for (i=1;i<=maxlay;i++)
      if (i%2)
        lindex[i]=1;
      else  
        lindex[i]=0;
    index=1;
    for (i=1;i<=g_no;i++) {
      cflag=0;
      for (j=1;j<=conflist[cid][0];j++) {
        if (conflist[cid][j]==i)
          cflag=1;
      }   
      if (cflag && i!=kid)
        continue; 
      else {      
      tmp3=gcpre[i];
      tmp2=gccon[i]->next;
      lindex[tmp2->layer-1]++;
  	  while(tmp3->next != NULL) {
	    tmp=tmp3->next;
	    tmp2=gccon[i]->next;
	    tmtab[index].lh=tmp->layer;
	    tmtab[index].head=tmp->node;
	    tmtab[index].lt=tmp2->layer-1;
	    tmtab[index].tail =lindex[tmp2->layer-1];
	    tmtab[index].cm = tmp->m;
	    tmtab[index].cn = tmp->n;
	    tmtab[index].ca = tmp->a;
	    tmtab[index].cb = tmp->b;

        if (mode==1)
	printf("%d:%d-->%d:%d weight: %1.3f %1.3f %1.3f %1.3f %s\n",
			tmtab[index].lh,
			tmtab[index].head,
			tmtab[index].lt,
			tmtab[index].tail,
			tmtab[index].cm,
			tmtab[index].cn,/* 4 */
			tmtab[index].ca,
			tmtab[index].cb,
			weight);
		tmp3=tmp3->next;
		index++;
	  }
	lrecord[i]=lindex[tmp2->layer-1];
      }	
    }
         
	 /* build conclusion links */
    for (i=1;i<=g_no;i++) {
      cflag=0;
      for (j=1;j<=conflist[cid][0];j++) 
        if (conflist[cid][j]==i)
          cflag=1;
      if (cflag && i!=kid) 
        continue;
      else {   
	tmp=gccon[i]->next;
		tmtab[index].lh=tmp->layer-1;
		tmtab[index].head=lrecord[i];
		tmtab[index].lt=tmp->layer;
		tmtab[index].tail =tmp->node;
		tmtab[index].cm = tmp->m;
		tmtab[index].cn = tmp->n;
		tmtab[index].ca = tmp->a;
		tmtab[index].cb = tmp->b;
        if (mode==1)
	printf("%d:%d-->%d:%d weight: %1.3f %1.3f %1.3f %1.3f %s\n",
			tmtab[index].lh,
			tmtab[index].head,
			tmtab[index].lt,
			tmtab[index].tail,
			tmtab[index].cm,
			tmtab[index].cn,/* 4 */
			tmtab[index].ca,
			tmtab[index].cb,
			weight);
	index++;	
      }	
    }
	no_link=index-1;      
  	
	for (i=2;i<laynum;i++) 
	  tlaynods[i]=lindex[i];
        tlaynods[1]=laynods[1];
        tlaynods[laynum]=laynods[laynum];	  
        if (mode==1) 
	for (i=1;i<=laynum;i++) 
          printf("%2d nodes at layer %2d\n",tlaynods[i],i);
  if (mode==1)        	  
  for (i=1;i<=no_link;i++) {
        printf("%d %d %d %d %1.2f %1.2f %1.2f %1.2f\n",
 			tmtab[i].lh,tmtab[i].head,tmtab[i].lt,tmtab[i].tail,
			tmtab[i].cm,tmtab[i].cn,tmtab[i].ca,tmtab[i].cb);
  }  
  if (mode==1)
    printf("Total links %d\n",no_link);
  build_tlink();
  tt_mse=0;
  av_sim=0;
  for (pat_num=1;pat_num<=patnum;pat_num++) {
    mse=0;
    scompute_output(pat_num);
    for(i=1;i<=tlaynods[laynum];i++) {
      /* fuzzy target */
      err=(pattagm[i][pat_num]-outm[laynum][i])*
        (pattagm[i][pat_num]-outm[laynum][i])+
        (pattagn[i][pat_num]-outn[laynum][i])*
        (pattagn[i][pat_num]-outn[laynum][i])+
        (pattaga[i][pat_num]-outa[laynum][i])*
        (pattaga[i][pat_num]-outa[laynum][i])+
        (pattagb[i][pat_num]-outb[laynum][i])*
        (pattagb[i][pat_num]-outb[laynum][i]);
        sim=similarity(pattagm[i][pat_num],pattagn[i][pat_num],
         pattaga[i][pat_num],pattagb[i][pat_num],
         outm[laynum][i],outn[laynum][i],outa[laynum][i],outb[laynum][i]);
      av_sim+=sim;   
        if (mode==1)
          printf("err %1.3f\n",err);
        mse+=err/2;
        if (mode==1)
          printf("o%d: %1.2f %1.2f %1.2f %1.2f d: %1.2f %1.2f %1.2f %1.2f \n",
          i,outm[laynum][i],outn[laynum][i],outa[laynum][i],outb[laynum][i],
          pattagm[i][pat_num],pattagn[i][pat_num],pattaga[i][pat_num],
          pattagb[i][pat_num]);
    }
    tt_mse+=mse; 
  }
  av_mse=tt_mse/patnum;
  av_sim/=patnum;
  if (mode==1) {
    printf("Average Pss= %3.6f\n",av_mse);
    printf("Average Accuracy=%1.5f\n",av_sim);
  }
  return(av_sim);
}

float stestt(gnum,mode)   /* test temp rules */
int gnum,mode;
{
  int i,j,pat_num,exist=0;
  int index;
  int lindex[maxlay],lrecord[maxnod]; 
  RULE *tmp,*tmp2,*tmp3;
  float tt_mse,mse,err,av_mse;
  char weight[3];
  
  if (patnum==0)
    return;
    /* build temp links */
    for (i=1;i<=maxlay;i++)
      if (i%2)
        lindex[i]=1;
      else  
        lindex[i]=0;
    index=1;
    for (i=1;i<=gnum;i++) {
      if (tmgcact[i]==0)
        continue; 
      else {      
      tmp3=gcpre[i];
      tmp2=gccon[i]->next;
      lindex[tmp2->layer-1]++;
  	  while(tmp3->next != NULL) {
	    tmp=tmp3->next;
	    tmp2=gccon[i]->next;
	    tmtab[index].lh=tmp->layer;
	    tmtab[index].head=tmp->node;
	    tmtab[index].lt=tmp2->layer-1;
	    tmtab[index].tail =lindex[tmp2->layer-1];
	    tmtab[index].cm = tmp->m;
	    tmtab[index].cn = tmp->n;
	    tmtab[index].ca = tmp->a;
	    tmtab[index].cb = tmp->b;

        if (mode==1)
	printf("%d:%d-->%d:%d weight: %1.3f %1.3f %1.3f %1.3f %s\n",
			tmtab[index].lh,
			tmtab[index].head,
			tmtab[index].lt,
			tmtab[index].tail,
			tmtab[index].cm,
			tmtab[index].cn,/* 4 */
			tmtab[index].ca,
			tmtab[index].cb,
			weight);
		tmp3=tmp3->next;
		index++;
	  }
	lrecord[i]=lindex[tmp2->layer-1];
      }	
    }
         
	 /* build conclusion links */
    for (i=1;i<=gnum;i++) {
      if (tmgcact[i]==0)
        continue;
      else {   
	tmp=gccon[i]->next;
		tmtab[index].lh=tmp->layer-1;
		tmtab[index].head=lrecord[i];
		tmtab[index].lt=tmp->layer;
		tmtab[index].tail =tmp->node;
		tmtab[index].cm = tmp->m;
		tmtab[index].cn = tmp->n;
		tmtab[index].ca = tmp->a;
		tmtab[index].cb = tmp->b;
        if (mode==1)
	printf("%d:%d-->%d:%d weight: %1.3f %1.3f %1.3f %1.3f %s\n",
			tmtab[index].lh,
			tmtab[index].head,
			tmtab[index].lt,
			tmtab[index].tail,
			tmtab[index].cm,
			tmtab[index].cn,/* 4 */
			tmtab[index].ca,
			tmtab[index].cb,
			weight);
	index++;	
      }	
    }
	no_link=index-1;      
  	
	for (i=2;i<laynum;i++) 
	  tlaynods[i]=lindex[i];
        tlaynods[1]=laynods[1];
        tlaynods[laynum]=laynods[laynum];	  
        if (mode==1) 
	for (i=1;i<=laynum;i++) 
          printf("%2d nodes at layer %2d\n",tlaynods[i],i);
  if (mode==1)        	  
  for (i=1;i<=no_link;i++) {
        printf("%d %d %d %d %1.2f %1.2f %1.2f %1.2f\n",
 			tmtab[i].lh,tmtab[i].head,tmtab[i].lt,tmtab[i].tail,
			tmtab[i].cm,tmtab[i].cn,tmtab[i].ca,tmtab[i].cb);
  }  
  if (mode) 
    printf("Total links %d\n",no_link);
  build_tlink();
  tt_mse=0;
  av_sim=0;
  for (pat_num=1;pat_num<=patnum;pat_num++) {
    mse=0;
    scompute_output(pat_num);
    for(i=1;i<=tlaynods[laynum];i++) {
      /* fuzzy target */
      err=(pattagm[i][pat_num]-outm[laynum][i])*
        (pattagm[i][pat_num]-outm[laynum][i])+
        (pattagn[i][pat_num]-outn[laynum][i])*
        (pattagn[i][pat_num]-outn[laynum][i])+
        (pattaga[i][pat_num]-outa[laynum][i])*
        (pattaga[i][pat_num]-outa[laynum][i])+
        (pattagb[i][pat_num]-outb[laynum][i])*
        (pattagb[i][pat_num]-outb[laynum][i]);
        sim=similarity(pattagm[i][pat_num],pattagn[i][pat_num],
         pattaga[i][pat_num],pattagb[i][pat_num],
         outm[laynum][i],outn[laynum][i],outa[laynum][i],outb[laynum][i]);
      av_sim+=sim;   
        if (mode==1)
          printf("err %1.3f\n",err);
        mse+=err/2;
        if (mode==1)
          printf("o%d: %1.2f %1.2f %1.2f %1.2f d: %1.2f %1.2f %1.2f %1.2f \n",
          i,outm[laynum][i],outn[laynum][i],outa[laynum][i],outb[laynum][i],
          pattagm[i][pat_num],pattagn[i][pat_num],pattaga[i][pat_num],
          pattagb[i][pat_num]);
    }
    tt_mse+=mse; 
  }
  av_mse=tt_mse/patnum;
  av_sim/=patnum;
  if (mode==1) {
    printf("Average Pss= %3.6f\n",av_mse);
    printf("Average Accuracy=%1.5f\n",av_sim);
  }  
  return(av_sim);
}

float stest3(pid,rid,mode)    /* rules for specific pattern*/
int pid,rid,mode;
{
  int i,j,pat_num,exist=0;
  int index,fire=0,fire_flag;
  int lindex[maxlay],lrecord[maxnod]; 
  RULE *tmp,*tmp2,*tmp3;
  float tt_mse,mse,err,av_mse;
  char weight[3];
  ct_node *p;
  
  if (patnum==0)
    return;
    /* build temp links */
    for (i=1;i<=maxlay;i++)
      if (i%2)
        lindex[i]=1;
      else  
        lindex[i]=0;
    index=1;
    tmp3=gcpre[rid];
    tmp2=gccon[rid]->next;
    lindex[tmp2->layer-1]++;
	  while(tmp3->next != NULL) {
	    tmp=tmp3->next;
	    tmp2=gccon[rid]->next;
	    tmtab[index].lh=tmp->layer;
	    tmtab[index].head=tmp->node;
	    tmtab[index].lt=tmp2->layer-1;
	    tmtab[index].tail =lindex[tmp2->layer-1];
	    tmtab[index].cm = tmp->m;
	    tmtab[index].cn = tmp->n;
	    tmtab[index].ca = tmp->a;
	    tmtab[index].cb = tmp->b;

        if (mode==1)
	printf("%d:%d-->%d:%d weight: %1.3f %1.3f %1.3f %1.3f %s\n",
			tmtab[index].lh,
			tmtab[index].head,
			tmtab[index].lt,
			tmtab[index].tail,
			tmtab[index].cm,
			tmtab[index].cn,/* 4 */
			tmtab[index].ca,
			tmtab[index].cb,
			weight);
		tmp3=tmp3->next;
		index++;
	  }
	  lrecord[rid]=lindex[tmp2->layer-1];

	 /* build conclusion links */
	     tmp=gccon[rid]->next;
		tmtab[index].lh=tmp->layer-1;
		tmtab[index].head=lrecord[rid];
		tmtab[index].lt=tmp->layer;
		tmtab[index].tail =tmp->node;
		tmtab[index].cm = tmp->m;
		tmtab[index].cn = tmp->n;
		tmtab[index].ca = tmp->a;
		tmtab[index].cb = tmp->b;
        if (mode==1)
	printf("%d:%d-->%d:%d weight: %1.3f %1.3f %1.3f %1.3f %s\n",
			tmtab[index].lh,
			tmtab[index].head,
			tmtab[index].lt,
			tmtab[index].tail,
			tmtab[index].cm,
			tmtab[index].cn,/* 4 */
			tmtab[index].ca,
			tmtab[index].cb,
			weight);
	index++;		
	no_link=index-1;      
	
	for (i=2;i<laynum;i++) 
	  tlaynods[i]=lindex[i];
        tlaynods[1]=laynods[1];
        tlaynods[laynum]=laynods[laynum];	  
        if (mode==1) 
	for (i=1;i<=laynum;i++) 
          printf("%2d nodes at layer %2d\n",tlaynods[i],i);
  if (mode==1)        	  
  for (i=1;i<=no_link;i++) {
        printf("%d %d %d %d %1.2f %1.2f %1.2f %1.2f\n",
 			tmtab[i].lh,tmtab[i].head,tmtab[i].lt,tmtab[i].tail,
			tmtab[i].cm,tmtab[i].cn,tmtab[i].ca,tmtab[i].cb);
  }  
  if (mode==1)
    printf("Total links %d\n",no_link);
  build_tlink();
  tt_mse=0;
  av_sim=0;
  av_sim2=0;
    mse=0;
    fire_flag=(scompute_output(pid));
    if (fire_flag)
      fire++;
    for(i=1;i<=tlaynods[laynum];i++) {
      /* fuzzy target */
      err=(pattagm[i][pid]-outm[laynum][i])*
        (pattagm[i][pid]-outm[laynum][i])+
        (pattagn[i][pid]-outn[laynum][i])*
        (pattagn[i][pid]-outn[laynum][i])+
        (pattaga[i][pid]-outa[laynum][i])*
        (pattaga[i][pid]-outa[laynum][i])+
        (pattagb[i][pid]-outb[laynum][i])*
        (pattagb[i][pid]-outb[laynum][i]);
        sim=similarity(pattagm[i][pid],pattagn[i][pid],
         pattaga[i][pid],pattagb[i][pid],
         outm[laynum][i],outn[laynum][i],outa[laynum][i],outb[laynum][i]);
      av_sim+=sim; 
      if (fire_flag)
        av_sim2+=sim;  
        if (mode==1)
          printf("err %1.3f\n",err);
        mse+=err/2;
        if (mode==1)
          printf("o%d: %1.2f %1.2f %1.2f %1.2f d: %1.2f %1.2f %1.2f %1.2f \n",
          i,outm[laynum][i],outn[laynum][i],outa[laynum][i],outb[laynum][i],
          pattagm[i][pid],pattagn[i][pid],pattaga[i][pid],
          pattagb[i][pid]);
    }
    tt_mse+=mse; 
  av_mse=tt_mse;
  /*
    printf("fired: %d/%d\n",fire,patnum);
    printf("Average Pss= %3.6f\n",av_mse);
    printf("Average Accuracy:\n");
    printf("Total=%1.5f Fired=%1.5f\n",av_sim,av_sim2); */
  return(av_sim2);
}

float stest4(pid,rid,mode)    /* rules for specific phantom patterns*/
int pid,rid,mode;
{
  int i,j,pat_num,exist=0;
  int index,fire=0,fire_flag;
  int lindex[maxlay],lrecord[maxnod]; 
  RULE *tmp,*tmp2,*tmp3;
  float tt_mse,mse,err,av_mse;
  char weight[3];
  ct_node *p;
  
    /* build temp links */
    for (i=1;i<=maxlay;i++)
      if (i%2)
        lindex[i]=1;
      else  
        lindex[i]=0;
    index=1;
    tmp3=gcpre[rid];
    tmp2=gccon[rid]->next;
    lindex[tmp2->layer-1]++;
	  while(tmp3->next != NULL) {
	    tmp=tmp3->next;
	    tmp2=gccon[rid]->next;
	    tmtab[index].lh=tmp->layer;
	    tmtab[index].head=tmp->node;
	    tmtab[index].lt=tmp2->layer-1;
	    tmtab[index].tail =lindex[tmp2->layer-1];
	    tmtab[index].cm = tmp->m;
	    tmtab[index].cn = tmp->n;
	    tmtab[index].ca = tmp->a;
	    tmtab[index].cb = tmp->b;

        if (mode==1)
	printf("%d:%d-->%d:%d weight: %1.3f %1.3f %1.3f %1.3f %s\n",
			tmtab[index].lh,
			tmtab[index].head,
			tmtab[index].lt,
			tmtab[index].tail,
			tmtab[index].cm,
			tmtab[index].cn,/* 4 */
			tmtab[index].ca,
			tmtab[index].cb,
			weight);
		tmp3=tmp3->next;
		index++;
	  }
	  lrecord[rid]=lindex[tmp2->layer-1];

	 /* build conclusion links */
	     tmp=gccon[rid]->next;
		tmtab[index].lh=tmp->layer-1;
		tmtab[index].head=lrecord[rid];
		tmtab[index].lt=tmp->layer;
		tmtab[index].tail =tmp->node;
		tmtab[index].cm = tmp->m;
		tmtab[index].cn = tmp->n;
		tmtab[index].ca = tmp->a;
		tmtab[index].cb = tmp->b;
        if (mode==1)
	printf("%d:%d-->%d:%d weight: %1.3f %1.3f %1.3f %1.3f %s\n",
			tmtab[index].lh,
			tmtab[index].head,
			tmtab[index].lt,
			tmtab[index].tail,
			tmtab[index].cm,
			tmtab[index].cn,/* 4 */
			tmtab[index].ca,
			tmtab[index].cb,
			weight);
	index++;		
	no_link=index-1;      
	
	for (i=2;i<laynum;i++) 
	  tlaynods[i]=lindex[i];
        tlaynods[1]=laynods[1];
        tlaynods[laynum]=laynods[laynum];	  
        if (mode==1) 
	for (i=1;i<=laynum;i++) 
          printf("%2d nodes at layer %2d\n",tlaynods[i],i);
  if (mode==1)        	  
  for (i=1;i<=no_link;i++) {
        printf("%d %d %d %d %1.2f %1.2f %1.2f %1.2f\n",
 			tmtab[i].lh,tmtab[i].head,tmtab[i].lt,tmtab[i].tail,
			tmtab[i].cm,tmtab[i].cn,tmtab[i].ca,tmtab[i].cb);
  }  
  if (mode==1)
    printf("Total links %d\n",no_link);
  build_tlink();
  tt_mse=0;
  av_sim=0;
  av_sim2=0;
    mse=0;
    fire_flag=(scompute_output2(pid));
    if (fire_flag)
      fire++;
    for(i=1;i<=tlaynods[laynum];i++) {
      /* fuzzy target */
      err=(pattagm[i][pid]-outm[laynum][i])*
        (gpattagm[i][pid]-outm[laynum][i])+
        (gpattagn[i][pid]-outn[laynum][i])*
        (gpattagn[i][pid]-outn[laynum][i])+
        (gpattaga[i][pid]-outa[laynum][i])*
        (gpattaga[i][pid]-outa[laynum][i])+
        (gpattagb[i][pid]-outb[laynum][i])*
        (gpattagb[i][pid]-outb[laynum][i]);
        sim=similarity(gpattagm[i][pid],gpattagn[i][pid],
         gpattaga[i][pid],gpattagb[i][pid],
         outm[laynum][i],outn[laynum][i],outa[laynum][i],outb[laynum][i]);
      av_sim+=sim; 
      if (fire_flag)
        av_sim2+=sim;  
        if (mode==1)
          printf("err %1.3f\n",err);
        mse+=err/2;
        if (mode==1)
          printf("o%d: %1.2f %1.2f %1.2f %1.2f d: %1.2f %1.2f %1.2f %1.2f \n",
          i,outm[laynum][i],outn[laynum][i],outa[laynum][i],outb[laynum][i],
          gpattagm[i][pid],gpattagn[i][pid],gpattaga[i][pid],
          gpattagb[i][pid]);
    }
    tt_mse+=mse; 
  av_mse=tt_mse;
  /*
    printf("fired: %d/%d\n",fire,patnum);
    printf("Average Pss= %3.6f\n",av_mse);
    printf("Average Accuracy:\n");
    printf("Total=%1.5f Fired=%1.5f\n",av_sim,av_sim2); */
  return(av_sim2);
}

check()
{
  int loop=0,done=0;
  char select;
  int i;
  float result;
  do {
		printf("\n");
		printf("**********************\n");
		printf("*    NVV Rev 0.1     *\n");
		printf("*    Check menu       *\n");
		printf("**********************\n");
		printf("1. Consistency Check\n");
		printf("2. List Rules\n");
		printf("3. Rule test\n");
		printf("4. Remove conflict rules\n");
		printf("5. Insert rules\n");
		printf("6. Delete rules\n");
		printf("7. Delete rules manually\n");
		printf("8. Similarity check \n");
		printf("0. go to main nenu\n");
		printf("select a function...");
		scanf("%s",&select);
		switch(select)
		{
		case '1':
		  ccheck();
		  done=1;
		  break;
		case '2':
		  tranlink();
		  lrule();
		  break;
		case '3':
		  tranlink();
		  do {  
                    printf("Enter Rule ID(%d to %d, 0 to quit)",1,g_no);
                    scanf("%d",&i);  
                    if(i==0)
                      break; 
                    if (i>0 && i<=g_no) {
                      printf("Test result of rule %2d:\n",i);
                      lrule(i);
                      result=stest(i,1);
                    }  
                  } while (1);
			break;
		case '4':
		  if (done) 
		    rconflict();
	          break;
		case '5':
		  tranlink();
		  insert_rule();
		  break;	
		case '6':
		  tranlink();
		  delete_rule();
		      break;        
		case '7':
		  tranlink();
		  man_delete();
		      break;
		case '8':
		  tranlink();
		  m_test();
		  break;        
		case '0':
		  loop=1;
		  break;
		default:
			printf("error!\n");
		}
	  if (select!='1')
	    done=0;	
	}  while(loop==0);
}

conflict(cgroup,cmember)
int cgroup;
int cmember;
{
  int i,found;
  for (i=1;i<20;i++)
    if (conflist[cgroup][i]==0)
      break;
  conflist[cgroup][0]++;    
  conflist[cgroup][i]=cmember;
  conflist[cgroup][i+1]=0;
  return;
}  

rconflict()
{
  int i,j,flag=1;
  int cnumber,delete;
  int drule,dmax,dmin;
  char select;
  float temp[maxnod],old_sim;
  table confdata[max];
  
  batest(0);
  old_sim=av_sim;
  printf("\nConflict list:\n\n");
  for (i=1;i<maxnod;i++)
    if (conflist[i][0]>1) {
      flag=0;
      dmin=maxnod;
      dmax=0;
      printf("conflict at group %d:\n",i);
      cnumber=conflist[i][0];
      printf("Number of rules: %d\n",cnumber);
      for (j=1;j<=cnumber;j++) {
        confdata[j-1].id=conflist[i][j];
        confdata[j-1].value=stest2(i,confdata[j-1].id,0); 
        printf("id:%2d, acc:%1.5f\n",confdata[j-1].id,confdata[j-1].value);        
      }
      qsort(confdata,cnumber,sizeof(table),tcompare); 
      for (j=1;j<=cnumber;j++) {
        drule=dim_rule(gcpre[confdata[j-1].id]);
        if (drule>dmax)
          dmax=drule;
        if (drule<dmin)
          dmin=drule;      
        printf("member at group %2d dim %2d\n",confdata[j-1].id,drule);
        list_rule(gcpre[confdata[j-1].id]);
        list_rule(gccon[confdata[j-1].id]);
        printf("Accuracy:%1.5f\n",confdata[j-1].value);   
      }
      printf("Performance test of deletion:\n");
      for (j=1;j<g_no;j++)
        tmgcact[j]=1;
      for (j=1;j<=cnumber;j++) {
        tmgcact[confdata[j-1].id]=0;
        printf("Delete rule No.%3d: D=%2d %1.5f\n",confdata[j-1].id,dim_rule(gcpre[confdata[j-1].id]),stestt(g_no,0));
      }     
      printf("Max dim: %2d, min dim: %2d\n",dmax,dmin);
      printf("ICE suggests to be careful with low dimension rules!\n");
      printf("How many rules to be deleted automatically (up to %d)?",cnumber);
      scanf("%d",&delete);
      if (delete<0)
        delete=0;
      if (delete>cnumber)
        delete=cnumber;
      for (j=cnumber-delete+1;j<=cnumber;j++) {
        printf("Deleting rule No.%d\n",confdata[j-1].id);  
        gcact[confdata[j-1].id]=0;
      }  
    }
  if (flag) {
    printf ("No conflict found yet..\n");
    return;
  }
  printf("Rules to be deleted:\n");
  for(i=1;i<=g_no;i++) 
    if (gcact[i]==0) {
      printf("rule %3d %2d \n",i,dim_rule(gcpre[i]));
    }  
  printf("\n");     
  printf("Are you sure to delete this rule?");
  scanf("%s",&select);
  if (select=='Y'||select=='y') 
    tranrule(0);
    batest(0);
    printf("Accuracy: old=%1.5f new=%1.5f",old_sim,av_sim);
    if (av_sim<old_sim)
      printf("Suggestion: insert rules\n");
  else 
    for (i=1;i<=g_no;i++)
      gcact[i]=1;
  return;  
}

insert_rule()
{
  int i,j,k,itemp,insert,tindex;
  table pattern[max];
  char select;
  RULE *r;
  float ftemp,top;
  
  printf("Test of original patterns\n");
  for (i=1;i<=patnum;i++) {
    pattern[i-1].value=test2(i);
    printf("pat %2d: %1.5f\n",i,pattern[i-1].value);  
  }
  do {
   printf("Threshold for Clustering? (from 0 to 1)");
   scanf("%f",&ftemp);
  } while (ftemp<0 && ftemp>1); 
  p_cluster(ftemp);
  printf("Test of pattern clusters\n");
  for (i=1;i<=pg_no;i++) {
    pattern[i-1].value=test3(i);

    printf("pat %2d: %1.5f\n",i,pattern[i-1].value);  
  }  
  /* sort patterns */
  for (i=1;i<=pg_no;i++)
    pattern[i-1].id=i;
  qsort(pattern,pg_no,sizeof(table),tcompare);  
  for (i=1;i<=pg_no;i++)
    printf("Cluster %3d, accuracy=%1.5f\n",pattern[i-1].id,pattern[i-1].value);
  do {
    printf("How many rules to be previewed? (up to %d)",pg_no);
    scanf("%d",&k);
  } while (k<0 && k>pg_no);
  batest(0);
  printf("Original accuracy: %1.5f\n",av_sim);
  top=0;
  for (i=1;i<=k;i++) {
    append_link(i,pattern[i-1],0);
    ftemp=stestt(g_no+i,0);
    printf("Accuracy at %4d %1.5f\n",i,ftemp);
    if (ftemp>top) {
      tindex=i;
      top=ftemp;
    }
  }
  printf("Top point:%3d   accuracy %1.5f\n",tindex,top);
  do {
    printf("How many rules to be inserted? (up to %d)",pg_no);
    scanf("%d",&insert);
  } while (insert<0&&insert>pg_no);
  printf("Insert %d rules\n",insert);
  for (i=k+1;i<=insert;i++) { 
    append_link(i,pattern[i-1],0);
  }  
  batest(0);  
  printf("Old Accuracy:%1.5f\n",av_sim);  
  printf("Accuracy at %4d: %1.5f\n",insert,stestt(g_no+insert,0));
  printf("Are you sure to insert these rules?");
  scanf("%s",&select);
  if (select=='Y'||select=='y') {
    g_no+=insert;
    tranrule(0);
  }  
  return;  
}

man_delete()
{
  int delete;
  char select;
  
  do {
    do {
      printf("Enter rule ID (from 1 to %d, 0 to quit)",g_no);
      scanf("%d",&delete);
    } while (delete<0&&delete>g_no);
  if (delete==0)
    break;
    list_rule(gcpre[delete]);
    list_rule(gccon[delete]);
    printf("Delete or Clear to unknown (D/C)");
    scanf("%s",&select);
    if (select=='D'||select=='d')     
      gcact[delete]=0;  
    if (select=='C'||select=='c') {
    printf("Clear premise?");
    scanf("%s",&select);
    if (select=='Y'||select=='y')  
      clear_rule(gcpre[delete]);
    printf("Clear conclusion?");
    scanf("%s",&select);
    if (select=='Y'||select=='y') 
      clear_rule(gccon[delete]);  
    }  
  } while (1); 
  
  printf("Perform actual change?");
  scanf("%s",&select);
  if (select=='Y'||select=='y') 
    tranrule(0);
  return;  
}

clear_rule(p)
RULE *p;
{	
  int i,j;
  RULE *tmp;
  
  while(p->next != NULL) {
    tmp=p->next;
    tmp->m=0.5;
    tmp->n=0.5;
    tmp->a=0;
    tmp->b=0;
    p=p->next;
  }
  return;
}

delete_rule()
{
  int i,j,delete;
  table rule[max];
  char select;
  RULE *r;
  
  printf("Performance test of of rules\n");
  for (i=1;i<=g_no;i++) {
    for (j=1;j<=g_no;j++) 
      tmgcact[j]=(j!=i);
    printf("Rule %3d\n",i);
    rule[i-1].id=i;
    /* list_rule(gcpre[i]);
    list_rule(gccon[i]); */
    rule[i-1].value=stestt(g_no,0);
  }
  qsort(rule,g_no,sizeof(table),tcompare);
  printf("Sorted rules\n"); 
  for (i=1;i<=g_no;i++) {
    printf("Rule %3d: %1.5f\n",rule[i-1].id,rule[i-1].value);
    /* list_rule(gcpre[rule[i-1].id]);
    list_rule(gccon[rule[i-1].id]); */
  }
  for (i=1;i<g_no;i++)
    tmgcact[i]=1;
  for (i=1;i<=g_no;i++) {
    tmgcact[rule[i-1].id]=0;
    printf("Delete Rule %3d  %1.4f\n",rule[i-1].id,stestt(g_no,0));
  }  
  do {
    printf("How many rules to be deleted? (up to %d)",g_no);
    scanf("%d",&delete);
  } while (delete<0&&delete>g_no);
  printf("Delete %d rules\n",delete);
  for (i=1;i<=delete;i++) { 
    printf("Delete rule %3d\n",rule[i-1].id);
    gcact[rule[i-1].id]=0;
  }  
  printf("Are you sure to delete these rule?");
  scanf("%s",&select);
  if (select=='Y'||select=='y') {
    tranrule(0);
    batest(0);
    printf("Accuracy: %1.5f\n",av_sim);
  }  
  return;  
}

tranrule(mode)
int mode;
{
  int i,j,index;

  RULE *tmp,*tmp2,*tmp3;
  int lindex[maxlay],lrecord[maxnod];
  
  index=1;
  for (i=1;i<maxlay;i++)
    lindex[i]=i%2;  
	for (i=1;i<=g_no;i++) {    /* build premise links */
	  if (gcact[i]==0)	            /* check if active */
	    continue;
	  tmp3=gcpre[i];
	  tmp2=gccon[i]->next;
	  lindex[tmp2->layer-1]++;
	  while(tmp3->next != NULL) {
	    tmp=tmp3->next;
	    tmp2=gccon[i]->next;
	    cotab[index].lh=tmp->layer;
	    cotab[index].head=tmp->node;
	    cotab[index].lt=tmp2->layer-1;
	    cotab[index].tail =lindex[tmp2->layer-1];
	    cotab[index].cm = tmp->m;
	    cotab[index].cn = tmp->n;
	    cotab[index].ca = tmp->a;
	    cotab[index].cb = tmp->b;
        if (mode)
	  printf("%d:%d-->%d:%d weight: %1.3f %1.3f %1.3f %1.3f \n",
			cotab[index].lh,
			cotab[index].head,
			cotab[index].lt,
			cotab[index].tail,
			cotab[index].cm,
			cotab[index].cn,/* 4 */
			cotab[index].ca,
			cotab[index].cb);
		tmp3=tmp3->next;
		index++;
	  }
	  lrecord[i]=lindex[tmp2->layer-1];
	}
        
	 /* build conclusion links */
	 for (i=1;i<=g_no;i++) {	
	   if (gcact[i]==0)        /* check if active */
	     continue;
	     tmp=gccon[i]->next;
		cotab[index].lh=tmp->layer-1;
		cotab[index].head=lrecord[i];
		cotab[index].lt=tmp->layer;
		cotab[index].tail =tmp->node;
		cotab[index].cm = tmp->m;
		cotab[index].cn = tmp->n;
		cotab[index].ca = tmp->a;
		cotab[index].cb = tmp->b;
        if (mode)
  	  printf("%d:%d-->%d:%d weight: %1.3f %1.3f %1.3f %1.3f\n",
			cotab[index].lh,
			cotab[index].head,
			cotab[index].lt,
			cotab[index].tail,
			cotab[index].cm,
			cotab[index].cn,/* 4 */
			cotab[index].ca,
			cotab[index].cb);
	index++;
      }			
      if (mode)
	printf("number of connections: %d\n", index-1);
	no_link=index-1;
      for (i=2;i<laynum;i++)
        laynods[i]=lindex[i];	
  /* under construction end*/
  build_link(mode);
  return;
}

p_cluster(pthr)
float pthr;
{
  int numgc[maxnod];
  int i,j,k,pweight;
  float p_sim,maxp_sim;
  
  pg_no=0;
  for (i=1;i<=maxnod;i++)
    numgc[i]=0;
  for (i=1;i<=patnum;i++) {
    maxp_sim=0;
    pg_max=0;
    for (j=1;j<=pg_no;j++) {
      p_sim=0;
      for (k=1;k<=laynods[laynum];k++) 
        p_sim+=similarity(gpattagm[k][j],pattagm[k][i],gpattagn[k][j],
        pattagn[k][i],gpattaga[k][j],pattaga[k][i],gpattagb[k][j],
        pattagb[k][i]);
      p_sim/=laynods[laynum];
      /* printf("test p%2d g%2d sim%1.3f\n",i,j,p_sim);  */
      if (maxp_sim<p_sim) { 
        pg_max=j;
        maxp_sim=p_sim;  
      }
    }
     printf("test point %d,pg_max:%2d,maxp_sim=%1.2f\n",i,pg_max,maxp_sim);
    if (maxp_sim<pthr) {
      printf("Create cluster for pat %3d\n",i);   
      pg_no++;
      for (k=1;k<=laynods[1];k++) {
        gpatm[k][pg_no]=patm[k][i];
        gpatn[k][pg_no]=patn[k][i];
        gpata[k][pg_no]=pata[k][i];
        gpatb[k][pg_no]=patb[k][i];
        gpattagm[k][pg_no]=pattagm[k][i];
        gpattagn[k][pg_no]=pattagn[k][i];
        gpattaga[k][pg_no]=pattaga[k][i];
        gpattagb[k][pg_no]=pattagb[k][i];
      }  
      numgc[pg_no]=1;
    } 
    else {
      printf("Combine pattern %3d\n",i);
      pweight=numgc[pg_max];
      numgc[pg_max]++;		
      for (k=1;k<=laynods[1];k++) {
        gpatm[k][pg_max]=(gpatm[k][pg_max]*pweight+patm[k][i])/(pweight+1);
        gpatn[k][pg_max]=(gpatn[k][pg_max]*pweight+patn[k][i])/(pweight+1);
        gpata[k][pg_max]=(gpata[k][pg_max]*pweight+pata[k][i])/(pweight+1);
        gpatb[k][pg_max]=(gpatb[k][pg_max]*pweight+patb[k][i])/(pweight+1);
        gpattagm[k][pg_max]=(gpattagm[k][pg_max]*pweight+pattagm[k][i])/(pweight+1);
        gpattagn[k][pg_max]=(gpattagn[k][pg_max]*pweight+pattagn[k][i])/(pweight+1);
        gpattaga[k][pg_max]=(gpattaga[k][pg_max]*pweight+pattaga[k][i])/(pweight+1);
        gpattagb[k][pg_max]=(gpattagb[k][pg_max]*pweight+pattagb[k][i])/(pweight+1);
      }  	
    }
  }
  printf("Total pattern groups:%d\n",pg_no);
  return;  
}  
  
ccheck()
{
        char select;
 	char buffer[80],buffer1[20];
	int i,j,k;
	ct_node *p,*q;
	int numgc[maxnod];
	int numred,numsub,numconf;
	float max_simp,max_simc,presim,consim;
	RULE *r;
	GROUP *g;
	float sthreshold=0.8;
	/* addedd by torch */
	int wi,wj,wk,wl,index=1;
	float m,n,a,b;	/* 4 */
	char weight[3];

        r_no=1;
        g_no=0;
        numred=0;
        numsub=0;
        numconf=0;
	for(i=1;i<maxnod;i++) {
	  premise[i]=(RULE *)malloc(sizeof(RULE));
	  conclusion[i]=(RULE *)malloc(sizeof(RULE));
	  group[i]=(GROUP *)malloc(sizeof(GROUP));
	  gcpre[i]=(RULE *)malloc(sizeof(RULE));
	  gccon[i]=(RULE *)malloc(sizeof(RULE));
		numgc[i]=0;
		premise[i]->next=NULL;
		conclusion[i]->next=NULL;
		group[i]->next=NULL; /* recording the member of each group */
		gcpre[i]->next=NULL; /* center of group */
		gccon[i]->next=NULL;
	     }
	printf("Threshold? (from 0 to 1) ");
	scanf("%f",&sthreshold);     
	if (sthreshold==0)
	  sthreshold=0.000001;
	if (sthreshold>1)
	  sthreshold=1;  
	for(i=2;i<=laynum;i+=2)  /* for each conjunction layer */
	    for(j=1;j<=laynods[i];j++)    /* for each node */
            {
		 p=ct_head[i][j];
		 q=ct_tail[i][j];

		 /* premise part */
		 sprintf(buffer,"\n  IF ");
		 while(p->next != NULL) /* for each link lead to the node */
		  {
		    	r=(RULE *)malloc(sizeof(RULE));
			r->next = premise[r_no]->next;
			premise[r_no]->next = r;
			r->node = cotab[p->ct_id].head;
			r->layer = cotab[p->ct_id].lh;
			r->m = cotab[p->ct_id].cm;
			r->n = cotab[p->ct_id].cn;
			r->a = cotab[p->ct_id].ca;
			r->b = cotab[p->ct_id].cb;
 		  	p=p->next;
		  }
		 while(q->next != NULL)  /* concluseion part */
		  {
			r=(RULE *)malloc(sizeof(RULE));
			r->next = conclusion[r_no]->next;
			conclusion[r_no]->next = r;
			r->node = cotab[q->ct_id].tail;
			r->layer = cotab[q->ct_id].lt;
			r->m = cotab[q->ct_id].cm;
			r->n = cotab[q->ct_id].cn;
			r->a = cotab[q->ct_id].ca;
			r->b = cotab[q->ct_id].cb;
 		  	q=q->next;
		  }
		  r_no++;
	     }

	for(i=1;i<r_no;i++)  /* list all rules */
{
		conflist[i][0]=0;
		printf("Rule #%3d\n",i);
		list_rule(premise[i]);
		list_rule(conclusion[i]);
}

	for(i=1;i<r_no;i++)
	   {
		max_simp=0;
		max_simc=0;
	        g_max=0;
		consim=0;
		g=(GROUP *)malloc(sizeof(GROUP));
		for(j=1;j<g_no+1;j++)
		{
		   presim= comp_rule(premise[i],gcpre[j]);
		   consim= comp_rule(conclusion[i],gccon[j]);
		   if (max_simp<presim || (max_simp==presim&&max_simc<consim))
		   {
			max_simp = presim;
			g_max = j;
			max_simc=consim;
		   }
		}
	printf("test point %d,g_max:%d,max_simp=%1.2f, %1.2f\n",i,g_max,max_simp,max_simc);
		if(max_simp < sthreshold) /*no cluster near this premise, */
		{			/* form a new cluster */
		    g_no++;
		    group[g_no]->next=g;
		    g->next=NULL;
		    g->number=i;
		    assign_rule(premise[i], &gcpre[g_no]);
		    assign_rule(gcpre[g_no],&gcpre[g_no]);
		    assign_rule(conclusion[i], &gccon[g_no]);
		    numgc[g_no]=1;
		    gcact[g_no]=1;
		    if (conflist[g_no][0]==0)
		      conflict(g_no,g_no);
		printf ("new group %2d formed by rule %3d\n",g_no,i);    
		list_rule(premise[i]);
		list_rule(conclusion[i]);
		printf("dimension: %2d\n",dim_rule(gcpre[g_no]));
		} /* add the premise to the cluster which it is closest to, */
		else /* and adjust the cluster center */
		{
		    printf("candidate: rule %2d\n",i);
		    list_rule(premise[i]);
		    list_rule(conclusion[i]);
		    printf("Group center: %2d\n",g_max);
		    list_rule(gcpre[g_max]);
		    list_rule(gccon[g_max]);
		    if (max_simc<sthreshold) {
		      g_no++;
		      group[g_no]->next=g;
		      g->next=NULL;
		      g->number=i;
		      assign_rule(premise[i], &gcpre[g_no]);
		      assign_rule(gcpre[g_no],&gcpre[g_no]);
		      assign_rule(conclusion[i], &gccon[g_no]);
		      numgc[g_no]=1;
		      gcact[g_no]=1;
                      if (g_max!=g_no) 
                        conflict(g_max,g_no);
                      numconf++;
		      printf("conflict rule!\n");
	              printf ("new group %2d formed by rule %3d\n",g_no,i);    
		      list_rule(premise[i]);
		      list_rule(conclusion[i]);
		      printf("dimension: %2d\n",dim_rule(gcpre[g_no])); 
		    }
		    else {
		      g->next=group[g_max]->next;
		      g->number=i; /* premise i belongs to group g_max */
		      group[g_max]->next=g;
		      if (dim_rule(premise[i]) == dim_rule(gcpre[g_max])) {
			combine_rule(premise[i],gcpre[g_max],numgc[g_max]);
			combine_rule(conclusion[i],gccon[g_max],numgc[g_max]);
                        numgc[g_max]++;
                        numred++;
                        printf("Deleted: redundant\n");
                        printf("Change value of group %2d to:\n",g_max);
                        list_rule(gcpre[g_max]);
                        list_rule(gccon[g_max]);
                      }    
		      else if (dim_rule(premise[i]) < dim_rule(gcpre[g_max])) {
			/* free the memory of gc[g_max], not implemented */
			/* assign premise i to gc[g_max] */
			assign_rule(premise[i],&gcpre[g_max]);
	                assign_rule(conclusion[i],&gccon[g_max]);
	                numgc[g_max]=1;
	                printf("Replace current group center\n");		
                      } 
                      else { 
                        printf("Deleted: subsumed\n");
                        numsub++;
                        };   
                      printf("rule:%d  group:%d\n",dim_rule(premise[i]),dim_rule(gcpre[g_max]));  
		      };
		    };  
	    }
	for(i=1;i<=g_no;i++)
        {
		printf("Group %2d\n",i);
		printf("premise:\n");
		list_rule(gcpre[i]);
		printf("conclusion:\n");
		list_rule(gccon[i]);
        }
  printf("redundant: %d subsume %d conflict %2d\n",numred,numsub,numconf);      
  printf("Perform change to weight?");
  scanf("%s",&select);
  if (select=='Y'||select=='y') 
    tranrule(0);
  return;       
} 

append_link(rid,tpattern,mode)
int rid;
table tpattern;
int mode;
{
  int k;
  RULE *r,tmprule;
  
    for (k=1;k<=laynods[1];k++) {
      r=(RULE *)malloc(sizeof(RULE));
      r->next = gcpre[g_no+rid]->next;
      gcpre[g_no+rid]->next = r;
      r->node = k;
      r->layer =1; 
      r->m = gpatm[k][tpattern.id];
      r->n = gpatn[k][tpattern.id];
      r->a = gpata[k][tpattern.id];
      r->b = gpatb[k][tpattern.id];
    }
    assign_rule(gcpre[g_no+rid],&gcpre[g_no+rid]);
    for (k=1;k<=laynods[laynum];k++) {
      r=(RULE *)malloc(sizeof(RULE));
      r->next = gccon[g_no+rid]->next;
      gccon[g_no+rid]->next = r;
      r->node = k;
      r->layer =laynum; 
      r->m = gpattagm[k][tpattern.id];
      r->n = gpattagn[k][tpattern.id];
      r->a = gpattaga[k][tpattern.id];
      r->b = gpattagb[k][tpattern.id];
    }
    if (mode) {
      list_rule(gcpre[g_no+rid]);
      list_rule(gccon[g_no+rid]);
    }  
    gcact[g_no+rid]=1;
    tmgcact[g_no+rid]=1;
  return;
}

tranlink()  /* transfer links to rules */
{
        char select;
 	char buffer[80],buffer1[20];
	int i,j,k;
	ct_node *p,*q;
	int numgc[maxnod];
	int numred, numconf;
	RULE *r;
	GROUP *g;
	/* addedd by torch */
	int wi,wj,wk,wl,index=1;
	float m,n,a,b;	/* 4 */
	char weight[3];

        r_no=1;
        g_no=0;
          
	for(i=1;i<maxnod;i++) {
	  conflist[i][0]=0;
	  premise[i]=(RULE *)malloc(sizeof(RULE));
	  conclusion[i]=(RULE *)malloc(sizeof(RULE));
	  group[i]=(GROUP *)malloc(sizeof(GROUP));
	  gcpre[i]=(RULE *)malloc(sizeof(RULE));
	  gccon[i]=(RULE *)malloc(sizeof(RULE));
		numgc[i]=0;
		premise[i]->next=NULL;
		conclusion[i]->next=NULL;
		group[i]->next=NULL; /* recording the member of each group */
		gcpre[i]->next=NULL; /* center of group */
		gccon[i]->next=NULL;
	     }
	for(i=2;i<=laynum;i+=2)  /* for each conjunction layer */
	    for(j=1;j<=laynods[i];j++)    /* for each node */
            {
		 p=ct_head[i][j];
		 q=ct_tail[i][j];

		 /* premise part */
		 sprintf(buffer,"\n  IF ");
		 while(p->next != NULL) /* for each link lead to the node */
		  {
		    	r=(RULE *)malloc(sizeof(RULE));
			r->next = premise[r_no]->next;
			premise[r_no]->next = r;
			r->node = cotab[p->ct_id].head;
			r->layer = cotab[p->ct_id].lh;
			r->m = cotab[p->ct_id].cm;
			r->n = cotab[p->ct_id].cn;
			r->a = cotab[p->ct_id].ca;
			r->b = cotab[p->ct_id].cb;
 		  	p=p->next;
		  }
		 while(q->next != NULL)  /* concluseion part */
		  {
			r=(RULE *)malloc(sizeof(RULE));
			r->next = conclusion[r_no]->next;
			conclusion[r_no]->next = r;
			r->node = cotab[q->ct_id].tail;
			r->layer = cotab[q->ct_id].lt;
			r->m = cotab[q->ct_id].cm;
			r->n = cotab[q->ct_id].cn;
			r->a = cotab[q->ct_id].ca;
			r->b = cotab[q->ct_id].cb;
 		  	q=q->next;
		  }
		  r_no++;
	     }

	for(i=1;i<r_no;i++)
	   {
		g=(GROUP *)malloc(sizeof(GROUP));
		    g_no++;
		    group[g_no]->next=g;
		    g->next=NULL;
		    g->number=i;
		    assign_rule(premise[i], &gcpre[g_no]);
		    assign_rule(gcpre[g_no],&gcpre[g_no]);
		    assign_rule(conclusion[i], &gccon[g_no]);
		    numgc[g_no]=1;
		    gcact[g_no]=1;
		    tmgcact[g_no]=1;
		    if (conflist[g_no][0]==0)
		      conflict(g_no,g_no);
	    }
	/*    
	for(i=1;i<=g_no;i++)
        {
		printf("Group %2d\n",i);
		printf("premise:\n");
		list_rule(gcpre[i]);
		printf("conclusion:\n");
		list_rule(gccon[i]);
        } */
  tranrule(0);
  return;       
} 

/***************************
 * assign rule a to rule b *
 ***************************/
assign_rule(ra,rb)
RULE *ra,**rb; 
{   RULE *ta,*tb;
    *rb=(RULE *)malloc(sizeof(RULE));
    (*rb)->next=NULL;
    while (ra->next != NULL)
    {
    	ta=ra->next;
	tb=(RULE *)malloc(sizeof(RULE));
	tb->next = (*rb)->next;
	tb->layer= ta->layer ;
	tb->node= ta->node ;
	tb->m= ta->m;
	tb->n= ta->n;
	tb->a= ta->a;
	tb->b= ta->b;
	(*rb)->next = tb;
	ra=ra->next;
     }
}

/* batch test of network model*/


/* clear record of weight change */
clear()
{
  int i;
  for (i=0;i<max;i++) {
    errec[i]=0;
    cflag[i]=0;
  }
  return;
}

static int fcompare(i,j)
float *i,*j;
{
  return(*i<*j);
}

esort()
{
  int rank[max],i,j,limit,flag;
  float temp[max];
  
  scount++; 
  if (!lmode) {
    for (i=1;i<max;i++) {
      cflag[i]=1;
    }
    return;
  }    
  
  limit=0;
  for (i=0;i<max;i++) { 
    temp[i]=errec[i];
    if (errec[i]>0)
      limit++;
  } 
  qsort(temp,max,sizeof(float),fcompare);
  for (i=0;i<max;i++) { 
    flag=0;
    for (j=0;j<max&&!flag;j++) 
      if (errec[i]>=temp[j]) { 
        rank[i]=j+1;
        flag=1;
      }
    if (rank[i]<=(limit/sfact+1)||!lmode)  
      cflag[i]=1;
  }  
  return;
}



list_link()
{
  FILE *WFile;
  char FileName[FileNameMax];
  int l;
  float max_sim,sim;
  char term_flag[5];
  
  printf("Please input weight file name: ");
  scanf("%s",FileName);
  WFile = fopen(FileName,"w");
  for (l=1;l<=no_link;l++) {
        max_sim=0;
        term_flag[0]='\0';
        sim=similarity(.0, .2, .0, .1, cotab[l].cm,cotab[l].cn,cotab[l].ca,cotab[l].cb);
        if(sim > max_sim)
          {
             max_sim=sim;
             term_flag[0]='\0';
             strcat(term_flag,"T1");
          }             
        sim=similarity(.35, .65, .1, .1, cotab[l].cm,cotab[l].cn,cotab[l].ca,cotab[l].cb);
        if(sim > max_sim)
          {
             max_sim=sim;
             term_flag[0]='\0';
             strcat(term_flag,"T2");
          }        
        sim=similarity(.8, 1.0, .1, .0, cotab[l].cm,cotab[l].cn,cotab[l].ca,cotab[l].cb);
        if(sim > max_sim)
          {
             max_sim=sim;
             term_flag[0]='\0';
             strcat(term_flag,"T3");
          }   
        sim=similarity(.0, .1, .0, .1, cotab[l].cm,cotab[l].cn,cotab[l].ca,cotab[l].cb);
        if(sim > max_sim)
          {
             max_sim=sim;
             term_flag[0]='\0';
             strcat(term_flag,"F1");
          }   
        sim=similarity(.25, .4, .1, .15, cotab[l].cm,cotab[l].cn,cotab[l].ca,cotab[l].cb);
        if(sim > max_sim)
          {
             max_sim=sim;
             term_flag[0]='\0';
             strcat(term_flag,"F2");
          }
        sim=similarity(.6, .75, .15, .1, cotab[l].cm,cotab[l].cn,cotab[l].ca,cotab[l].cb);
        if(sim > max_sim)
          {
             max_sim=sim;
             term_flag[0]='\0';
             strcat(term_flag,"F3");
          } 
        sim=similarity(.9, 1.0, .1, .0, cotab[l].cm,cotab[l].cn,cotab[l].ca,cotab[l].cb);
        if(sim > max_sim)
          {
             max_sim=sim;
             term_flag[0]='\0';
             strcat(term_flag,"F4");
          }      
        printf("%d %d %d %d %1.2f %1.2f %1.2f %1.2f => %s  %1.4f\n",
 			cotab[l].lh,cotab[l].head,cotab[l].lt,cotab[l].tail,
			cotab[l].cm,cotab[l].cn,cotab[l].ca,cotab[l].cb
			,term_flag,max_sim);
	fprintf(WFile,"%d %d %d %d %d %1.2f %1.2f %1.2f %1.2f\n",l,
 			cotab[l].lh,cotab[l].head,cotab[l].lt,cotab[l].tail,
			cotab[l].cm,cotab[l].cn,cotab[l].ca,cotab[l].cb);		
  }  
  printf("Total links %d\n",no_link);
  fclose(WFile);
  return;
}

/* put the new list_link() at 10/1 */

list_link_ori()
{
  int i,j,l,maxset[maxnod];
  float sim_model,smax[maxnod];
  
  for (l=1;l<=no_link;l++) {
    for (i=0;i<=2;i++) {
      smax[i]=0;
      for (j=0;j<fmodel[i].no_set;j++) {
        sim_model=similarity(cotab[l].cm,cotab[l].cn,cotab[l].ca,cotab[l].cb,
	  fmodel[i].lr[j][0],fmodel[i].lr[j][1],fmodel[i].lr[j][2],fmodel[i].lr[j][3]);
        if (sim_model>smax[i]) {
	  maxset[i]=j;
	  smax[i]=sim_model;
	}
      }
      printf("%d %d %d %d (%1.2f, %1.2f, %1.2f, %1.2f)\n",
      cotab[l].lh,cotab[l].head,cotab[l].lt,cotab[l].tail,
        cotab[l].cm,cotab[l].cn,cotab[l].ca,cotab[l].cb);
      for (j=0;j<2;j++)  
        printf("model (%2d,%2d,%1.2f) ",j,maxset[j],smax[j]);
      printf("\n");  			
    } 
  }   
  for (i=1;i<=laynum;i++) 
    printf("%2d nodes at layer %2d\n",laynods[i],i);
  printf("Total links %d\n",no_link);
  return;
}

lrule()
{
  int i;

  for(i=1;i<=g_no;i++) {
    printf("Rule %2d\n",i);
    printf("premise:\n");
    list_rule(gcpre[i]);
    printf("conclusion:\n");
    list_rule(gccon[i]);
  }
  printf("Number of rules: %d\n",g_no);
}
