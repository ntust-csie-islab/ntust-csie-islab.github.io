#include <stdio.h>
#define FileNameMax 12
#define VarMax 10

typedef struct WNode
{
 int index;
 float m;
 float n;
 float alfa;
 float beta;
 struct WNode *NextNode;
}WNode;

void ReadFile(WNode *WHead);
void WriteFile(WNode *WHead);
void ReadTest(WNode *WHead);

main()
{
 static WNode *WHead;
 WHead = (WNode *)malloc(sizeof(WNode));
 WHead->NextNode = NULL;
 ReadFile(WHead);
 ReadTest(WHead);
 WriteFile(WHead);
}

void ReadTest(WNode *WHead)
{
 FILE *TestFile;
 WNode *Wnow;
 TestFile = fopen("TestFile","w");
 Wnow = WHead;
 while(Wnow->NextNode != NULL)
  {
   Wnow = Wnow->NextNode;
   fprintf(TestFile,"%d %4.2f %4.2f %4.2f %4.2f\n",Wnow->index,
	   Wnow->m, Wnow->n, Wnow->alfa, Wnow->beta);
  }
 fclose(TestFile);
}

void WriteFile(WNode *WHead)
{
 FILE *NetForm, *WriteFile;
 char FileName[FileNameMax],variable[VarMax];
 int TermNum,cntr,index,ReturnFlag;
 WNode *Wnow;
 printf("\nplease input the name of output file : ");
 scanf("%s",FileName);
 WriteFile = fopen(FileName,"w");
 NetForm = fopen("NetForm","r");
 while(!feof(NetForm))
  {
   ReturnFlag = 1;
   fscanf(NetForm,"%d",&TermNum);
   fprintf(WriteFile,"%d ",TermNum);
   for(cntr=1;cntr<=TermNum;cntr++)
     {
      fscanf(NetForm,"%s",variable);
      fprintf(WriteFile,"%s ",variable);
      fscanf(NetForm,"%d",&index);
      Wnow = WHead;
      while(Wnow->index != index)
	 Wnow = Wnow->NextNode;
      fprintf(WriteFile,"%4.2f %4.2f %4.2f %4.2f ",Wnow->m,Wnow->n,
						Wnow->alfa,Wnow->beta);
      ReturnFlag *= -1;
      if (ReturnFlag == 1)
	fprintf(WriteFile,"\n");
     }
   if (ReturnFlag == -1)
     fprintf(WriteFile,"\n");
  }
 fclose(NetForm);
 fclose(WriteFile);
}

void ReadFile(WNode *WHead)
{
 FILE *WeightFile;
 char FileName[FileNameMax];
 int cntr,t1,t2,t3,t4;
 float m,n,alfa,beta;
 WNode *Wnow, *Wprevious, *Wnew;
 Wnow = WHead;
 printf("\nplease input weight file : ");
 scanf("%s",FileName);
 WeightFile = fopen(FileName,"r");
 while(!feof(WeightFile))
  {
   Wprevious = Wnow;
   Wnew = (WNode *)malloc(sizeof(WNode));
   Wnew->NextNode = NULL;
   fscanf(WeightFile,"%d %d %d %d %d", &cntr,&t1,&t2,&t3,&t4);
   fscanf(WeightFile,"%f %f %f %f", &m,&n,&alfa,&beta);
   Wnew->index = cntr;
   Wnew->m = m;
   Wnew->n = n;
   Wnew->alfa= alfa;
   Wnew->beta = beta;
   Wnow->NextNode = Wnew;
   Wnow = Wnew;
  }
 Wprevious->NextNode = NULL;
 free(Wnow);
 fclose(WeightFile);
}