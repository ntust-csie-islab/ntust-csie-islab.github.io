
/* file: multinnc.c  v1.0

         file for multiclasses neural network classifier with disjunctive fuzzy information.

         input : trapezoidal fuzzy number (m1, m2, al, b )
         author: Jiang I-Feng
         tel   : (02) 951-3388
         date  : 6/29/96 



/* file: expert.c

        file for hyperplane-hyperbox hybrid learning.
        input : fuzzy interval
        author: wade wang
        tel: 6667252
        Date of last revision:  8-23-92
*/

#include <math.h>
#include <time.h>
#include "general.h"
#include "variable.h"
#include "patterns.h"
#include "command.h"
#include "cl.h"

unsigned time1,time2,time3,time4;
clock_t  tick1,tick2;

char   *str = NULL;
char   *Prompt = "cl: ";
char   *Default_step_string = "epoch";

boolean System_Defined = FALSE;

boolean lflag = 1;              /* 1 = learning,     at learning phase 
                                   0 = not learning, at testing phase  */
                                
boolean proto_train = 1;        /* pocket algorithm learning flag */

int     class = 0;
int     count = 0;
int     tra_no = 0;
int     mis_flag = 0;
int     proto_no = 0;
int     iteration = 0;

int     nepochs = 0;
int     epochno = 0;

int     iris = 0;
int     pal = 0;        /* pecfuh 0;   avg 1;   lvq 2;   */
int     look = 0;
int     test_flag = 0;
int     pass = 2;
int     holap = 1;      /* the exemplars with same class can overlap */
int     no_phase1 = 0;
int     max_run_len = 1;
float   max_size = 0.3; /* size condition during pass2 -- gfence */
float   alpha = 0.002;  /* initial learning rate in dynpro       */
float   t_rate = 1.0;   /* the proportion of training set (%)    */



float   min_dist,dist;

float   lrate = 1.0;    /* learning rate during dynpro. decreasing when epoch ++ */ 

int     nunits = 0;
int     nhiddens = 0;           /* number of hidden units */ 
int     noutputs = 0;           /* number of output units */
int     ninputs = 0;            /* number of input units*/

float  **mean_value1_weight;    /* pointers to vectors of maximun weights */
float  **mean_value2_weight;    /* pointers to vectors of minimun weights */
float  **spread_a_weight;
float  **spread_b_weight;
float  **membership_height;  /* the largest is 1 for the nest prototype */
float  **fallLcount;  /* the # pattern falling the Left side of the prototype */
float  **fallRcount;  /* the # pattern falling the Right side of the prototype*/

int  intcount=0;    /* # input pattern */
float  down_rate=.99999;  /* decrese the membership hight */


float  *desired_out = NULL;
float  *activation = NULL;      /* activations for all units */

float  defuzzify_step = 0.0;
float  defuzzify_count = 0.0;
float  membershipvalue = 0.0;
float  defuzzification_result = 0.0;

float  *mean_value1 = NULL;     /* activations for all units */
float  *mean_value2 = NULL;     /* activations for all units */
float  *spread_a = NULL;        /* activations for all units */
float  *spread_b = NULL;        /* activations for all units */





float  **w_mean_value1 = NULL;  /* activations for all units */
float  **w_mean_value2 = NULL;  /* activations for all units */
float  **w_spread_a = NULL;     /* activations for all units */
float  **w_spread_b = NULL;     /* activations for all units */
float  *netinput = NULL;        /* sum of inputs for pool units */


float  **old_mean_value1_weight;   
float  **old_mean_value2_weight; 
float  **old_spread_a;
float  **old_spread_b; 


int   **p_node;
int   **old_p_node;
int   *p_node_index;
 
int    *old_use_flag=NULL;


float  **pnode_weight;


 
int    patno = 0;
int    winner = 0;
int    nonwin = 0;
int    tallflag = 0;            /* test all flag */

float  *classification_out = NULL;
float  *size = NULL;

int    *err_pattern = NULL;
int    *tra_pattern = NULL;
int    *class_flag = NULL;
int    *enode_win = NULL;
int    *use_train = NULL;
int    *use_flag = NULL;

int     no_of_misclassification = 0;
int     winner_no;
int     nhyperbox;              /* number of created hyperboxes */
int     mistake;
int     no_win;

int      train_error_number;
int      find_prototype_number =0 ;
int      max_prototype_node  ;
float    total_distant = 999 ;/* initial value of the total_distance */
float    old_distant   = 999 ; 

/****************/
define_system() {
/****************/
    int     i,j;

    if (noutputs <= 0) {
        put_error("cannot initialize weights without noutputs");
        return(FALSE);
    }

    if (ninputs <= 0) {
        put_error("cannot initialize weights without ninputs");
        return(FALSE);
    }

    nunits = ninputs + nhiddens + noutputs;
    no_of_misclassification = 0;
    nhyperbox = 0;
    
    if (activation != NULL) {
        free((char *) activation);
    }
    
    if (desired_out != NULL) {
        free((char *) desired_out);
    }

    if (netinput != NULL) {
        free((char *) netinput);
    }
    
    activation = (float *) emalloc((unsigned)(nunits * sizeof(float)));
    install_var("activation", Vfloat,(int *) activation, nunits,0,SETSVMENU);
    mean_value1 = (float *) emalloc((unsigned)(nunits * sizeof(float)));
    install_var("mean_value1", Vfloat,(int *) mean_value1, nunits,0,SETSVMENU);
    mean_value2 = (float *) emalloc((unsigned)(nunits * sizeof(float)));
    install_var("mean_value2", Vfloat,(int *) mean_value2, nunits,0,SETSVMENU);
    spread_a = (float *) emalloc((unsigned)(nunits * sizeof(float)));
    install_var("spread_a", Vfloat,(int *) spread_a, nunits,0,SETSVMENU);
    spread_b = (float *) emalloc((unsigned)(nunits * sizeof(float)));
    install_var("spread_b", Vfloat,(int *) spread_b, nunits,0,SETSVMENU);
    install_var("defuzzification_result", Float,(int *) & defuzzification_result, 0,0,NOMENU);
    netinput = (float *) emalloc((unsigned)(nunits * sizeof(float)));
    install_var("netinput", Vfloat,(int *) netinput, nunits,0,SETSVMENU);
    size = (float *) emalloc((unsigned)(nunits * sizeof(float)));
    install_var("size", Vfloat,(int *) size, nunits,0,SETSVMENU);
    use_flag = (int *) emalloc((unsigned)(nunits * sizeof(int)));
    install_var("use_flag", Vint,(int *) use_flag, nunits, 0, SETSVMENU);
    use_train = (int *) emalloc((unsigned)(noutputs * sizeof(int)));
    install_var("use_train", Vint,(int *) use_train, noutputs, 0, SETSVMENU);

    class_flag = (int *) emalloc((unsigned)(nunits * sizeof(int)));
    install_var("class_flag", Vint,(int *) class_flag, nunits, 0, SETSVMENU);

    p_node_index= (int *) emalloc((unsigned)(nunits * sizeof(int)));
    install_var("p_node_index", Vint,(int *) p_node_index, nunits, 0, SETSVMENU);

    


    desired_out = (float *) emalloc((unsigned)(noutputs * sizeof(float)));    
    install_var("desired_out", Vfloat,(int *)  desired_out, noutputs, 0, NOMENU);
    classification_out = (float *) emalloc((unsigned)(noutputs * sizeof(float)));    
    install_var("classification_out", Vfloat,(int *) classification_out, 0, 0, NOMENU);
    install_var("defuzzify_step", Float,(int *) & defuzzify_step, 0, 0, NOMENU);

    mean_value1_weight = ((float **) emalloc((unsigned)(nunits * sizeof(float *))));
    mean_value2_weight = ((float **) emalloc((unsigned)(nunits * sizeof(float *))));
    spread_a_weight = ((float **) emalloc((unsigned)(nunits * sizeof(float *))));
    spread_b_weight = ((float **) emalloc((unsigned)(nunits * sizeof(float *))));
    membership_height = ((float **) emalloc((unsigned)(nunits * sizeof(float *))));
    fallRcount = ((float **) emalloc((unsigned)(nunits * sizeof(float *))));
    fallLcount = ((float **) emalloc((unsigned)(nunits * sizeof(float *))));



   
    old_mean_value1_weight = ((float **) emalloc((unsigned)(nunits * sizeof(float *))));
    old_mean_value2_weight = ((float **) emalloc((unsigned)(nunits * sizeof(float *))));
    old_spread_a=((float **) emalloc((unsigned)(nunits * sizeof(float *))));
    old_spread_b=((float **) emalloc((unsigned)(nunits * sizeof(float *))));


    old_use_flag = (int *) emalloc((unsigned)(nunits * sizeof(int)));
    install_var("old_use_flag", Vint,(int *) old_use_flag, nunits, 0, SETSVMENU);
     
    pnode_weight = (( float ** ) emalloc((unsigned)(nhiddens * sizeof(float *)))); 
    p_node=( (int **) emalloc((unsigned)(nunits * sizeof(int))));
    old_p_node=( (int **) emalloc((unsigned)(nunits * sizeof(int))));


    w_mean_value1 = ((float **) emalloc((unsigned)(nunits * sizeof(float *))));
    w_mean_value2 = ((float **) emalloc((unsigned)(nunits * sizeof(float *))));
    w_spread_a = ((float **) emalloc((unsigned)(nunits * sizeof(float *))));
    w_spread_b = ((float **) emalloc((unsigned)(nunits * sizeof(float *))));

    install_var("mean_value1_weight", PVweight,(int *) 
                 mean_value1_weight, nunits, nunits,SETSVMENU);
    install_var("mean_value2_weight", PVweight,(int *) 
                 mean_value2_weight, nunits, nunits,SETSVMENU);
    install_var("spread_a_weight", PVweight,(int *) 
                 spread_a_weight, nunits, nunits,SETSVMENU);
    install_var("spread_b_weight", PVweight,(int *) 
                 spread_b_weight, nunits, nunits,SETSVMENU);
    install_var("membership_height", PVweight,(int *)
                 membership_height, nunits, nunits,SETSVMENU); /* shelly add*/
    install_var("fallLcount", PVweight,(int *)
                 fallLcount, nunits, nunits,SETSVMENU); /* shelly add*/
    install_var("fallRcount", PVweight,(int *)
                 fallRcount, nunits, nunits,SETSVMENU); /* shelly add*/


    install_var("pnode_weight",Vfloat,(int *) pnode_weight,nhiddens,noutputs,SETSVMENU);
    install_var("p_node", Vint,(int *) p_node, nunits, 150, SETSVMENU);
    install_var("old_p_node", Vint,(int *) old_p_node, nunits, 150, SETSVMENU);

    

    
    install_var("old_mean_value1_weight", PVweight,(int *) 
                 old_mean_value1_weight, nunits, nunits,SETSVMENU);
    install_var("old_mean_value2_weight", PVweight,(int *) 
                 old_mean_value2_weight, nunits, nunits,SETSVMENU);

    
    install_var("old_spread_a", PVweight,(int *) 
                 old_spread_a, nunits, nunits,SETSVMENU);
    install_var("old_spread_b", PVweight,(int *) 
                 old_spread_b, nunits, nunits,SETSVMENU);



    install_var("w_mean_value1", PVweight,(int *) 
                 w_mean_value1, nunits, nunits,SETSVMENU);
    install_var("w_mean_value2", PVweight,(int *) 
                 w_mean_value2, nunits, nunits,SETSVMENU);
    install_var("w_spread_a", PVweight,(int *) 
                 w_spread_a, nunits, nunits,SETSVMENU);
    install_var("w_spread_b", PVweight,(int *) 
                 w_spread_b, nunits, nunits,SETSVMENU);

    tra_pattern = (int *) emalloc((unsigned)(npatterns * sizeof(int)));
    err_pattern = (int *) emalloc((unsigned)(npatterns * sizeof(int)));
    enode_win = (int *) emalloc((unsigned)(nhiddens * sizeof(int)));
    install_var("err_pattern", Vint,(int *) err_pattern, npatterns, 0, SETSVMENU);
    install_var("tra_pattern", Vint,(int *) tra_pattern, npatterns, 0, SETSVMENU);
    install_var("enode_win", Vint,(int *) enode_win,nhiddens , 0, SETSVMENU);

    
    for (i = ninputs; i < nunits; i++) {
      mean_value1_weight[i] = ((float *) emalloc((unsigned) (ninputs / 4) * sizeof (float)));
      mean_value2_weight[i] = ((float *) emalloc((unsigned) (ninputs / 4) * sizeof (float)));
      spread_a_weight[i] = ((float *) emalloc((unsigned) (ninputs / 4) * sizeof (float)));
      spread_b_weight[i] = ((float *) emalloc((unsigned) (ninputs / 4) * sizeof (float)));
      membership_height[i] = ((float *) emalloc((unsigned) (ninputs / 4) * sizeof (float)));
      fallLcount[i] = ((float *) emalloc((unsigned) (ninputs / 4) * sizeof (float)));
      fallRcount[i] = ((float *) emalloc((unsigned) (ninputs / 4) * sizeof (float)));


      w_mean_value1[i] = ((float *) emalloc((unsigned) (ninputs / 4) * sizeof (float)));
      w_mean_value2[i] = ((float *) emalloc((unsigned) (ninputs / 4) * sizeof (float)));
      w_spread_a[i] = ((float *) emalloc((unsigned) (ninputs / 4) * sizeof (float)));
      w_spread_b[i] = ((float *) emalloc((unsigned) (ninputs / 4) * sizeof (float)));

      old_mean_value1_weight[i] = ((float *) emalloc((unsigned) (ninputs / 4) * sizeof (float)));
      old_mean_value2_weight[i] = ((float *) emalloc((unsigned) (ninputs / 4) * sizeof (float)));
      old_spread_a[i] = ((float *) emalloc((unsigned) (ninputs / 4) * sizeof (float)));
      old_spread_b[i] = ((float *) emalloc((unsigned) (ninputs / 4) * sizeof (float)));

            for (j = 0; j < (ninputs / 4); j++) {
          w_mean_value1[i][j] = 0.0;
          w_mean_value2[i][j] = 0.0;
          w_spread_a[i][j] = 0.0;
          w_spread_b[i][j] = 0.0;
          old_mean_value1_weight[i][j] = 0.0;
          old_mean_value2_weight[i][j] = 0.0;
          old_spread_a[i][j] = 0.0;
          old_spread_b[i][j] =0.0;

       }
    }
    
                  
    for (i=0 ; i< nhiddens ; i++)
      {
        pnode_weight[i]=((float *) emalloc((unsigned) (noutputs) * sizeof (float)));
        for(j=0; j< noutputs ;j++)
         pnode_weight[i][j]= 0.0;
      }

                   
    for (i=0 ; i< nunits ; i++)
      {
        p_node[i]=((int *) emalloc((unsigned) (150) * sizeof (int)));
        old_p_node[i]=((int *) emalloc((unsigned) (150) * sizeof (int)));
        for(j=0; j< 150 ;j++)
         {
           p_node[i][j]= 0;
           old_p_node[i][j]= 0;
         }

           
      }


    for (i = 0; i < nunits; i++) {
        netinput[i] = 0.0;        
        activation[i] = 0.0;
        mean_value1[i] = 0.0;
        mean_value2[i] = 0.0;
        spread_a[i] = 0.0;
        spread_b[i] = 0.0;
    }
    
    max_prototype_node=noutputs;

    new1();
    
    System_Defined = TRUE;
    return(TRUE);
}


/********************/
float membership_value(m1,m2,a,b,y) float m1,m2,a,b,y; {
/********************/
float membershipvalue;

   if  (y <= m2 && y >= m1)
       membershipvalue = 1.0;
   else {
     if  (y > m2) {
      if (b != 0)  
              if ((1 - (y - m2 ) / b) > 0.0)
                membershipvalue = (1 - ( y - m2 ) / b ); 
              else
                membershipvalue = 0.0;
      else
        membershipvalue = 0.0;  
     }
     else
      if  (y < m1) {
       if ( a != 0 ) 
             if ((1 - (m1 - y ) / a) > 0.0)
                membershipvalue = (1 - ( m1 - y ) / a);
              else
                membershipvalue = 0.0;
       else
        membershipvalue = 0.0; 
     }
   }
   return(membershipvalue);
/*   update_display();*/
}

/*****************************************/
defuzzification(t1,t2,u,v) float t1,t2,u,v; {
/*****************************************
float x,y,z;
    defuzzify_count = t1 - u;
    x = 0.0;
    y = 0.0;

    while ( (defuzzify_count >= t1 - u)  &&  (defuzzify_count <= t2 + v)){
       membership_value(t1,t2,u,v,defuzzify_count);
       x += defuzzify_count * membershipvalue;
       y += membershipvalue;
       defuzzify_count += defuzzify_step;
    }
    if (y != 0.0)
    defuzzification_result = x / y;
******************************************/
    defuzzification_result = (t1 + t2) / 2;
}

/********************/
float COA(k)int k; {
/********************/
        float cx;

        cx = ( activation[k*4] + activation[k*4+1] ) / 2.0
        + ( activation[k*4+3] - activation[k*4+2] ) / 4.0;
        return(cx);
}



/************/
float min(c,d) float c,d; {
/************/
   if (c > d)  return(d);
   else        return(c);
}

/************/
float max(c,d) float c,d; {
/************/
   if (c < d)  return(d);
   else        return(c);
}

/**********************/
float absolute_dist(x,y) float x,y; {
/**********************/
   float dist;
  
   dist = ( x - y ) * ( x - y );
   return ( dist );
}

/**********************/
float absolute_dist_op(x,y) float x,y; {
/**********************/
   float dist;

   if (x>y) dist=x-y;
   else dist=y-x;
   return ( dist );
}


/*************/
disp_weight() {
/*************/
   int    i,j,k;

/*   update_display();
   printf("\npal = %d  ",pal);
   printf("    winner =%3d",winner);
   printf("    t_rate =%6.3f",t_rate);
   printf("    msize =%6.3f",max_size);
   printf("    alpha=%6.3f",alpha);
*/
if (look > 4) {
   printf("\n\nlook =%3d",look);
   printf("    min_dist =%6.3f",min_dist);
   printf("    dist =%6.3f",dist);
}
   printf("\n\nno_box=%3d   base=%5u     ",nhyperbox,time4/1000);
/*   printf("pass1=%8u   p2.1=%8u     all=%8u",time1/1000,time2/1000,time3/1000
*/

   printf("\ntra_pattern = ");
   for ( i = 0; i < tra_no; i++)
         printf("%4d",tra_pattern[i]);

   printf("\nuse_pat_end= ");
   for ( i = 0; i < npatterns; i++)
         printf("%4d",used[i]);
/*
   printf("\nuse_train   = ");
   for ( i = 0; i < noutputs; i++)
         printf("%4d",use_train[i]);

   printf("\n\ndesired_out = ");
   for ( i = 0; i < noutputs; i++)
         printf("%5.0f",desired_out[i]*1000);

   printf("\nhidden_out  = ");
   for ( i = ninputs; i < ninputs + nhiddens/2; i++)
         printf("%5.0f",activation[i]*1000);

   printf("\nhidden_size = ");
   for ( i = ninputs; i < ninputs + nhiddens/2; i++)
         printf("%5.0f",size[i] * 4000 / ninputs);
*/
   printf("\nuse_flag_no = ");
/*   for ( i = ninputs; i < ninputs + nhiddens/2; i++)*/
   for ( i = ninputs; i < ninputs + nhyperbox; i++)
         printf(" %4d",use_flag[i]);

   printf("\nnet_inputs  = ");
   for ( i = 0; i < ninputs; i++)
         printf("%5.0f",activation[i]*1000);

   printf("\nnet_inputs_out = "); /* prototype output */
/*   for ( i = ninputs; i < ninputs + noutputs; i++)*/
   for ( i = ninputs; i < ninputs + nhyperbox; i++)
         printf("%5.0f ",activation[i]*1000);


   if (look == 2) {
      printf("\n\newin =%3d   match node =",no_win);
      for ( i = 0; i < nhiddens - noutputs; i++)
            printf("%5d",enode_win[i]);
      printf("\n");
   }
/*
for (i=0;i<13;i++)
printf("\n                                  ");
*/
   k = ninputs + no_phase1 * noutputs;
/*     k = ninputs ; */
 /*  for ( i = k; i < k + noutputs + nhyperbox ; i++) {*/
  for ( i = k; i < k + nhyperbox ; i++) {
       printf("\n *fall left[%d]",i);
       for ( j = 0; j < ninputs/4; j++)
           printf(" %3.0f",fallLcount[i][j]);
       printf("   *fall right[%d]",i);
       for ( j = 0; j < ninputs/4; j++)
           printf(" %3.0f",fallRcount[i][j]);

       printf("\n m1[%d]= ",i);
       for ( j = 0; j < ninputs/4; j++)
           printf("%4.0f",mean_value1_weight[i][j] * 1000);
       printf(" m2[c%d]  ",class_flag[i]);
       for ( j = 0; j < ninputs/4; j++)
           printf("%4.0f",mean_value2_weight[i][j] * 1000);
       printf(" a       ");
       for ( j = 0; j < ninputs/4; j++)
           printf("%4.0f",spread_a_weight[i][j] * 1000);
       printf(" b       ");
       for ( j = 0; j < ninputs/4; j++)
           printf("%4.0f",spread_b_weight[i][j] * 1000);
       printf("\n");
   }
   printf("\nerror pattern =");
   for ( i = 0; i < no_of_misclassification; i++)
         printf(" %4d",err_pattern[i]);
printf("\nno_of_misclassification:%4d",no_of_misclassification);
/*str=get_command("show output...");*/
for (i=0;i<24;i++)
printf("\n                                                     ");

/*   for ( i = no_of_misclassification; i < mistake; i++)
         printf("     ");
*/
} /* disp_weight   */ 

/********************/
float membership_all(j) int j; {
/********************/
    int k;
    float sum,s,cx;

        sum=0.0;
        for ( k = 0; k< ninputs/4; k++){ 
               cx=COA(k);
                   s= 1-membership_value( mean_value1_weight[j][k]
                                ,mean_value2_weight[j][k]
                                ,spread_a_weight[j][k]
                                ,spread_b_weight[j][k]
                                ,cx );
/*
 printf("\n\n *IN OF LOOP 2* s:%15.3f, COA:%5.0f, k:%d, j:%d "
                ,s*1000, COA(k)*1000, k , j);*/
                   sum+=s*s;
        }/* for i */            
 
       sum=1-sqrt(sum/k);
/*
printf("\n\n sum:%5.0f, j:%d", sum*1000,j);
str=get_command(" show mem ALL...");
*/
        return(sum);
} /* membership_all */

/********************/
float intersection(j) int j; {
/********************/
    int k;
    float s,sum;

        sum=1.0;
        for ( k = 0; k< ninputs/4; k++){ 
                s = max(0.0,
                min((mean_value2_weight[j][k] + spread_b_weight[j][k]/2.0)
                   , (activation[k*4+1] + activation[k*4+3]/2.0) )
                   - max( (activation[k*4] - activation[k*4+2]/2.0)
                   , (mean_value1_weight[j][k] - spread_a_weight[j][k]/2.0) ) );
                sum*=s;
        }
        return(sum);
}

/********************/
float Union(j) int j; {
/********************/
    int k;
   float s=0.0,sum1,sum2, card1,card2;

        sum1=1.0; sum2=1.0;
        for ( k = 0; k< ninputs/4; k++){ 
           card1= (mean_value2_weight[j][k] + spread_b_weight[j][k]/2.0) 
                   -(mean_value1_weight[j][k] - spread_a_weight[j][k]/2.0);
           card2= (activation[k*4+1] + activation[k*4+3]/2.0) 
            - (activation[k*4] - activation[k*4+2]/2.0);
                sum1*=card1;
                sum2*=card2;
        }
        s=sum1+sum2-intersection(j);
/*
printf("\n\n s:%6.0f, sum1:%6.0f, sum2:%6.0f, intersection:%6.0f, j:%d"
           ,s*1000000, sum1*1000000, sum2*1000000, intersection(j)*1000000, j);
disp_weight();
str=get_command(" show Union ...");*/

        return(s);
}

/********************/
float exemplar_dist(j) int j; {
/********************/
    int k;
    float dist, d;

        dist=0.0; 
        for ( k = 0; k< ninputs/4; k++){ 
                d=max(  0.0,
                     max( COA(k) - 
                      (mean_value2_weight[j][k] + spread_b_weight[j][k]/2.0) 
                     ,(mean_value1_weight[j][k] - spread_a_weight[j][k]/2.0)
                     - COA(k) )  );
                dist+=d*d;
/*
printf("\n\n **In OF LOOP**   dist:%5.0f, k:%d, j:%d"
                ,dist*1000, k, j);*/

        }

/*
printf("\n\n **Out OF LOOP**   dist:%5.0f, k:%d, j:%d"
                ,dist*1000, k, j);
str=get_command(" show exemplar_Dist ...");*/

        dist=sqrt(dist/k);
        return(dist);
}



/********************/
float compute_new_similar(j) int j; {
/********************/
    int i;
    float d,s,cw1=0.0,cw2=0.0,one=0.0,two=0.0;

    d=exemplar_dist(j);
    if (d > 0.0) 
         s= 0.5*(1.0 - d) + intersection(j) / Union(j);
    else 
         s= membership_all(j) + intersection(j) / Union(j);
/*
cw1= intersection(j); cw2=Union(j);one=membership_all(j);
printf("\n\n*compute_new_similar* d:%6.0f,s:%6.0f,j:%d,mem:%6.0f,inter/uni:%6.0f"
                ,d*1E6,s*1E6,j,one*1E6,cw1/cw2*1E6);
disp_weight();
str=get_command(" show s ...");*/

        return(s);
}/* compute_new_similar  */



/************************/
find_exemplar_overlap(ecount)int ecount; {
/************************/
    /* hyperbox learning */

    int i,j,k,n,n1,n2,p,r;
    float s,t,x,y;
    
/* --- find exemplar which has the same class of current pattern ----- */       
       p=ninputs; 
       
       for (r = 0; r < ecount; r++) {
           j = enode_win[r];

           if (j >= ninputs){
              for ( i = p; i < p + nhyperbox; i++ ) {
                 if ( i != j ) {
                   n = 0; n1 = 0; n2 = 0;
                   for ( k = 0; k < ninputs / 4; k++) {
                          x = mean_value1_weight[j][k];
                          y = activation[k*4];
                          s = activation[k*4];
                          if ( x < y ) s = x; /* simulated exemplar*/
                          x = mean_value2_weight[j][k];
                          y = activation[k*4+1];
                          t = activation[k*4+1];
                          if ( x > y ) t = x; /*simulated exemplar*/
       
      /* ------ overlap test (include nesting ) ------------- */ 
                       if (((s < mean_value1_weight[i][k]) 
                           &&  (t < mean_value2_weight[i][k])
                       &&  (t > mean_value1_weight[i][k])) 
                           || ((s > mean_value1_weight[i][k]) 
                       &&  (t > mean_value2_weight[i][k])
                           &&  (s < mean_value2_weight[i][k]))
                       || ((s <= mean_value1_weight[i][k]) 
                           &&  (t >= mean_value2_weight[i][k]))
                       || ((s >= mean_value1_weight[i][k]) 
                           &&  (t <= mean_value2_weight[i][k]))) n++;
                            
                  
      /* ------ nesting test -------------------------------- */ 
                       if ((s <= mean_value1_weight[i][k]) 
                          && (t >= mean_value2_weight[i][k])) n1++;
                       if ((s >= mean_value1_weight[i][k]) 
                          && (t <= mean_value2_weight[i][k])) n2++; 
                   }  /* /  for k */
        
/*     printf("\n test_exemplar:%d,exem:%d,no:%d **********\n",i,j,patno); 
     str=get_command(" exemplar overlap...");   
                       if (n1 == k) {
                           disp_weight();
                           str=get_command("nested n1");
                       }
                       if (n2 == k) {
                           disp_weight();
                           str=get_command("nested n2");
                       }
*/
                       if ( (n == k) && (n1 != k) && (n2 != k) &&
                         (((holap == 1) && (class_flag[i] != class_flag[j]))
                         || (holap == 0)) ) {
                           if (look > 3) {
                               disp_weight();
                               str=get_command("overlap...");
                            }/* if look*/
                            i = p + nhyperbox;
                            enode_win[r] = p - 1;
                       } /* if n,k,n1,n2 */
                   /*  }    for k */
                 } /* if i,j */
              } /* for i */  
          } /*  if j */
       }/* for r */

} /* find_exemplar_overlap */


/************************/
int find_exemplar_distance_criterion(ecount)int ecount; {
/************************/
    /* hyperbox learning */

    int i,j,k,r;
    float distance,criterion=max_size;

/*    str=get_command(" run distance criterion 0...");*/

       for (r = 0; r < ecount; r++) {
         j = enode_win[r];

/*    disp_weight();    
    printf("\n\n ecount:%d,j:%d",ecount,j);
    str=get_command(" int ecount...");  */

         for ( k = 0; k < ninputs / 4; k++ ) {
             distance=0.0;   

             if (mean_value2_weight[j][k] < activation[k*4])
/*                distance = activation[k*4] - activation[k*4+2]/2 - 
                ( mean_value2_weight[j][k] + spread_b_weight[j][k]/2 );
*/
                distance = COA(k) - (mean_value2_weight[j][k] + 
                        spread_b_weight[j][k]/2);

             if (mean_value1_weight[j][k] > activation[k*4+1])
/*                distance = mean_value1_weight[j][k] - spread_a_weight[j][k]/2-
                ( activation[k*4+1] + activation[k*4+3]/2 );
*/
                distance = (mean_value2_weight[j][k] +
                        spread_b_weight[j][k]/2) - COA(k);

             if (distance > criterion){
                enode_win[r] = ninputs - 1;
                k = ninputs / 4 ;                
             }   /* if distance */

        } /* for k */
    }/* for r */
} /* find_exemplar_distance */


/************************/
int find_nearest_exemplar(ecount)int ecount; {
/************************/
    /* hyperbox learning */

    int j,k,r,exp_no;
    float min_dist,ss,s,dist;
    
       exp_no = 0;
       min_dist = 2.0;
       for ( r = 0; r < ecount; r++ ) {
         j = enode_win[r];
         ss=0.0;
         if ( j >= ninputs ) {
              dist = compute_new_similar(j);
         
/*printf("\n\n dist[%d]:%4.0f", j,dist*1000);*/

              if ( dist < min_dist) {
                  exp_no = j;
                  min_dist = dist;
                } /* if dist */
         } /* if j*/ 
      } /* for r */
      
        return(exp_no);    

}/* find_nearest_exemplar */



/************************/
expand_process(win)int win; {
/************************/
    int j,k;
    float x,y,z;

             j=win;     
             size[j] = 0.0;
             for ( k = 0; k < ninputs / 4; k++ ) {
                      x = mean_value1_weight[j][k];
                      y = mean_value2_weight[j][k];

                if (activation[k*4] < mean_value1_weight[j][k]){
/*                   mean_value1_weight[j][k] =max(activation[k*4]
  -(-activation[k*4]+mean_value1_weight[j][k])*
      (float) fallLcount[j][k]/(float) (intcount+1), 0.0);*/
                   fallLcount[j][k]++;
                }
                     mean_value1_weight[j][k]= min(activation[k*4],
                                                mean_value1_weight[j][k]);

/*             *(1-fallLcount[j][k]/(1+fallLcount[j][k]+fallRcount[j][k]));*/

                if (activation[k*4+1] > mean_value2_weight[j][k]){
/*                   mean_value2_weight[j][k]  =min(activation[k*4+1]
  +(activation[k*4+1]-mean_value2_weight[j][k])*
     (float) fallRcount[j][k]/(float) (1+intcount), 1.0);*/
                   fallRcount[j][k]++;
                }
                    mean_value2_weight[j][k]= max(activation[k*4+1],
                                                mean_value2_weight[j][k]);

/*             *(1+fallRcount[j][k]/(1+fallLcount[j][k]+fallRcount[j][k]));*/

                    spread_a_weight[j][k]= max( mean_value1_weight[j][k]
                         - min( x-spread_a_weight[j][k]
                               ,activation[k*4]-activation[k*4+2] ), 0.0);
                    spread_b_weight[j][k]= max(max( y+spread_b_weight[j][k]
                               ,activation[k*4+1]+activation[k*4+3] )
                         - mean_value2_weight[j][k], 0.0);

                                        size[j] += ( mean_value2_weight[j][k] - mean_value1_weight[j][k]
                       +  ( spread_a_weight[j][k] + spread_b_weight[j][k] ) / 2.0 );
    } /* for k */ 
}/* exemplar_process */



/************************/
int find_exemplar() {
/************************/

    int j,p,ecount=0,win=0;
    
/*    no_win = 0;*/

    for (j = 0; j < nhiddens ; j++)
         enode_win[j] = ninputs - 1;     

    if ( nhyperbox > 0 ){

/* --- find exemplar which has the same class of current pattern ----- */       

       p = ninputs;
       
       for ( j = p; j < p + nhyperbox; j++ ) /*belongs to the same class as X*/
           if (class_flag[j] == class) {
              enode_win[ecount] = j;
              ecount++;
           }   

/*str=get_command("initial weight 2-1");*/

       find_exemplar_distance_criterion(ecount);

/*str=get_command("initial weight 2-2");*/

       find_exemplar_overlap(ecount);   

/*str=get_command("initial weight 2-3");*/

       win = find_nearest_exemplar(ecount); 

/*str=get_command("initial weight 2-4");*/    
    }/* if hyoerbix */ 
    return(win);

}/* find exemplar */




/***************************/
compute_nodes_output() {
/***************************/
   int   i;

       for (i = ninputs ; i < (ninputs+nhyperbox); i++)
                 activation[i] = compute_new_similar(i);

/*printf("\n act[%d]:%4.0f, patno:%d, ss:%4.0f,k:%d ",
         i,activation[i]*1000,patno,ss*1000,k );*/

/*str=get_command(" act...");*/
}/* compute_nodes_output */


/***********/
setinput() {
/***********/
    register int    i;
    register float  *pp;
    for ( i = 0, pp = ipattern[patno]; i < ninputs; i++, pp++)
          activation[i] = *pp;
    strcpy(cpname,pname[patno]);
}

/****************/
settarget() {
/****************/
    register int    i;
    register float  *pp;
    
    class = noutputs;
    for ( i = 0, pp = tpattern[patno]; i < noutputs; i++, pp++) {
          desired_out[i] = *pp;
          if ( desired_out[i] == 1.0 ) class = i;
          else desired_out[i] = 0.0;
    }      
} /* compute_nodes_output */


/****************/
setup_pattern() {
/****************/
int k;

    setinput();
    settarget();

/* avoid the crsp data*/
        for ( k = 0; k < (ninputs / 4 ) ; k++)  { 
            if  ( ( activation[k*4+1]+activation[k*4+3]-
                 activation[k*4]+activation[k*4+2]) ==0.0){
                activation[k*4+2]+=1E-5;
                activation[k*4+3]+=1E-5;
               }
        }
}


/*******************************/
compute_classification_result() {
/*******************************/
     int i,j,k,m;
     float s;
   
     s = 0.0;
     
     for (j = ninputs; j < ninputs + nhiddens; j++) {
         if (activation[j] > s) {
            s = activation[j]; 
            winner = j;
         }   
/* printf(" act[%d]:%4.0f ",j,activation[j]*1000); */
     }    
/*printf("\n");*/
     
     if ( s == 0.0 ) {
        err_pattern[no_of_misclassification] = patno;
        no_of_misclassification++;      
        mis_flag = 1;
        nonwin = 1;   
     }   
     else {
        nonwin = 0;
        mis_flag = 0;  
        if ((class_flag[winner] == class) && (use_flag[winner] == 0))        
           mis_flag = 1; 
        else if (class_flag[winner] != class) {
               err_pattern[no_of_misclassification] = patno;
               no_of_misclassification++;
               if (no_of_misclassification > mistake)
               mistake = no_of_misclassification; 

           mis_flag = 1;

disp_weight(); str=get_command(" find errer...");

        }
/*disp_weight(); str=get_command(" find double errer...");*/
     } 
}/* compute_classification_result  */


 /************************/
int fall_fully_in_E(win)int win; {
/************************/
    int i,k,n1;
    float s,t;
    i=win;
/*str=get_command("initial weight 4-1");*/
                n1 = 0;
                for ( k = 0; k < ninputs / 4; k++) {
                       s = activation[k*4];
                       t = activation[k*4+1];

/*str=get_command("initial weight 4-2");*/

                       if ((s >= mean_value1_weight[i][k]) 
                           && (t <= mean_value2_weight[i][k])) n1++; 
/*str=get_command("initial weight 4-3");*/

                } /* for k */

   if (n1==k)
          return(1);
   else
          return(0);     

} /* fall_fully in E */



/*********************/
int the_other_expand_process(win)int win; {
/*********************/
     int     i, do_expand=0, no_merge=0;

/*str=get_command("initial weight 6-1");*/

     /*           do_expand=expand_fuzzypart(win);   for kbe */

/*str=get_command("initial weight 6-2");*/

                if (do_expand>0) {

/*str=get_command("initial weight 6-3");*/

                        check_size(win);

/*str=get_command("initial weight 6-4");*/

                        no_merge=check_process_overlap(win);
  
              } /* if do_expand */

/*str=get_command("initial weight 6-5");*/

        return(no_merge);
}/* the _other_expand_process */



/*********************/
int prototype_trial() {
/*********************/
     int     i, do_expand, win, no_merge=0;

     intcount++; /* input # patterns */

/*str=get_command("initial weight 2");*/

        if  ( (win=find_exemplar())<1) {

/*str=get_command("initial weight 3");*/
              hyperbox_generate();

        }
        else {

/*str=get_command("initial weight 4");*/

              if ( fall_fully_in_E(win)==0){

/*str=get_command("initial weight 5");*/

                    expand_process(win);
              }
              else {

/*str=get_command("initial weight 6");*/
                  no_merge=the_other_expand_process(win);
              }


        }       
/*str=get_command("initial weight 7");*/

/*        merge_process();  */
/*printf("\n intcount:%d",intcount);str=get_command(" intcount...");*/

        return(no_merge);
}/* pototype_trial */


/*********************/
int expand_fuzzypart(win)int win;{
/*********************/
     int     j,k,do_expand;
     float   x,y,t1,t2,a,b;

 /*    j = ninputs + class;*/
        j=win; /* near winner */
        do_expand=0; /* suppose no expand */

/*str=get_command("initial weight 6-1-1");*/

        for ( k = 0; k < ninputs / 4; k++ ) {

           x = mean_value1_weight[j][k];
           y = mean_value2_weight[j][k];

           t1 = activation[k*4];
           t2 = activation[k*4+1];

/*str=get_command("initial weight 6-1-2");*/
/*
printf("\n\n COA(k):%5.1f,t1:%5.1f,t2:%5.1f,(x,t1):%11.0f,(y,t2):%11.0f,intcount:%2d",
COA(k),t1,t2,absolute_dist_op(x,t1)*1e10,absolute_dist_op(y,t2)*1e10,intcount);
str=get_command("into check ");*/

/*           if (t1 <= x) {*/
           if (t2 < COA(k)) {
/*           if ( absolute_dist_op(x,t1) < absolute_dist_op(y,t2) ){*/
                fallLcount[j][k]++;
/*                spread_a_weight[j][k] *=1+(x- min(x-spread_a_weight[j][k],
                                t1- activation[k*4+2]))*fallLcount[j][k]/
                                        (float) intcount;*/

                spread_a_weight[j][k] *=1+(float) fallLcount[j][k]/
                                        (float) intcount;
                do_expand++;
                if ( (x-spread_a_weight[j][k])<0.0 )
                   spread_a_weight[j][k]=x;
                        /* x's lenght is from zero */
/*printf("\n\n fallLcount[%d]:%2.0f, intcount:%2d",
j,fallLcount[j][k],intcount);*/
/*str=get_command("into LEFT");*/
            }

/*str=get_command("initial weight 6-1-3");*/

/*           if (y <= t2) {*/
           if (COA(k) < t1) {
/*           if ( absolute_dist_op(x,t1) > absolute_dist_op(y,t2) ){*/
                fallRcount[j][k]++;
/*                spread_b_weight[j][k] *=1+(max(y+spread_b_weight[j][k],
                                t2+activation[k*4+3])-y) * fallRcount[j][k]/
                                        (float) intcount;*/
                spread_b_weight[j][k] *=1+ (float) fallRcount[j][k]/
                                        (float) intcount;
                do_expand++;
                if ( (y+spread_b_weight[j][k])>1.0 )
                   spread_b_weight[j][k]=1.0-y; 
                        /*y's lenght is from zero to 1*/
/*printf("\n\n fallRcount[%d]:%2.0f,intcount:%2d,b:%5.0f",
j,fallRcount[j][k],intcount,spread_b_weight[j][k]*1000);*/
/*str=get_command("into RIGHT");*/
            }

/*str=get_command("initial weight 6-1-4");*/

/*           if ( ( x < t1) && ( t2 < y ) ) {*/
           if ( ( t1 <= COA(k)) && ( COA(k) <= t2 ) ) {
                spread_a_weight[j][k] = x - min((t1-activation[k*4+2]) ,
                                         (x-spread_a_weight[j][k])) ;
                spread_b_weight[j][k] = max((t2+activation[k*4+3]) ,
                                         (y+spread_b_weight[j][k])) - y;
                do_expand++;
            }

/*str=get_command("initial weight 6-1-5");*/

          } /* for k */
/*printf("\n winner:%d , patno:%2d", winner, patno);*/
/*disp_weight();
str=get_command("check L,R count...");   */
        return(do_expand);
}/* expand_fuzzypart  */ 


/*********************/
check_size(win)int win; {
/*********************/
     int     j,k;
     float   a,b,len,x,y;

  /*   j = ninputs + class;*/
     j=win;

     for ( k = 0; k < ninputs / 4; k++ ) {
           x = mean_value1_weight[j][k];
           y = mean_value2_weight[j][k];
           a = spread_a_weight[j][k];
           b = spread_b_weight[j][k];
           len = membership_height[j][k];
           if ( (len/sqrt(a*a+len*len)) < 0.97 )
/*           if ( (a/(y-x)) > (sqrt(3)/2) )*/
             {
/*printf("\n j:%d,a:%5.0f,b:%5.0f,len:%5.0f",j,a*1000,b*1000,len);
str=get_command("oversize.... for a");*/

             mean_value1_weight[j][k]*=(1.0- fallLcount[j][k]/
                                        (float) intcount);
             spread_a_weight[j][k]-=( x-mean_value1_weight[j][k]);

              if ( mean_value1_weight[j][k] < 0.0 ){
                        mean_value1_weight[j][k]=0.0;
                        spread_a_weight[j][k]=0.0;
               }         
             }
           if ( (len/sqrt(b*b+len*len)) < 0.97 )
/*           if ( (b/(y-x)) > (sqrt(3)/2) )*/
             {
/*printf("\n j:%d,a:%5.0f,b:%5.0f,len:%5.0f",j,a*1000,b*1000,len);
str=get_command("oversize.... for b");*/
              mean_value2_weight[j][k]*=(1.0+ fallRcount[j][k]/
                                        (float) intcount);
              spread_b_weight[j][k]-=(mean_value2_weight[j][k]-y);

              if ( mean_value2_weight[j][k] > 1.0 ){
                           mean_value2_weight[j][k]=1.0;
                           spread_b_weight[j][k]=0.0;
               }
              }
        if ( (x-spread_a_weight[j][k])<0.0 )
           spread_a_weight[j][k]=x;
                        /* x's lenght is from zero */
        if ( (y+spread_b_weight[j][k])>1.0 )
           spread_b_weight[j][k]=1.0-y;
                        /*y's lenght is from zero to 1*/
        }
}/* check_size   */


/*********************/
int check_process_overlap(win) int win; {
/*********************/
     int     i,j,k,no_merge=0;
     float   s,t,x,y,fallsumi,fallsumj,hi,hj;

        j=win;
     for ( i = ninputs; i < ninputs + nhyperbox ; i++ )
        if ( (i != j) && (class_flag[i]==class_flag[j]) )
                if ( check_overlap(i,j) ) {
/*disp_weight();*/
/*printf("\n\n overlap i:%d, j:%d",i,j);
                str=get_command("overlap....");*/
                for ( k = 0; k < ninputs / 4; k++ ) {
                      x = mean_value1_weight[j][k];
                      y = mean_value2_weight[j][k];
 /*                     hj=       membership_height[j][k];*/
                      s = mean_value1_weight[i][k];
                      t = mean_value2_weight[i][k];
/*                      hi=       membership_height[i][k];*/

/*disp_weight();
printf("\n\n i:%d, j:%d",i,j);
                str=get_command("process overlap....");*/

                  mean_value1_weight[j][k]= min(mean_value1_weight[i][k],
                                             mean_value1_weight[j][k]);
                  mean_value2_weight[j][k]= max(mean_value2_weight[i][k],
                                             mean_value2_weight[j][k]);

                  spread_a_weight[j][k]= mean_value1_weight[j][k] 
                                        - min( x-spread_a_weight[j][k]
                                            , s- spread_a_weight[i][k] );
                  spread_b_weight[j][k]= max( y+spread_b_weight[j][k]
                                            , t+ spread_b_weight[i][k] )
                                         - mean_value2_weight[j][k];
                  fallRcount[j][k]=min( max(fallRcount[i][k],
                                             fallLcount[i][k]) ,
                                        max(fallRcount[j][k],
                                             fallLcount[j][k]) );
                  fallLcount[j][k]=fallRcount[j][k];

/*                        fallsumi=fallRcount[i][k]+fallLcount[i][k];
                        fallsumj=fallRcount[j][k]+fallLcount[j][k];*/

/*                        membership_height[j][k]= (fallsumi*hi+fallsumj*hj)
                                        /(fallsumi+fallsumj);*/

                        mean_value1_weight[i][k]=0.0; 
                        mean_value2_weight[i][k]=0.0;
                        spread_a_weight[i][k]=0.0; spread_b_weight[i][k]=0.0;
                        fallRcount[i][k]=0.0; fallLcount[i][k]=0.0;
                        membership_height[i][k]=0.0;
                        no_merge++;
                }  /* for k */  } /*  if i j */
        return(no_merge/k);
}/* check_process_overlap   */


/*********************/
check_overlap(a,b) int a,b; {
/*********************/
     int     k,one,i,n;
     float   s,t;

     one=1;i=b;n=0;
     for ( k = 0; k < ninputs / 4; k++ ) {
           s = mean_value1_weight[a][k];
           t = mean_value2_weight[a][k];

      /* ------ overlap test ( not include nesting ) ------------- */
                       if (((s < mean_value1_weight[i][k])
                           &&  (t < mean_value2_weight[i][k])
                       &&  (t > mean_value1_weight[i][k]))
                           || ((s > mean_value1_weight[i][k])
                       &&  (t > mean_value2_weight[i][k])
                           &&  (s < mean_value2_weight[i][k])))
                            n++;
     }       
      if  (n<k)  one=0;

/*disp_weight();
printf("\n\n check overlap n:%d, k:%d",n,k);
str=get_command("check overlap....");
*/
  /*              one=0;*/

      return(one);
}/* check_overlap   */





/********************/
hyperbox_generate() {
/********************/
   int j,k;
   
   j = ninputs + nhyperbox;
   if (j > (nunits - max_prototype_node - 1)) {
        printf ("\n *** error %d***\n", nhyperbox);
   }
   else {
     size[j] = 0.0;
     for ( k = 0; k < ninputs / 4; k++) {
       mean_value1_weight[j][k] = activation[k * 4];
       mean_value2_weight[j][k] = activation[k * 4 + 1];
       spread_a_weight[j][k] = activation[k * 4 + 2];
       spread_b_weight[j][k] = activation[k * 4 + 3];
       membership_height[j][k] = 1.0;
       fallLcount[j][k] = 0.0;
       fallRcount[j][k] = 0.0;
       size[j] += ( mean_value2_weight[j][k] - mean_value1_weight[j][k]
               +  ( spread_a_weight[j][k] + spread_b_weight[j][k] ) / 2.0 );
     }

     class_flag[j] = class;  
     use_flag[j] = 1;       
     nhyperbox++;
   }
}/* hyperbox_generate  */


/****************/
hyperbox_trial() {
/****************/
int k;

    setup_pattern();
/*
    for ( k = 0; k < (ninputs / 4 ) ; k++)  {  avoid the crisp data
            if  ( ( activation[k*4+1]+activation[k*4+3]-
                 activation[k*4]+activation[k*4+2]) ==0.0){
                activation[k*4+2]+=1E-8;
                activation[k*4+3]+=1E-8;
               }
    }*/

    compute_nodes_output();
    compute_classification_result(); 
/*    disp_weight(); str=get_command("show");*/
   
    if (Interrupt) { /* interrupt in running pdp */
               Interrupt_flag = 0;
               update_display();
               if (contin_test() == BREAK) return(BREAK);
    }

}/* hyperbox_trial  */



/****************/
get_input_order() {
/****************/

   int i,j,old,npat;

   FILE  *fp;
   char  fstr[80];

   if (! System_Defined)
      if (! define_system())
         return(BREAK);

/*   new();*/
   strcpy(fstr,"../ok/");
   str = get_command(" filename (get): ");
   if (str == NULL) return(CONTINUE);
   strcat(fstr,str);

   if ((fp = fopen(fstr,"r")) == NULL ) {
      return(put_error("Cannot open file"));
   }
   nhyperbox = 0;
   for ( j = 0; j < npatterns; j++ ) {
       (void) fscanf(fp," %d ",&used[j]);
   }
   fclose(fp);
   nhyperbox /= i;
   return(CONTINUE);
}  /* intput order */



/****************/
int train_process() {
/****************/
     int   i,j,k,t,old,npat,tra_mis=0,no_merge=0;

        new1();
/*        for (i = 0; i <npatterns ; i++) {
                npat = rnd() * (npatterns- i) + i;
             npat=(npatterns)/(i+7);
                old = used[i];
                used[i] = used[npat];
                used[npat] = old;
         }
*/
get_input_order();
/*
used[0]=9;used[1]=7;used[2]=4;used[3]=2;used[4]=6;used[5]=8;
used[10]=2;used[11]=11;used[12]=4;used[13]=0;used[14]=8;used[15]=7;*/


         for (i = 0; i < npatterns; i++) tra_pattern[i] = used[i];      


/* ------------ iris generalization ability test -------- */
      if (iris == 1) {
         j = 0;
         for (i = 0; i < npatterns; i++) {
             patno = used[i];
             setup_pattern();
             for ( k = 0; k < noutputs; k++ )
             if ( (class == k) && (use_train[k] < t_rate * npatterns) ) {
                tra_pattern[j] = patno;
                use_train[k]++;
                j++;
             } /* if */
         }/* for i */    
      } /* if iris  */  
      
/* --- base time --- */
         time4 = 0;
         if ( (tick1 = clock()) == (clock_t) - 1 ) {
            printf("\nclock error *****\n");
            exit(0);
         }
         for (i = 0; i < tra_no; i++) {
             if (Interrupt) {
                Interrupt_flag = 0;
                update_display();
                if (contin_test() == BREAK) return(BREAK);
             } /* interrupt */
             patno = tra_pattern[i];
             setup_pattern();
             
/* delay */  if (tra_no < 1000) 
                 for (j = 0; j < 2 * (1000 - tra_no); j++) { j++; j--; }
             
             if (step_size == PATTERN) {
               update_display();
               if (single_flag) {
                 if (contin_test() == BREAK) return(BREAK);
               } /* if single */
             }/* if step_size */
         } /* for i  */
         if ( (tick2 = clock()) == (clock_t) - 1 ) {
            printf("\nclock 2 error ******\n");
            exit(0);
         }
         time4 = (unsigned) (tick2 - tick1);
/* --- end --- */

  if (no_phase1 == 0) {
     for (t = 0; t < max_run_len; t++) {
         if (!tallflag) epochno++;
         no_of_misclassification = 0;
      /*   for (i = 0; i < tra_no; i++) {
             npat = rnd() * (tra_no - i) + i;
             old = tra_pattern[i];
             tra_pattern[i] = tra_pattern[npat];
             tra_pattern[npat] = old;
         }
*/
         time1 = 0;
         if ( (tick1 = clock()) == (clock_t) - 1 ) {
            printf("\nclock error *****\n");
            exit(0);
         }

         for (i = 0; i < tra_no; i++) {
             if (Interrupt) {
                Interrupt_flag = 0;
                update_display();
          if (contin_test() == BREAK) return(BREAK);
             }
             patno = tra_pattern[i];

         setup_pattern();       

                no_merge+=prototype_trial();  /********/

/*     disp_weight(); str=get_command("show");*/


           if (step_size == PATTERN) {
               update_display();
               if (single_flag) {
                 if (contin_test() == BREAK) return(BREAK);
               }
           }     
         }/* for tra_no*/

         if ( (tick2 = clock()) == (clock_t) - 1 ) {
            printf("\nclock 2 error ******\n");
            exit(0);
         }
         time1 = (unsigned) (tick2 - tick1) - time4;
         iteration++;

         if (single_flag)
               if (contin_test() == BREAK) return(BREAK);

     }  /* for max_run_len */  

       no_of_misclassification = 0;

   /*  test_alls_all_patterns('p');*/
/*     for (i = 0; i < tra_no; i++) {
             patno = tra_pattern[i];
             hyperbox_trial();
     }
     disp_weight();
     str=get_command("start exemplar training");*/

  } /* if no_phase1 */

     if ( t_rate < 1.0 ) {
        no_of_misclassification = 0;
        for (i = 0; i < tra_no; i++) {
            patno = tra_pattern[i];
            hyperbox_trial();
/*     disp_weight(); str=get_command("show ");*/

        }/* for i */
        tra_mis=no_of_misclassification; /* after train #error */
/*
        disp_weight();*/
        str=get_command("training set error .....");

     }/* if t_rate */

     tall();
     no_of_misclassification-=tra_mis;   
     return(no_merge);   
} /* train_process*/




/****************/
train(c) char c; {
/****************/
     int     i,j,k,t,old,npat,no_merge=0,
             no_train=1,no_error=0; 
     float   ave_no_error=0.0,no_hyper=0.0;     
   
     if (!System_Defined)
        if (!define_system())
           return(BREAK);

        proto_train = TRUE;

         random_seed = rand();
         srand(random_seed);    

         for (i = 0; i <npatterns; i++) used[i] = i;            
         for (i = 0; i < no_train; i++) {
                    no_merge+=train_process();                
                    no_error += no_of_misclassification;
                    no_hyper += nhyperbox;
                } /* for i */
        ave_no_error = (float)no_error/ (float)no_train ;
        no_hyper = (float)(no_hyper-no_merge)/ (float)no_train;  
        printf("\n\n ave_no_error:%6.2f,no_merge:%3d, no_hyper:%5.2f "
        ,ave_no_error,no_merge,no_hyper);
        str=get_command("** train many times... ***");

return(CONTINUE);
}

/*********/
ptrain() {
/*********/
  return(train('p'));
}

/*********/
strain() {
/*********/
  return(train('s'));
}


/**************************/
test_all_patterns(c) char c; {
/**************************/
    int   j,k,t,i,old,npat;
    
    for (t = 0; t < 1; t++) {
        if (!tallflag) epochno++;

        for (i = 0; i < npatterns; i++) used[i] = i;
        if (c == 'p') {
          for (i = 0; i < npatterns; i++) {
            npat = rnd() * (npatterns - i) + i;
            old = used[i];
            used[i] = used[npat];
            used[npat] = old;
          }
        }

/*        if (look) {
           disp_weight();
           str=get_command("testing .....");
        }  */
         
        for (i= ninputs; i < ninputs + nhiddens; i++) use_flag[i] = 0;        
        for (i = 0; i < npatterns; i++) {
            if (Interrupt) {
               Interrupt_flag = 0;
               update_display();
               if (contin_test() == BREAK) return(BREAK);
            }
            patno = used[i];
             
            hyperbox_trial();
            use_flag[winner]++;

/*     disp_weight(); str=get_command("show test...");*/

            j = 0;
            for ( k = ninputs + noutputs; k < ninputs + nhiddens; k++ ) 
                if ( activation[k] > 0.0 ) j++;

            if ( (look) && ((class_flag[winner] != class) || ( j > 2 )) ) {
               disp_weight();
               str=get_command("error or nested");
            }   

            if (step_size == PATTERN) {
               update_display();
               if (single_flag) {
                 if (contin_test() == BREAK) return(BREAK);
               }
            }
        }
        if (step_size == EPOCH)  {
          update_display();
          if (single_flag)  {
                 if (contin_test() == BREAK) return(BREAK);
          }
        }
    }
    disp_weight();
}



/********/
tall() {
/********/
  int i,save_lflag;
  int save_single_flag;
  int save_nepochs;
  int save_step_size;

  save_lflag = lflag;  lflag = 0;
  save_single_flag = single_flag;
/*  if (in_stream == stdin) single_flag = 1;  */
  single_flag = 0;
  save_nepochs = nepochs;  nepochs = 1;
  save_step_size = step_size;
  if (step_size > PATTERN) step_size = PATTERN;
  tallflag = 1;
  no_of_misclassification = 0;
  proto_train = FALSE;
  test_all_patterns('s');
  /*train('s');*/
  
  proto_train = TRUE;
  tallflag = 0;
  lflag = save_lflag;
  nepochs = save_nepochs;
  single_flag = save_single_flag;
  step_size = save_step_size;
  return(CONTINUE);
}

/****************/
test_pattern() {
/****************/
    char   *str;
    int    j,k,t;
    
    if (!System_Defined)
        if (!define_system())
            return(BREAK);

    str = get_command("Test which pattern? ");
    if (str == NULL) return(CONTINUE);
    if ((patno = get_pattern_number(str)) < 0 ) {
        return(put_error("Invalid pattern specification."));
    }
    
    hyperbox_trial();
    disp_weight();
    
    return(CONTINUE);
}


/****************/
leaving_one_out_test()  {
/****************/
        return(CONTINUE);
}


/****************/
new() {
/****************/
   new1();
   disp_weight();
}




/***********/
new1() {
/***********/
   int i,j;
   
   nhyperbox = 0;
   iteration = 0;
   epochno = 0;
   winner = 0;
   lrate = 1.0;
   no_of_misclassification = 0;
   time1 = time2 = time3 = time4 = 0;
   
   tra_no = (int) ( (float) (npatterns) * t_rate);   /*decise how much trained
                                                       patterns*/ 
 
   for (i = ninputs; i < nunits - noutputs; i++) {

       if ( find_prototype_number == 0) old_use_flag[i]=0;

       use_flag[i] = 0;
       class_flag[i] = noutputs; 
   }
   for (j = 0; j < nunits; j++) size[j] = 0.0;
   for (j = 0; j < nunits; j++) activation[j] = 0.0;

   if( find_prototype_number==0 ) 
        for (i = 0; i < npatterns; i++) tra_pattern[i] = i;

   for (i = 0; i < npatterns; i++) err_pattern[i] = npatterns;
   for (i = 0; i < nhiddens - max_prototype_node; i++) enode_win[i] = 0;
   for (i = 0; i < noutputs; i++) use_train[i] = 0;

    for (j = 0; j < nunits; j++) p_node_index[j] = 0;

/*   reset_weights();*/
} 



/****************/
reset_weights() {
/****************/

    int i,j;
str=get_command("wait...");
   
     for (i=0 ; i< nhiddens ; i++)
      {
         for(j=0; j< noutputs ;j++)
         pnode_weight[i][j]=  0.5;
      }
 
    if ( (pal == 2) && ( find_prototype_number == 0) )
      {
       for (i = ninputs ; i < ninputs + max_prototype_node; i++) 
           for (j = 0; j < (ninputs / 4); j++) 
             {
               random_seed =rand();
               srand(random_seed);

              mean_value1_weight[i][j] = 
                mean_value2_weight[i][j] = rnd()/10.0;

              mean_value1_weight[i][j]+=0.45;
              mean_value2_weight[i][j]+=0.45;
              spread_a_weight[i][j] =0;
              spread_b_weight[i][j] =0;
             }

          printf("\n ****************** initaial for prototype ************************\n");
          for ( i = ninputs; i < ninputs +max_prototype_node ; i++) {
           printf(" m1[%d]= ",i);
           for ( j = 0; j < ninputs/4; j++)
           printf("%4.0f",mean_value1_weight[i][j]*1000);
           printf(" m2[#%d]  ",use_flag[i]);
           for ( j = 0; j < ninputs/4; j++)
           printf("%4.0f",mean_value2_weight[i][j]*1000);
           printf(" a       ");
           for ( j = 0; j < ninputs/4; j++)
           printf("%4.0f",spread_a_weight[i][j]*1000 );
           printf(" b       ");
           for ( j = 0; j < ninputs/4; j++)
           printf("%4.0f",spread_b_weight[i][j]*1000 );
           printf("\n");
       
         }



      }
    else if ( (pal == 2) && ( find_prototype_number == 1) )
          for (j = 0; j < (ninputs / 4); j++) 
             {
              mean_value1_weight[ninputs+max_prototype_node-1][j] = 
          mean_value2_weight[ninputs+max_prototype_node-1][j] = rnd()/10.0;

              mean_value1_weight[ninputs+max_prototype_node-1][j]+=0.45;
              mean_value2_weight[ninputs+max_prototype_node-1][j]+=0.45;
              spread_a_weight[ninputs+max_prototype_node-1][j] = 0.0;
              spread_b_weight[ninputs+max_prototype_node-1][j] = 0.0 ;
             }



        for (i = ninputs+max_prototype_node ; i < nunits-max_prototype_node; i++) 
           for (j = 0; j < (ninputs / 4); j++) 
             {
              mean_value1_weight[i][j]=0.0;
              mean_value2_weight[i][j]=0.0;
              spread_a_weight[i][j] = 0.0;
              spread_b_weight[i][j] =0.0;
             }


}


/****************/
get_weights() {
/****************/

   int i,j,old,npat;

   FILE  *fp;
   char  fstr[80];
   
   if (! System_Defined)
      if (! define_system())
         return(BREAK);
   
   new();      
   strcpy(fstr,"../ok/");
   str = get_command(" filename (get): ");                
   if (str == NULL) return(CONTINUE);
   strcat(fstr,str);

   if ((fp = fopen(fstr,"r")) == NULL ) {
      return(put_error("Cannot open file"));
   }

   nhyperbox = 0;
   for ( j = ninputs; j < nunits - noutputs; j++ ) { 
     size[j] = 0.0;
     for ( i = 0; i < ninputs / 4; i++) {
       (void) fscanf(fp,"  %d  %f  %f  %f  %f \n",
                           &class_flag[j],
                           &mean_value1_weight[j][i],
                           &mean_value2_weight[j][i],
                           &spread_a_weight[j][i],
                           &spread_b_weight[j][i]);
       if (class_flag[j] != noutputs) nhyperbox++;
       size[j] += ( mean_value2_weight[j][i] - mean_value1_weight[j][i]
               +  ( spread_a_weight[j][i] + spread_b_weight[j][i] ) / 2.0 );

     }
   }  
   fclose(fp);   
   nhyperbox /= i; 
/*   nhyperbox -= noutputs;  */

/*   test_all_patterns('p');*/
   return(CONTINUE);                                            
}


/****************/
save_weights() {
/****************/

   int i,j;

   FILE  *fp;
   char  fstr[80];
   
   if (! System_Defined)
      if (! define_system())
         return(BREAK);
         
   strcpy(fstr,"../ok/");
   str = get_command(" filename(save): ");                
   if (str == NULL) return(CONTINUE);
   strcat(fstr,str);
   strcpy(str,"");      
   if ((fp = fopen(fstr,"w")) == NULL ) {
      return(put_error("Cannot open file"));
   }

   for ( j = ninputs; j < nunits - noutputs; j++ ) { 
       for ( i = 0; i < ninputs / 4; i++) 
           fprintf(fp,"  %3d  %6.3f  %6.3f  %6.3f  %6.3f  \n",
                                class_flag[j], 
                                mean_value1_weight[j][i],
                                mean_value2_weight[j][i],
                                spread_a_weight[j][i],            
                                spread_b_weight[j][i]);
       fprintf(fp,"\n");
   }                             

   fclose(fp);
   return(CONTINUE);                                            
}



/*************/
init_system() {
/*************/
    int     strain(), ptrain(), tall(), test_pattern(),reset_weights();
    int     get_unames();

    install_command("leaving_one_out_test", leaving_one_out_test, BASEMENU,(int *) NULL);
    install_command("strain", strain, BASEMENU,(int *) NULL);
    install_command("ptrain", ptrain, BASEMENU,(int *) NULL);
    install_command("tall", tall, BASEMENU,(int *) NULL);
    install_command("test", test_pattern, BASEMENU,(int *) NULL);
    install_command("new",new,BASEMENU,(int *)NULL);
    install_command("reset",reset_weights,BASEMENU,(int *)NULL);
    install_command("w", get_weights, GETMENU,(int *) NULL);
    install_command("w", save_weights, SAVEMENU,(int *) NULL);
    install_command("patterns", get_pattern_pairs, GETMENU,(int *) NULL);
    install_command("unames", get_unames, GETMENU,(int *) NULL);
    install_var("noutputs", Int,(int *) & noutputs, 0, 0, SETCONFMENU);
    install_var("ninputs", Int,(int *) & ninputs, 0, 0, SETCONFMENU);
    install_var("nunits", Int,(int *) & nunits, 0, 0, SETCONFMENU);
    install_var("nhiddens", Int,(int *) & nhiddens, 0, 0, SETCONFMENU);
    install_var("iris", Int,(int *) & iris, 0, 0, SETPARAMMENU);
    install_var("pal", Int,(int *) & pal, 0, 0, SETPARAMMENU);
    install_var("no_phase1", Int,(int *) & no_phase1, 0, 0, SETPARAMMENU);    
    install_var("alpha", Float,(int *) & alpha, 0, 0, SETPARAMMENU);
    install_var("lrate", Float,(int *) & lrate, 0, 0, SETPARAMMENU);
    install_var("max_size", Float,(int *) & max_size, 0, 0, SETPARAMMENU);
    install_var("t_rate", Float,(int *) & t_rate, 0, 0, SETPARAMMENU);    
    install_var("pass", Int,(int *) & pass, 0, 0, SETPARAMMENU);
    install_var("holap", Int,(int *) & holap, 0, 0, SETPARAMMENU);    
    install_var("max_run_len", Int,(int *) & max_run_len, 0, 0, SETPARAMMENU);
    install_var("look", Int,(int *) & look, 0, 0, SETPARAMMENU);    
    install_var("lflag", Int,(int *) & lflag, 0, 0, SETPCMENU);
    install_var("nepochs", Int,(int *) & nepochs, 0, 0, SETPCMENU);
    install_var("epochno", Int,(int *) & epochno, 0, 0, SETSVMENU);
    install_var("patno", Int,(int *) & patno, 0, 0, SETSVMENU);
    install_var("npatterns", Int,(int *) & npatterns, 0, 0,SETENVMENU);
    install_var("no_of_misclassification", Int,(int *) & no_of_misclassification, 0, 0, NOMENU);
    install_var("patno", Int,(int *) & patno, 0, 0, NOMENU);
    install_var("count", Int,(int *) & count, 0, 0, NOMENU);
    install_var("nhyperbox", Int,(int *) & nhyperbox, 0, 0, NOMENU);
    install_var("winner_no", Int,(int *) & winner_no, 0, 0, NOMENU);
    install_var("iteration", Int,(int *) & iteration, 0, 0, NOMENU);

    init_pattern_pairs();
}





